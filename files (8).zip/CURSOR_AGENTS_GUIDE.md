# Cursor Agents for DAiW Development

## 🎯 OVERVIEW

**Cursor** is an AI-powered code editor (VS Code fork) with autonomous agent capabilities. Unlike GitHub Copilot's suggestions, Cursor agents can autonomously make changes across multiple files, run terminal commands, and execute complex multi-step tasks.

### **What Makes Cursor Different:**

```
GitHub Copilot:
- Suggests code completions
- You accept/reject each suggestion
- Single-file focus
- Passive assistance

Cursor Agents:
- Autonomously edits multiple files
- Runs terminal commands
- Multi-step task execution
- Active development partner
```

---

## 🤖 CURSOR AGENT MODES

### **1. Agent Mode (Ctrl/Cmd + I)**
Autonomous agent that can:
- Edit multiple files simultaneously
- Run terminal commands (tests, scripts)
- Install dependencies
- Fix errors across codebase
- Implement complete features

### **2. Composer (Ctrl/Cmd + Shift + I)**
Multi-file editing assistant:
- See all proposed changes before applying
- Edit multiple files in one operation
- Visual diff view
- Accept/reject per file

### **3. Chat Mode (Ctrl/Cmd + L)**
Conversational coding assistant:
- Explain code
- Answer questions about codebase
- Suggest improvements
- Generate code snippets

### **4. Inline Edit (Ctrl/Cmd + K)**
Quick inline edits:
- Modify selection
- Refactor code
- Add documentation
- Fix bugs

---

## 🚀 SETTING UP CURSOR FOR DAIW

### **Step 1: Install Cursor**
```bash
# Download from https://cursor.sh
# Or via homebrew:
brew install --cask cursor
```

### **Step 2: Open DAiW Project**
```bash
# Open DAiW workspace in Cursor
cursor /path/to/DAiW-Music-Brain

# Or from within project:
cd DAiW-Music-Brain
cursor .
```

### **Step 3: Configure Cursor Rules**

Create `.cursorrules` in project root:
```bash
touch .cursorrules
```

**Add DAiW-specific rules:**
```
# DAiW - Digital Audio intelligent Workstation
# "Interrogate Before Generate" Philosophy

## Project Context

This is DAiW, an AI-powered music production system that translates emotional 
intent into musical compositions. The core philosophy is "Interrogate Before 
Generate" - deeply understanding emotional truth before making technical decisions.

## Core Principles

1. Emotional truth drives all technical decisions
2. Intentional rule-breaking serves authenticity
3. Imperfection is an authenticity marker
4. Every choice must be emotionally justified

## Architecture

- Python 3.12+
- Key dependencies: mido, librosa, pydantic, mcp
- Async/await for I/O operations
- Type hints required
- Pydantic v2 for validation

## Coding Standards

### Pydantic Models
```python
class Model(BaseModel):
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra='forbid'
    )
    
    field: str = Field(
        ...,
        description="Clear description with examples",
        min_length=1
    )
    
    @field_validator('field')
    @classmethod
    def validate_field(cls, v: str) -> str:
        return v
```

### Error Handling
Always provide actionable error messages with suggestions:
```python
raise ValueError(
    f"Error: {details}. "
    f"Suggestion: Try this instead."
)
```

### Async Functions
```python
async def async_operation(param: str) -> dict:
    """Clear docstring with examples."""
    try:
        result = await some_async_call(param)
        return result
    except Exception as e:
        logger.error(f"Operation failed: {e}")
        raise
```

## Kelly Song Reference Test Case

Use this as the canonical test for all harmony-related code:
```python
kelly_intent = CompleteSongIntent(
    core_wound="Finding someone after they left",
    emotional_intent="Grief disguised as love",
    technical_constraints="F major, 82 BPM, lo-fi",
    technical_rule_to_break="HARMONY_ModalInterchange"
)
# Expected: F-C-Dm-Bbm
# Bbm = "bittersweet darkness, borrowed sadness"
```

## File Organization

- music_brain/ - Core modules
- daiw_mcp/ - MCP server
- vault/ - Knowledge base
- tests/ - Test suite
- docs/ - Documentation

## Current Priorities

1. Complete Phase 1 CLI wrapper
2. Expand MCP tool coverage (3/30 tools done)
3. Implement Phase 2 audio analysis
4. Generate Kelly song complete package

## Anti-Patterns to Avoid

- Don't over-engineer
- Don't sacrifice emotional authenticity for technical perfection
- Don't apply rules without understanding their purpose
- Don't use magic numbers
- Don't write functions without docstrings

## Questions to Ask Before Implementation

1. Does this serve the emotional intent?
2. Is the technical decision justified by the philosophy?
3. Are error messages actionable?
4. Does it follow established patterns?
5. Is it testable?
```

### **Step 4: Add Context Files**

Cursor reads these automatically:
- `.cursorrules` (project-specific rules)
- `README.md` (project overview)
- `.github/copilot-instructions.md` (if present)
- Open files in tabs (active context)

---

## 🎼 CURSOR AGENT WORKFLOWS

### **Workflow 1: Implement Complete MCP Tool**

**Task:** "Implement daiw_analyze_audio MCP tool"

**Using Agent Mode (Ctrl/Cmd + I):**

```
Prompt:
"Implement the daiw_analyze_audio MCP tool in daiw_mcp/tools/audio.py.

Requirements:
- Follow the pattern from daiw_mcp/tools/harmony.py
- Use Pydantic v2 for input validation
- Input: audio file path
- Output: JSON with tempo, key, frequency profile, dynamics
- Use music_brain/audio/analyzer.py for core logic
- Include actionable error messages
- Add to daiw_mcp/server.py imports

Also create tests in tests/test_mcp_audio.py."

Agent will:
1. ✅ Create daiw_mcp/tools/audio.py
2. ✅ Define Pydantic input model
3. ✅ Implement tool following harmony.py pattern
4. ✅ Add import to server.py
5. ✅ Create test file
6. ✅ Run tests to verify
```

**Result:** Complete implementation across 3 files in ~2 minutes

---

### **Workflow 2: Fix Bug Across Multiple Files**

**Task:** "Fix modal interchange detection bug"

**Using Agent Mode:**

```
Prompt:
"There's a bug in modal interchange detection. When analyzing 
F-C-Dm-Bbm in F major, it's not correctly identifying Bbm as 
borrowed from F minor.

Fix this bug. The issue is likely in:
- music_brain/diagnostics/chord_analyzer.py
- daiw_mcp/tools/harmony.py

Also update tests to catch this case."

Agent will:
1. ✅ Analyze chord_analyzer.py
2. ✅ Find the bug (likely in scale degree mapping)
3. ✅ Fix the logic
4. ✅ Update harmony.py if needed
5. ✅ Add test case for F-C-Dm-Bbm
6. ✅ Run tests to verify fix
```

---

### **Workflow 3: Refactor with Philosophy Alignment**

**Using Composer (Ctrl/Cmd + Shift + I):**

```
Prompt:
"Refactor the harmony generator to better align with 
'Interrogate Before Generate' philosophy.

Requirements:
- Add more detailed emotional interrogation
- Each chord choice should have explicit justification
- Add emotion_to_harmony_mapping.py module
- Update documentation to explain philosophy
- Keep Kelly song test passing

Show me all changes before applying."

Composer will:
1. Create emotion_to_harmony_mapping.py
2. Refactor harmony_generator.py
3. Update related docstrings
4. Update docs/philosophy.md
5. Show visual diff of all changes
6. You approve/reject each file
```

---

### **Workflow 4: Generate Complete Feature**

**Task:** "Implement bass line generator"

**Using Agent Mode:**

```
Prompt:
"Implement a bass line generator that creates bass lines from 
harmony progressions.

Spec:
- Location: music_brain/composition/bass_generator.py
- Input: HarmonyResult from harmony_generator.py
- Output: BassLine with MIDI notes
- Style: Follow chord roots with passing tones
- Options: walking, fingered, picked styles
- Generate MIDI file
- Add MCP tool: daiw_generate_bass_line
- Write comprehensive tests
- Document with examples

Use Kelly song (F-C-Dm-Bbm) as test case."

Agent will:
1. ✅ Create bass_generator.py with full implementation
2. ✅ Define BassLine data class
3. ✅ Implement style variations
4. ✅ Add MIDI generation
5. ✅ Create MCP tool wrapper
6. ✅ Write tests including Kelly song
7. ✅ Generate example documentation
8. ✅ Run all tests

Estimated time: 5-10 minutes
```

---

### **Workflow 5: Kelly Song Complete Generation**

**Using Agent Mode (Complex Multi-Step):**

```
Prompt:
"Generate the complete Kelly song package.

Context:
- Emotional intent: 'Grief disguised as love'
- Progression: F-C-Dm-Bbm (already validated)
- Tempo: 82 BPM, Key: F major
- Style: Lo-fi bedroom emo

Tasks:
1. Create examples/kelly_song/generate_complete.py
2. Use Phase 1 harmony generator (done)
3. Add bass line generator (if implemented)
4. Apply lo-fi groove (minimal, intensity=0.75)
5. Generate arrangement structure
6. Create production_guide.md with mix notes
7. Output multi-track MIDI to outputs/kelly_song_complete/
8. Test the complete workflow

Reference:
- Existing harmony: outputs/kelly_song_harmony.mid
- Groove templates: groove_templates/straight.json
- Production guides: vault/production/lofi_aesthetic.md"

Agent will:
1. ✅ Create complete generation script
2. ✅ Integrate all Phase 1 modules
3. ✅ Generate bass line
4. ✅ Apply groove humanization
5. ✅ Create arrangement structure
6. ✅ Write production guide
7. ✅ Generate all MIDI files
8. ✅ Test end-to-end workflow
9. ✅ Document the process

Estimated time: 10-15 minutes
```

---

## 🔧 CURSOR AGENT COMMANDS

### **Agent Mode Prompts:**

```
# Implement feature
"Implement [feature] in [file]. Requirements: [list]"

# Fix bug
"Fix bug in [file] where [description]. Also update tests."

# Refactor
"Refactor [module] to improve [aspect]. Keep tests passing."

# Add tests
"Add comprehensive tests for [module]. Cover success and error cases."

# Documentation
"Document [module] with usage examples and API reference."

# Terminal commands
"Run pytest and fix any failing tests."

# Dependencies
"Install [package] and integrate it into [module]."
```

### **Composer Prompts:**

```
# Multi-file edit
"Update all files that reference [old_name] to use [new_name]."

# Pattern application
"Apply [pattern] across all files in [directory]."

# Consistency check
"Ensure all error messages follow the actionable format."

# Documentation sync
"Update all docstrings to match current implementation."
```

### **Chat Prompts:**

```
# Understanding
"Explain how the harmony generator works."

# Planning
"How should I implement the arrangement generator?"

# Debugging
"Why is the modal interchange detection not working?"

# Best practices
"What's the best way to handle async file I/O here?"
```

---

## 📊 CURSOR PROJECT ORGANIZATION

### **Recommended Tab Layout:**

**Tab Group 1: Current Feature**
```
- File you're implementing
- Related pattern file
- Test file
- Documentation
```

**Tab Group 2: Context**
```
- .cursorrules
- README.md
- Phase plan (PHASE_1_SUMMARY.md)
- Kelly song example
```

**Tab Group 3: Testing**
```
- pytest output
- Test files
- Coverage report
```

---

## 🎯 ADVANCED CURSOR PATTERNS

### **Pattern 1: Test-Driven Development with Agent**

```
Step 1: Write test first
"""
def test_generate_bass_line_kelly_song():
    # Test implementation
    assert bass_line.notes[0] == "F2"  # Root of F chord
```

Step 2: Agent implements
Prompt: "Implement bass_generator.py to pass this test"

Step 3: Agent runs test
Terminal: pytest tests/test_bass_generator.py

Step 4: Agent fixes if needed
Agent iterates until test passes
```

### **Pattern 2: Iterative Refinement**

```
Round 1 - Basic Implementation:
Agent: "Implement basic audio analyzer"
→ Creates functional but simple version

Round 2 - Add Features:
You: "Add 8-band frequency analysis"
Agent: Updates existing file with new feature

Round 3 - Optimize:
You: "Optimize for large audio files"
Agent: Refactors for better performance

Round 4 - Polish:
You: "Add detailed logging and error handling"
Agent: Adds production-ready error handling
```

### **Pattern 3: Context Injection**

```
# Add critical files to context
Open in tabs:
1. .cursorrules (philosophy)
2. Pattern file (similar implementation)
3. Kelly song context (test case)
4. API docs (reference)

Then prompt:
"Implement [feature] following the patterns in these open files."

Agent has full context and follows established patterns.
```

### **Pattern 4: Agent as Pair Programmer**

```
You: Write skeleton
```python
class ArrangementGenerator:
    """Generate song arrangements."""
    
    def generate_from_intent(self, intent):
        # Agent, complete this
        pass
```

Agent: Ctrl/Cmd + I
"Complete this class following DAiW patterns. Include:
- Section generation (verse, chorus, bridge)
- Energy arc calculation
- Instrumentation planning
- Integration with Phase 1 harmony
- Tests with Kelly song example"

Agent fills in complete implementation
```

---

## 💡 PRACTICAL EXAMPLES

### **Example 1: Implement Audio Analysis MCP Tool**

**Files to open:**
```
1. daiw_mcp/tools/harmony.py (pattern)
2. music_brain/audio/analyzer.py (logic)
3. docs/mcp/MCP_IMPLEMENTATION_PLAN.md (spec)
```

**Agent Prompt:**
```
Implement daiw_analyze_audio MCP tool.

Pattern: Follow daiw_mcp/tools/harmony.py exactly
Logic: Use music_brain/audio/analyzer.py
Spec: See MCP_IMPLEMENTATION_PLAN.md section on audio tools

Input model:
- audio_file: str (path to audio file)

Output JSON:
- tempo_bpm: float
- key: str
- frequency_profile: dict (8-band)
- dynamic_range_db: float

Also:
- Add to daiw_mcp/server.py imports
- Create tests in tests/test_mcp_audio.py
- Run tests to verify
```

**Result:** Complete implementation in ~3 minutes

---

### **Example 2: Kelly Song Complete Package**

**Context files to open:**
```
1. examples/kelly_song_example.py (existing)
2. outputs/kelly_song_harmony.mid (harmony)
3. vault/production/lofi_aesthetic.md (production)
4. groove_templates/straight.json (groove)
```

**Agent Prompt:**
```
Create complete Kelly song generation pipeline.

Task: Create examples/kelly_song/generate_complete.py

Pipeline:
1. Load kelly_intent (grief disguised as love)
2. Generate harmony: F-C-Dm-Bbm (use existing)
3. Generate bass line (root movement, fingered style)
4. Apply lo-fi groove (straight, intensity=0.75)
5. Create arrangement structure (verse-chorus-verse-chorus-bridge-chorus)
6. Generate multi-track MIDI
7. Create production_guide.md with:
   - Frequency balance recommendations
   - Dynamic range targets
   - Effect suggestions
   - Section-by-section notes

Output to: outputs/kelly_song_complete/
- harmony.mid
- bass.mid
- drums.mid
- arrangement.json
- production_guide.md

Test the complete pipeline and fix any errors.
```

**Result:** Complete song package in ~10 minutes

---

### **Example 3: Refactor for Philosophy Alignment**

**Agent Prompt:**
```
Audit music_brain/harmony/harmony_generator.py for philosophy alignment.

Check for:
1. Are emotional justifications explicit for each chord choice?
2. Is "Interrogate Before Generate" evident in the code?
3. Are rule-breaking decisions clearly documented?
4. Do error messages guide users emotionally?

Refactor to improve:
- Add emotional_justification field to every chord decision
- Create interrogation_log in generation process
- Make rule-breaking more explicit in output
- Improve error messages to reference emotional context

Keep all tests passing, especially Kelly song test.
Update documentation to explain improvements.
```

**Result:** Philosophy-aligned refactoring in ~5 minutes

---

## 🚀 CURSOR VS OTHER AI TOOLS

### **Comparison:**

```
Cursor Agent:
- Autonomous multi-file edits
- Runs terminal commands
- Iterative until success
- Best for: Implementation, refactoring

GitHub Copilot:
- Inline suggestions
- You control every change
- Single-file focus
- Best for: Writing code, completion

Claude (Chat):
- Design and architecture
- Complex problem solving
- Documentation
- Best for: Planning, integration

Gemini:
- Research and analysis
- Performance optimization
- Comparison studies
- Best for: Research, benchmarking

ChatGPT:
- Testing and tutorials
- Documentation generation
- Quick reference
- Best for: Tests, docs, learning
```

### **Optimal Workflow:**

```
Step 1: Claude - Design & Architecture
"Design the arrangement generator module"

Step 2: Gemini - Research
"Research best practices for energy arc calculation"

Step 3: Cursor Agent - Implementation
"Implement arrangement generator following design"

Step 4: Cursor Agent - Testing
"Add comprehensive tests, run them, fix failures"

Step 5: ChatGPT - Documentation
"Generate API documentation and usage examples"

Step 6: Claude - Integration Review
"Review implementation for philosophy alignment"
```

---

## 🔒 CURSOR AGENT SAFETY

### **Best Practices:**

**1. Always Review Changes**
```
# Before accepting agent changes:
1. Read the diff carefully
2. Check for unintended modifications
3. Ensure tests pass
4. Verify philosophy alignment
```

**2. Use Composer for Risky Operations**
```
# Composer shows all changes before applying
# Use for:
- Large refactors
- Multi-file renames
- Pattern applications
- Anything affecting >5 files
```

**3. Commit Frequently**
```bash
# Before agent session
git commit -m "Before agent: [task description]"

# After agent session
git add -p  # Review each change
git commit -m "After agent: [what was implemented]"
```

**4. Test-Driven Development**
```
# Write tests first
# Agent implements to pass tests
# Tests ensure correctness
```

---

## 📈 CURSOR PRODUCTIVITY METRICS

### **Expected Improvements:**

```
Implementation Speed:
- Simple feature: 10 min → 2 min (5x faster)
- Complex feature: 2 hours → 20 min (6x faster)
- Bug fix: 30 min → 5 min (6x faster)
- Refactor: 1 hour → 10 min (6x faster)

Quality Improvements:
- Consistent patterns (100% vs ~80% manual)
- Complete test coverage (auto-generated)
- Better error handling (always included)
- Documentation currency (updated with code)

Context Retention:
- Philosophy maintained automatically
- Patterns followed consistently
- Kelly song context always available
- No context re-explanation needed
```

---

## 🎼 KELLY SONG WORKFLOW

### **Complete Kelly Song with Cursor Agent:**

**Session 1: Harmony (Complete ✅)**
```
Already done in Phase 1:
- F-C-Dm-Bbm validated
- Modal interchange applied
- MIDI file generated
```

**Session 2: Bass Line (5 min)**
```
Agent Prompt:
"Generate bass line for Kelly song (F-C-Dm-Bbm).
Style: fingered, follow roots with passing tones.
Output: outputs/kelly_song_complete/bass.mid"
```

**Session 3: Drums (5 min)**
```
Agent Prompt:
"Create drum pattern for Kelly song.
Style: lo-fi, minimal, intimate feel
Apply straight groove, intensity=0.75
Output: outputs/kelly_song_complete/drums.mid"
```

**Session 4: Arrangement (10 min)**
```
Agent Prompt:
"Create arrangement structure for Kelly song.
Structure: verse-verse-chorus-verse-chorus-bridge-chorus
Duration: ~3 minutes
Energy arc: intimate → building → climax → resolution
Output: outputs/kelly_song_complete/arrangement.json"
```

**Session 5: Production Guide (5 min)**
```
Agent Prompt:
"Create production guide for Kelly song.
Based on Elliott Smith / Bon Iver lo-fi aesthetic.
Include:
- Frequency balance targets
- Dynamic range recommendations
- Effect suggestions
- Section-by-section mix notes
Output: outputs/kelly_song_complete/production_guide.md"
```

**Total Time: ~25 minutes**
**Output: Complete song package ready for recording**

---

## ✅ CURSOR SETUP CHECKLIST

### **Initial Setup:**
- [ ] Install Cursor from cursor.sh
- [ ] Open DAiW project in Cursor
- [ ] Create `.cursorrules` file (copy from guide)
- [ ] Test Agent mode (Ctrl/Cmd + I)
- [ ] Test Composer (Ctrl/Cmd + Shift + I)

### **Project Configuration:**
- [ ] Add `.cursorrules` to version control
- [ ] Ensure README.md is current
- [ ] Copy copilot-instructions.md to .github/ (optional)
- [ ] Open key context files in tabs

### **First Agent Task:**
- [ ] Choose simple task (e.g., add docstring)
- [ ] Test agent mode
- [ ] Review changes carefully
- [ ] Commit if satisfied
- [ ] Iterate with more complex tasks

---

## 🎯 CURSOR AGENT PROMPTING TIPS

### **Effective Prompts:**

**✅ Good:**
```
"Implement daiw_analyze_audio MCP tool in daiw_mcp/tools/audio.py.
Follow the pattern from tools/harmony.py.
Use Pydantic v2 validation.
Include tests and error handling."
```

**❌ Bad:**
```
"Make an audio tool"
```

### **Prompt Structure:**

```
1. Clear task description
2. File locations (specific paths)
3. Patterns to follow (reference files)
4. Requirements (bulleted list)
5. Expected output
6. Testing requirements
7. Documentation needs
```

### **Example:**

```
Implement [feature] in [file].

Pattern: Follow [reference_file]
Requirements:
- [Requirement 1]
- [Requirement 2]
- [Requirement 3]

Output: [description]

Also:
- Add tests in [test_file]
- Update documentation in [doc_file]
- Run tests to verify
```

---

## 🔥 THE CURSOR ADVANTAGE

**For DAiW Development:**

```
Traditional:
- Design: 30 min (Claude)
- Implementation: 2 hours (manual)
- Testing: 30 min (manual)
- Documentation: 20 min (manual)
Total: ~3.5 hours

With Cursor Agent:
- Design: 30 min (Claude)
- Implementation: 10 min (Cursor Agent)
- Testing: 5 min (Cursor Agent)
- Documentation: 5 min (Cursor Agent)
Total: ~50 minutes

Time saved: 2.5 hours (70% reduction)
```

**Quality Improvements:**
- Consistent pattern following
- Complete test coverage
- Documentation always current
- Philosophy maintained
- Kelly song context preserved

---

## ✨ NEXT STEPS

### **Today:**
1. Install Cursor
2. Create `.cursorrules` file
3. Open DAiW in Cursor
4. Test Agent with simple task

### **This Week:**
1. Implement 2-3 features with Agent
2. Measure time savings
3. Refine `.cursorrules`
4. Document workflows

### **Ongoing:**
1. Use Agent for all implementations
2. Keep `.cursorrules` current
3. Track productivity gains
4. Share successful patterns

---

*"From manual coding to autonomous agents - Cursor makes DAiW development 6x faster."*

Ready to enable Cursor agents? 🚀
