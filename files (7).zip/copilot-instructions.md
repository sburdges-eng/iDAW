# DAiW Project Context for GitHub Copilot

## Project Overview

**DAiW (Digital Audio intelligent Workstation / Deeply Abrasive idea Wrangler)** is an AI-powered music production system that translates psychological and emotional states into complete musical compositions.

### Core Philosophy: "Interrogate Before Generate"

DAiW operates as a "Creative Companion, Not a Factory" - deeply understanding emotional intent before creating music, making musicians braver rather than replacing their creativity.

## Current Status (November 2025)

- **Phase 1 (CLI):** 92% complete
- **Phase 2 (Audio Engine):** 5% complete  
- **Phase 3 (Desktop App):** Design phase
- **Phase 4 (DAW Integration):** Planning
- **MCP Integration:** 12% complete (3 tools working)

## Architecture

### Technology Stack
- **Language:** Python 3.12+
- **Audio:** librosa, aubio, mido
- **Validation:** Pydantic v2
- **AI Integration:** MCP (Model Context Protocol)
- **Testing:** pytest
- **Documentation:** Markdown (Obsidian-compatible)

### Project Structure
```
DAiW-Music-Brain/
├── music_brain/           # Core package
│   ├── harmony/          # Harmony generation (Phase 1 ✅)
│   ├── groove/           # Groove extraction/application (Phase 1 ✅)
│   ├── diagnostics/      # Chord analysis (Phase 1 ✅)
│   ├── audio/            # Audio analysis (Phase 2)
│   ├── arrangement/      # Arrangement generation (Phase 2)
│   └── composition/      # Complete composition (Phase 2)
├── daiw_mcp/            # MCP server
│   ├── server.py
│   ├── tools/
│   └── models/
├── vault/               # Music Brain Vault knowledge base
│   ├── rule_breaks/
│   ├── genre_templates/
│   └── production_guides/
├── tests/
├── docs/
└── examples/
```

## Core Principles

### 1. Interrogate Before Generate
- Deep emotional excavation before technical implementation
- Three-phase intent schema: Core Wound → Emotional Intent → Technical Constraints
- Every technical decision justified by emotional truth

### 2. Intentional Rule-Breaking
- Music theory violations must serve emotional authenticity
- "Wrong notes" work because they're meaningfully wrong
- Rule-breaking database documents masterpiece examples (Beethoven → Radiohead)

### 3. Imperfection as Authenticity
- Flaws serve authenticity in lo-fi genres
- Minimal groove = intimacy
- Raw, unpolished aesthetics preferred over technical perfection

### 4. Emotional Translation
- Complex emotional states → nuanced musical choices
- Modal interchange for "bittersweet darkness"
- Avoid tonic resolution for "unresolved yearning"

## Coding Standards

### Style Guidelines
- **Type hints:** Required for all function signatures
- **Docstrings:** Google format, include examples
- **Naming:** snake_case for functions/variables, PascalCase for classes
- **Line length:** Max 100 characters
- **Imports:** Standard library → Third-party → Local, alphabetically sorted

### Pydantic Patterns
```python
from pydantic import BaseModel, Field, ConfigDict, field_validator

class InputModel(BaseModel):
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra='forbid'
    )
    
    param: str = Field(
        ...,
        description="Clear description with examples",
        min_length=1,
        max_length=100
    )
    
    @field_validator('param')
    @classmethod
    def validate_param(cls, v: str) -> str:
        # Validation logic
        return v
```

### Error Handling
- **Always provide actionable error messages**
- Include suggestions for resolution
- Log context for debugging
- Never use bare `except:`

```python
try:
    result = risky_operation()
except SpecificError as e:
    raise ValueError(
        f"Operation failed: {e}. "
        "Suggestion: Check input parameters and try again."
    ) from e
```

### Async/Await
- Use for I/O operations (file, network, audio processing)
- Proper error handling in async context
- Type hints for async functions

```python
async def async_operation(param: str) -> dict:
    """Async operation with proper typing."""
    try:
        result = await some_async_call(param)
        return result
    except Exception as e:
        logger.error(f"Async operation failed: {e}")
        raise
```

## Key Concepts

### Complete Song Intent Schema
```python
CompleteSongIntent(
    core_wound: str,              # Emotional truth (e.g., "Finding someone after they left")
    emotional_intent: str,         # Transformation (e.g., "Grief disguised as love")
    technical_constraints: str,    # Music specs (e.g., "F major, 82 BPM, lo-fi")
    technical_rule_to_break: str   # Optional (e.g., "HARMONY_ModalInterchange")
)
```

### Rule-Breaking Categories
- `HARMONY_ModalInterchange` - Borrow chords from parallel mode
- `HARMONY_AvoidTonicResolution` - End on non-tonic for tension
- `HARMONY_ParallelMotion` - Power chords, parallel fifths
- `HARMONY_UnresolvedDissonance` - Monk-style wrong notes
- `PRODUCTION_BuriedVocals` - Vocals as texture, not clarity
- `PRODUCTION_PitchImperfection` - Intentional pitch variations

### Groove System
- **Extraction:** MIDI → timing deviations, swing %, velocity patterns
- **Application:** Genre templates → humanized MIDI
- **Templates:** funk, boom-bap, dilla, straight, trap
- **Intensity:** 0.0 (quantized) to 1.0 (full groove)

## MCP Integration

### Tool Naming
- Format: `daiw_action_target` (e.g., `daiw_generate_harmony`)
- Always include service context (not just `generate_harmony`)
- Snake_case for tool names

### Tool Structure
```python
@mcp.tool(
    name="daiw_tool_name",
    annotations={
        "title": "Human-Readable Title",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def tool_name(params: InputModel) -> str:
    """Clear description of what tool does.
    
    Include examples and expected behavior.
    
    Returns:
        str: JSON-formatted response
    """
    try:
        # Implementation
        return json.dumps({"status": "success", ...}, indent=2)
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
            "suggestion": "Actionable advice"
        }, indent=2)
```

## Kelly Song Reference Project

**Emotional Context:**
- Friend Kelly died by suicide 4 years ago
- Core wound: "Finding someone after they left"
- Emotional intent: "Grief disguised as love"
- Narrative: Misdirection - every line sounds like falling in love until final reveal

**Technical Specs:**
- Key: F major
- Tempo: 82 BPM
- Progression: F-C-Dm-Bbm
- Rule-breaking: Modal interchange (Bbm borrowed from F minor)
- Style: Lo-fi bedroom emo / confessional acoustic
- Production: Raw, minimal, intimate

**Why Bbm works:**
- Creates "bittersweet darkness, borrowed sadness"
- Tonal intrusion from F minor invading F major
- Like grief invading hope - harmonic misdirection matches narrative

## Test Case: Kelly Song Harmony
This is a canonical example for testing any harmony-related code:

```python
kelly_intent = CompleteSongIntent(
    core_wound="Finding someone after they left",
    emotional_intent="Grief disguised as love",
    technical_constraints="F major, 82 BPM, lo-fi",
    technical_rule_to_break="HARMONY_ModalInterchange"
)

# Expected output:
# Progression: F-C-Dm-Bbm
# Roman: I-V-vi-iv
# Justification: Bbm (borrowed from F minor) = "bittersweet darkness"
```

## Important Context Files

### Must-Read Documents
1. `/docs/phases/PHASE_1_SUMMARY.md` - Phase 1 complete implementation
2. `/docs/phases/PHASE_2_PLAN.md` - Audio engine roadmap
3. `/docs/mcp/MCP_IMPLEMENTATION_PLAN.md` - MCP server design
4. `/vault/rule_breaks/rule_breaking_masterpieces.md` - Rule-breaking database

### Pattern References
- `/music_brain/harmony/harmony_generator.py` - Harmony generation pattern
- `/music_brain/groove/groove_applicator.py` - Groove application pattern
- `/daiw_mcp/tools/harmony.py` - MCP tool pattern
- `/examples/kelly_song/kelly_song_example.py` - Complete workflow example

## Dependencies

### Core
```
mido>=1.3.0          # MIDI I/O
numpy>=1.24.0        # Numerical operations
pydantic>=2.0.0      # Data validation
```

### Audio (Phase 2)
```
librosa>=0.10.0      # Audio analysis
aubio>=0.4.9         # Pitch/beat detection
scipy>=1.10.0        # Signal processing
```

### MCP
```
mcp>=1.0.0          # MCP SDK
fastmcp>=2.0.0      # FastMCP framework
```

## Development Workflow

### Branch Strategy
- `main` - Stable releases
- `develop` - Integration branch
- `feature/*` - New features
- `mcp/*` - MCP tool development
- `phase-2/*` - Phase 2 audio work

### Commit Messages
```
feat(harmony): Add modal interchange detection
fix(groove): Correct swing percentage calculation
docs(mcp): Update tool usage examples
test(audio): Add frequency analysis test cases
```

### Testing Requirements
- All new functions must have tests
- Minimum 80% code coverage
- Tests for success and error cases
- Integration tests for multi-module features

## Common Patterns

### File I/O
```python
from pathlib import Path

def read_file(filepath: str) -> str:
    """Read file with proper error handling."""
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(
            f"File not found: {filepath}. "
            f"Suggestion: Check file path and permissions."
        )
    return path.read_text()
```

### MIDI Operations
```python
import mido

def load_midi(filepath: str) -> mido.MidiFile:
    """Load MIDI file with validation."""
    try:
        midi = mido.MidiFile(filepath)
        return midi
    except Exception as e:
        raise ValueError(
            f"Failed to load MIDI: {e}. "
            f"Suggestion: Ensure file is valid MIDI format."
        ) from e
```

### JSON Responses (for MCP)
```python
import json

def success_response(data: dict) -> str:
    """Format success response."""
    return json.dumps({
        "status": "success",
        **data
    }, indent=2)

def error_response(error: str, suggestion: str) -> str:
    """Format error response."""
    return json.dumps({
        "status": "error",
        "error": error,
        "suggestion": suggestion
    }, indent=2)
```

## Anti-Patterns to Avoid

### ❌ Don't
- Over-engineer solutions
- Sacrifice emotional authenticity for technical perfection
- Apply rules without understanding their purpose
- Ignore error cases
- Write functions without docstrings
- Use magic numbers without explanation

### ✅ Do
- Keep it simple and clear
- Prioritize emotional truth
- Break rules intentionally with justification
- Handle errors gracefully with helpful messages
- Document why, not just what
- Use named constants

## Questions to Ask

When implementing new features:
1. **Does this serve the emotional intent?**
2. **Is the technical decision justified by the philosophy?**
3. **Are error messages actionable?**
4. **Does it follow established patterns?**
5. **Is it testable?**
6. **Will future maintainers understand why?**

## Current Priorities (November 2025)

1. **Complete Phase 1 CLI** (2 hours)
   - Add CLI wrapper commands
   - Expand test coverage
   
2. **Expand MCP Tools** (ongoing)
   - Add audio analysis tools
   - Add arrangement tools
   - Add complete composition tools

3. **Implement Phase 2 Core** (6-8 weeks)
   - Audio analysis engine
   - Arrangement generator
   - Complete composition pipeline

4. **Generate Kelly Song Complete Package**
   - Multi-track MIDI
   - Production guide
   - Ready for recording

## Success Metrics

**Code is successful when:**
- ✅ Emotional intent is preserved
- ✅ Philosophy is evident in implementation
- ✅ Errors are helpful and actionable
- ✅ Tests pass and cover edge cases
- ✅ Documentation is clear and complete
- ✅ Kelly song test case works correctly

---

**Remember:** DAiW is not about perfect music generation. It's about brave, authentic, emotionally-true musical expression supported by thoughtful technology.

*"Interrogate Before Generate - emotional truth drives musical choices."*
