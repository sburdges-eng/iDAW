"""
DAiW - Digital Audio Intimate Workstation
==========================================
Music Brain: The core engine for affect-driven composition.
"""

__version__ = "0.1.0"
