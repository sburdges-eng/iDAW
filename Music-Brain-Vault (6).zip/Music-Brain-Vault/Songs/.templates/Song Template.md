---
title: "{{title}}"
status: idea
key: 
bpm: 
time_signature: 4/4
created: {{date}}
modified: {{date}}
tags:
  - status/idea
---

# {{title}}

## Overview

**Key:** 
**BPM:** 
**Time Signature:** 4/4
**Duration:** 
**Genre/Style:** 

---

## Concept / Vision

*What is this song about? What feeling should it evoke?*



---

## Structure

| Section | Bars | Time | Notes |
|---------|------|------|-------|
| Intro | | | |
| Verse 1 | | | |
| Chorus | | | |
| Verse 2 | | | |
| Chorus | | | |
| Bridge | | | |
| Chorus | | | |
| Outro | | | |

---

## Chord Progression

### Verse
```
| | | | |
```

### Chorus
```
| | | | |
```

### Bridge
```
| | | | |
```

---

## Lyrics

### Verse 1
```

```

### Chorus
```

```

### Verse 2
```

```

### Bridge
```

```

---

## Instrumentation

| Track | Instrument/Sound | Notes |
|-------|------------------|-------|
| | | |
| | | |
| | | |

---

## Recording Notes

### Session Info
- **Date:** 
- **Location:** 
- **Interface:** PreSonus AudioBox iTwo
- **DAW:** Logic Pro

### Mic/DI Setup


### Takes & Comps


---

## Mixing Notes

### Gain Staging


### EQ Decisions


### Compression


### Effects (Reverb/Delay)


### Panning/Stereo Image


---

## Stems / File Inventory

| Stem | Filename | Notes |
|------|----------|-------|
| | | |
| | | |

**Project File Location:** 

---

## References

*Songs that inspired this or that I'm using as mix references:*

1. 
2. 
3. 

---

## Revision History

| Date | Changes |
|------|---------|
| {{date}} | Created |

---

## Related
- [[Workflows/]]
- [[Gear/]]

