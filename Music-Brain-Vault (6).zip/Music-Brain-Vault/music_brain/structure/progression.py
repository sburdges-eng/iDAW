"""
Progression Matcher
Match chord sequences against known progressions.
"""

from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass

from .chord import Chord, NOTE_NAMES


# Common progressions as scale degree sequences
# Degrees: 0=I, 2=ii, 4=iii, 5=IV, 7=V, 9=vi, 11=vii°
COMMON_PROGRESSIONS = {
    # Universal
    'I-IV-V-I': ([0, 5, 7, 0], ['rock', 'country', 'pop', 'folk']),
    'I-V-vi-IV': ([0, 7, 9, 5], ['pop', 'rock']),  # "Axis of Awesome"
    'I-vi-IV-V': ([0, 9, 5, 7], ['pop', 'doo-wop']),  # 50s progression
    'vi-IV-I-V': ([9, 5, 0, 7], ['pop']),  # Sensitive female chord progression
    'I-IV-vi-V': ([0, 5, 9, 7], ['pop', 'rock']),
    
    # Jazz
    'ii-V-I': ([2, 7, 0], ['jazz', 'r&b']),
    'I-vi-ii-V': ([0, 9, 2, 7], ['jazz']),  # Rhythm changes
    'iii-vi-ii-V': ([4, 9, 2, 7], ['jazz']),  # Circle of fifths
    'Imaj7-IV-iii-vi': ([0, 5, 4, 9], ['neo-soul', 'jazz']),
    
    # Blues
    '12-bar-blues': ([0, 0, 0, 0, 5, 5, 0, 0, 7, 5, 0, 7], ['blues', 'rock']),
    '8-bar-blues': ([0, 0, 5, 5, 0, 7, 0, 7], ['blues']),
    'minor-blues': ([0, 0, 0, 0, 5, 5, 0, 0, 8, 7, 0, 7], ['blues', 'jazz']),
    
    # Rock
    'I-bVII-IV': ([0, 10, 5], ['rock']),  # Mixolydian
    'I-bIII-IV': ([0, 3, 5], ['rock', 'grunge']),
    'i-bVI-bIII-bVII': ([0, 8, 3, 10], ['rock', 'metal']),  # Aeolian
    'I-V-IV': ([0, 7, 5], ['rock', 'punk']),
    
    # Minor
    'i-iv-v': ([0, 5, 7], ['rock', 'folk']),
    'i-bVII-bVI-bVII': ([0, 10, 8, 10], ['flamenco', 'rock']),  # Andalusian
    'i-bVI-bIII-bVII': ([0, 8, 3, 10], ['rock', 'pop']),
    'i-V-i': ([0, 7, 0], ['classical', 'metal']),
    
    # Modal
    'Dorian-vamp': ([0, 2], ['funk', 'jazz']),  # i-II
    'Mixolydian-vamp': ([0, 10], ['rock', 'folk']),  # I-bVII
    
    # EDM
    'EDM-minor': ([0, 8, 3, 10], ['edm', 'pop']),  # i-bVI-bIII-bVII
    'EDM-major': ([0, 7, 9, 5], ['edm', 'pop']),  # Same as axis
    
    # Gospel
    'gospel-turnaround': ([0, 0, 5, 5], ['gospel']),  # I-I7-IV-iv
}


@dataclass
class ProgressionMatch:
    """A matched progression pattern."""
    name: str
    degrees: List[int]
    genres: List[str]
    confidence: float
    start_bar: int
    length_bars: int
    transposition: int  # Semitones from original key


class ProgressionMatcher:
    """Match chord sequences against known patterns."""
    
    def __init__(self):
        self.patterns = COMMON_PROGRESSIONS
    
    def find_matches(self, chords: List[Chord], key_root: int = 0) -> List[ProgressionMatch]:
        """
        Find progression patterns in chord sequence.
        
        Args:
            chords: List of detected chords
            key_root: Root of the key (0-11), or None to auto-detect
        
        Returns:
            List of matched progressions
        """
        if len(chords) < 2:
            return []
        
        # Convert chords to degree sequence
        degrees = [(c.root - key_root) % 12 for c in chords]
        
        matches = []
        
        # Try each pattern at each position
        for name, (pattern, genres) in self.patterns.items():
            pattern_len = len(pattern)
            
            for start_idx in range(len(degrees) - pattern_len + 1):
                segment = degrees[start_idx:start_idx + pattern_len]
                
                # Check for exact match
                if segment == pattern:
                    match = ProgressionMatch(
                        name=name,
                        degrees=pattern,
                        genres=genres,
                        confidence=1.0,
                        start_bar=chords[start_idx].bar,
                        length_bars=pattern_len,
                        transposition=0
                    )
                    matches.append(match)
                    continue
                
                # Check for transposed match
                for trans in range(1, 12):
                    transposed = [(d + trans) % 12 for d in pattern]
                    if segment == transposed:
                        match = ProgressionMatch(
                            name=name,
                            degrees=pattern,
                            genres=genres,
                            confidence=0.9,  # Slightly lower for transposed
                            start_bar=chords[start_idx].bar,
                            length_bars=pattern_len,
                            transposition=trans
                        )
                        matches.append(match)
                        break
        
        return matches
    
    def find_recurring_patterns(self, chords: List[Chord], min_length: int = 2, min_occurrences: int = 2) -> Dict[str, List[int]]:
        """
        Find patterns that repeat within the chord sequence.
        
        Args:
            chords: List of detected chords
            min_length: Minimum pattern length
            min_occurrences: Minimum times pattern must appear
        
        Returns:
            Dict of pattern string -> list of starting bar indices
        """
        if len(chords) < min_length:
            return {}
        
        patterns = {}
        
        # Convert to degree string for comparison
        degrees = [c.root for c in chords]
        
        for length in range(min_length, len(degrees) // 2 + 1):
            for start in range(len(degrees) - length + 1):
                pattern = tuple(degrees[start:start + length])
                pattern_str = '-'.join(NOTE_NAMES[d] for d in pattern)
                
                if pattern_str not in patterns:
                    # Find all occurrences
                    occurrences = []
                    for i in range(len(degrees) - length + 1):
                        if tuple(degrees[i:i + length]) == pattern:
                            occurrences.append(chords[i].bar)
                    
                    if len(occurrences) >= min_occurrences:
                        patterns[pattern_str] = occurrences
        
        return patterns
    
    def suggest_progressions(self, genre: str) -> List[Tuple[str, List[int]]]:
        """
        Suggest common progressions for a genre.
        
        Args:
            genre: Genre name
        
        Returns:
            List of (name, degrees) tuples
        """
        suggestions = []
        
        for name, (degrees, genres) in self.patterns.items():
            if genre.lower() in [g.lower() for g in genres]:
                suggestions.append((name, degrees))
        
        return suggestions
    
    def degrees_to_chords(self, degrees: List[int], key_root: int = 0, default_type: str = 'maj') -> List[str]:
        """
        Convert degree sequence to chord names.
        
        Args:
            degrees: List of scale degrees (semitones from root)
            key_root: Root note (0-11)
            default_type: Default chord type if not specified
        
        Returns:
            List of chord name strings
        """
        chord_names = []
        
        # Map degrees to typical chord types
        degree_types = {
            0: 'maj', 2: 'min', 4: 'min', 5: 'maj',
            7: 'maj', 9: 'min', 11: 'dim'
        }
        
        for degree in degrees:
            root = (key_root + degree) % 12
            root_name = NOTE_NAMES[root]
            
            chord_type = degree_types.get(degree, default_type)
            
            if chord_type == 'maj':
                chord_names.append(root_name)
            elif chord_type == 'min':
                chord_names.append(f"{root_name}m")
            elif chord_type == 'dim':
                chord_names.append(f"{root_name}dim")
            else:
                chord_names.append(f"{root_name}{chord_type}")
        
        return chord_names


def match_progressions(chords: List[Chord], key_root: int = 0) -> List[ProgressionMatch]:
    """Convenience function to find progression matches."""
    matcher = ProgressionMatcher()
    return matcher.find_matches(chords, key_root)
