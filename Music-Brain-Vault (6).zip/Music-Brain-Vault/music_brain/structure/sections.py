"""
Section Detector
Detect song sections (verse, chorus, etc.) from MIDI or audio.
"""

from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from collections import defaultdict

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False

from ..utils.midi_io import MidiData, MidiNote


@dataclass
class Section:
    """A detected song section."""
    name: str           # verse, chorus, bridge, intro, outro, etc.
    start_bar: int
    end_bar: int
    length_bars: int
    energy: float       # 0-1 relative energy level
    density: float      # Notes per beat
    characteristics: Dict[str, any]


class SectionDetector:
    """
    Detect sections in MIDI based on:
    - Note density changes
    - Energy (velocity) changes
    - Instrument presence changes
    - Pattern repetition
    """
    
    def __init__(self, ppq: int = 480, beats_per_bar: int = 4):
        self.ppq = ppq
        self.beats_per_bar = beats_per_bar
        self.ticks_per_bar = ppq * beats_per_bar
    
    def detect_sections(self, data: MidiData, min_section_bars: int = 4) -> List[Section]:
        """
        Detect sections from MIDI data.
        
        Args:
            data: MidiData object
            min_section_bars: Minimum bars for a section
        
        Returns:
            List of detected sections
        """
        notes = data.all_notes
        if not notes:
            return []
        
        # Get max bar
        max_tick = max(n.onset_ticks for n in notes)
        max_bar = int(max_tick / self.ticks_per_bar) + 1
        
        # Calculate per-bar metrics
        bar_metrics = self._calculate_bar_metrics(notes, max_bar)
        
        # Detect boundaries from metric changes
        boundaries = self._detect_boundaries(bar_metrics, min_section_bars)
        
        # Create sections
        sections = self._create_sections(boundaries, bar_metrics, max_bar)
        
        # Name sections based on characteristics
        sections = self._name_sections(sections)
        
        return sections
    
    def _calculate_bar_metrics(self, notes: List[MidiNote], max_bar: int) -> Dict[int, Dict]:
        """Calculate density, energy, etc. for each bar."""
        metrics = {}
        
        for bar in range(max_bar):
            bar_start = bar * self.ticks_per_bar
            bar_end = bar_start + self.ticks_per_bar
            
            # Get notes in this bar
            bar_notes = [n for n in notes 
                        if bar_start <= n.onset_ticks < bar_end]
            
            if bar_notes:
                # Density: notes per beat
                density = len(bar_notes) / self.beats_per_bar
                
                # Energy: average velocity
                if HAS_NUMPY:
                    energy = np.mean([n.velocity for n in bar_notes]) / 127
                else:
                    energy = sum(n.velocity for n in bar_notes) / (len(bar_notes) * 127)
                
                # Pitch range
                pitches = [n.pitch for n in bar_notes]
                pitch_range = max(pitches) - min(pitches)
                
                # Channel diversity (instrument count)
                channels = set(n.channel for n in bar_notes)
                
                # Drum presence
                has_drums = 9 in channels
            else:
                density = 0
                energy = 0
                pitch_range = 0
                channels = set()
                has_drums = False
            
            metrics[bar] = {
                'density': density,
                'energy': energy,
                'pitch_range': pitch_range,
                'channel_count': len(channels),
                'has_drums': has_drums,
                'note_count': len(bar_notes)
            }
        
        return metrics
    
    def _detect_boundaries(self, metrics: Dict[int, Dict], min_bars: int) -> List[int]:
        """Detect section boundaries from metric changes."""
        if len(metrics) < min_bars * 2:
            return [0, len(metrics)]
        
        boundaries = [0]  # Always start at 0
        
        bars = sorted(metrics.keys())
        
        # Calculate change score at each bar
        change_scores = {}
        window = 2  # Compare with previous 2 bars
        
        for i, bar in enumerate(bars[window:], start=window):
            prev_bars = bars[i-window:i]
            
            # Get average metrics for previous window
            if HAS_NUMPY:
                prev_density = np.mean([metrics[b]['density'] for b in prev_bars])
                prev_energy = np.mean([metrics[b]['energy'] for b in prev_bars])
            else:
                prev_density = sum(metrics[b]['density'] for b in prev_bars) / len(prev_bars)
                prev_energy = sum(metrics[b]['energy'] for b in prev_bars) / len(prev_bars)
            
            # Current metrics
            curr_density = metrics[bar]['density']
            curr_energy = metrics[bar]['energy']
            
            # Calculate change magnitude
            density_change = abs(curr_density - prev_density) / (prev_density + 0.1)
            energy_change = abs(curr_energy - prev_energy) / (prev_energy + 0.1)
            
            # Combined change score
            change_score = density_change * 0.5 + energy_change * 0.5
            
            # Check for drum presence change
            prev_drums = any(metrics[b]['has_drums'] for b in prev_bars)
            curr_drums = metrics[bar]['has_drums']
            if prev_drums != curr_drums:
                change_score += 0.5
            
            change_scores[bar] = change_score
        
        # Find peaks in change score
        if change_scores:
            if HAS_NUMPY:
                threshold = np.mean(list(change_scores.values())) + np.std(list(change_scores.values()))
            else:
                values = list(change_scores.values())
                mean_val = sum(values) / len(values)
                variance = sum((v - mean_val) ** 2 for v in values) / len(values)
                threshold = mean_val + variance ** 0.5
            
            for bar, score in change_scores.items():
                if score > threshold:
                    # Check minimum distance from last boundary
                    if bar - boundaries[-1] >= min_bars:
                        boundaries.append(bar)
        
        # Always include end
        boundaries.append(len(metrics))
        
        return sorted(set(boundaries))
    
    def _create_sections(self, boundaries: List[int], metrics: Dict[int, Dict], max_bar: int) -> List[Section]:
        """Create section objects from boundaries."""
        sections = []
        
        for i in range(len(boundaries) - 1):
            start = boundaries[i]
            end = boundaries[i + 1]
            length = end - start
            
            # Get average metrics for section
            section_metrics = [metrics.get(b, {}) for b in range(start, end)]
            
            if section_metrics:
                valid_metrics = [m for m in section_metrics if m]
                if valid_metrics:
                    if HAS_NUMPY:
                        avg_density = np.mean([m.get('density', 0) for m in valid_metrics])
                        avg_energy = np.mean([m.get('energy', 0) for m in valid_metrics])
                    else:
                        avg_density = sum(m.get('density', 0) for m in valid_metrics) / len(valid_metrics)
                        avg_energy = sum(m.get('energy', 0) for m in valid_metrics) / len(valid_metrics)
                    
                    has_drums = any(m.get('has_drums', False) for m in valid_metrics)
                else:
                    avg_density = 0
                    avg_energy = 0
                    has_drums = False
            else:
                avg_density = 0
                avg_energy = 0
                has_drums = False
            
            section = Section(
                name='section',  # Will be named later
                start_bar=start,
                end_bar=end,
                length_bars=length,
                energy=avg_energy,
                density=avg_density,
                characteristics={
                    'has_drums': has_drums,
                    'avg_density': avg_density,
                    'avg_energy': avg_energy
                }
            )
            sections.append(section)
        
        return sections
    
    def _name_sections(self, sections: List[Section]) -> List[Section]:
        """Assign names to sections based on characteristics and position."""
        if not sections:
            return []
        
        # Calculate relative energy levels
        if HAS_NUMPY:
            energies = np.array([s.energy for s in sections])
            densities = np.array([s.density for s in sections])
            max_energy = np.max(energies) if energies.size > 0 else 1
            max_density = np.max(densities) if densities.size > 0 else 1
        else:
            energies = [s.energy for s in sections]
            densities = [s.density for s in sections]
            max_energy = max(energies) if energies else 1
            max_density = max(densities) if densities else 1
        
        for i, section in enumerate(sections):
            # Normalize
            rel_energy = section.energy / max_energy if max_energy > 0 else 0
            rel_density = section.density / max_density if max_density > 0 else 0
            
            # Name based on position and characteristics
            if i == 0 and rel_energy < 0.5:
                section.name = 'intro'
            elif i == len(sections) - 1 and rel_energy < 0.5:
                section.name = 'outro'
            elif rel_energy > 0.7 and rel_density > 0.6:
                section.name = 'chorus'
            elif rel_energy < 0.4 and rel_density < 0.5:
                section.name = 'breakdown'
            elif rel_energy > 0.5:
                section.name = 'verse' if section.length_bars >= 8 else 'pre-chorus'
            else:
                section.name = 'bridge'
            
            # Check for repeats
            if i > 0:
                # If similar to a previous section, use same name with number
                for j, prev in enumerate(sections[:i]):
                    if (abs(section.energy - prev.energy) < 0.1 and 
                        abs(section.density - prev.density) < 0.2 and
                        section.length_bars == prev.length_bars):
                        section.name = prev.name
                        break
        
        return sections


def detect_sections(data: MidiData) -> List[Section]:
    """Convenience function to detect sections."""
    detector = SectionDetector(ppq=data.ppq)
    return detector.detect_sections(data)
