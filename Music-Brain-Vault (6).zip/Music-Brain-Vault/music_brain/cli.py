#!/usr/bin/env python3
"""
Music Brain CLI
Unified command-line interface for groove, structure, and audio analysis.

Usage:
    music-brain groove extract <file> [--genre=<g>] [--save]
    music-brain groove apply <file> <source> [--out=<o>] [--intensity=<i>]
    music-brain groove humanize <file> [--out=<o>] [--timing=<t>] [--velocity=<v>]
    music-brain groove genres
    music-brain groove templates [--genre=<g>]
    
    music-brain structure analyze <file> [--key=<k>]
    music-brain structure progressions <genre>
    
    music-brain sections <file>
    
    music-brain info <file>
"""

import argparse
import sys
import json
from pathlib import Path


def cmd_groove_extract(args):
    """Extract groove from MIDI file."""
    from .groove.extractor import GrooveExtractor
    from .groove.templates import TemplateStorage
    
    extractor = GrooveExtractor()
    template = extractor.extract(args.file, genre=args.genre)
    
    print(f"\n{'='*60}")
    print(f"Groove Extracted: {Path(args.file).name}")
    print(f"{'='*60}")
    print(f"BPM: {template.bpm:.1f}")
    print(f"Bars analyzed: {template.bars_analyzed}")
    print(f"Notes: {template.notes_analyzed}")
    print(f"Swing: {template.swing:.2f} ({'straight' if template.swing < 0.52 else 'shuffled' if template.swing < 0.6 else 'swung'})")
    
    print(f"\nPush/Pull Offsets (ticks from grid):")
    for inst, positions in template.push_pull.items():
        if positions:
            avg_offset = sum(positions.values()) / len(positions)
            direction = "behind" if avg_offset > 0 else "ahead" if avg_offset < 0 else "on grid"
            print(f"  {inst}: {avg_offset:+.1f} ({direction})")
    
    print(f"\nInstrument Stagger:")
    for (a, b), offset in template.stagger.items():
        direction = "after" if offset > 0 else "before"
        print(f"  {b} {direction} {a}: {abs(offset):.1f} ticks")
    
    if args.save and args.genre:
        storage = TemplateStorage()
        path = storage.save(args.genre, extractor.to_dict(template))
        print(f"\nSaved to: {path}")


def cmd_groove_apply(args):
    """Apply groove to MIDI file."""
    from .groove.applicator import apply_groove
    
    output = args.out or str(Path(args.file).stem) + '_grooved.mid'
    
    print(f"Applying groove from '{args.source}' to '{args.file}'...")
    print(f"Intensity: {args.intensity}")
    
    apply_groove(
        args.file,
        output,
        args.source,
        intensity=args.intensity
    )
    
    print(f"Saved: {output}")


def cmd_groove_humanize(args):
    """Apply basic humanization."""
    from .groove.applicator import GrooveApplicator
    
    output = args.out or str(Path(args.file).stem) + '_humanized.mid'
    
    print(f"Humanizing '{args.file}'...")
    print(f"Timing range: ±{args.timing} ticks")
    print(f"Velocity range: ±{args.velocity}")
    
    applicator = GrooveApplicator()
    applicator.humanize(args.file, output, args.timing, args.velocity)
    
    print(f"Saved: {output}")


def cmd_groove_genres(args):
    """List available genres."""
    from .groove.pocket_rules import GENRE_POCKETS
    
    print("\nAvailable Genre Pockets:")
    print("-" * 40)
    
    for genre, pocket in GENRE_POCKETS.items():
        swing = pocket.get('swing', 0.5)
        swing_desc = "straight" if swing < 0.52 else f"{swing:.0%} swing"
        bpm = pocket.get('bpm_range', (0, 0))
        
        print(f"  {genre:<12} {bpm[0]}-{bpm[1]} BPM, {swing_desc}")
        print(f"               {pocket.get('notes', '')[:50]}...")


def cmd_groove_templates(args):
    """List saved templates."""
    from .groove.templates import TemplateStorage
    
    storage = TemplateStorage()
    
    if args.genre:
        templates = storage.list_templates(args.genre)
        print(f"\nTemplates for '{args.genre}':")
        for t in templates:
            print(f"  {t.name}")
    else:
        genres = storage.list_genres()
        if genres:
            print("\nSaved template genres:")
            for g in genres:
                count = len(storage.list_templates(g))
                print(f"  {g}: {count} template(s)")
        else:
            print("\nNo templates saved yet.")
            print("Extract some grooves with: music-brain groove extract <file> --genre <name> --save")


def cmd_structure_analyze(args):
    """Analyze chord progressions."""
    from .utils.midi_io import load_midi
    from .structure.chord import ChordAnalyzer
    from .structure.progression import ProgressionMatcher
    
    print(f"\nAnalyzing: {args.file}")
    
    data = load_midi(args.file)
    
    # Detect chords
    analyzer = ChordAnalyzer(ppq=data.ppq)
    chords = analyzer.analyze(data.all_notes)
    
    print(f"\nChords detected: {len(chords)}")
    print("-" * 40)
    
    key_root = args.key if args.key is not None else 0
    
    for chord in chords[:20]:  # Show first 20
        roman = analyzer.to_roman_numeral(chord, key_root)
        print(f"  Bar {chord.bar:3d}, beat {chord.beat:.1f}: {chord.root_name}{chord.chord_type:<6} ({roman})")
    
    if len(chords) > 20:
        print(f"  ... and {len(chords) - 20} more")
    
    # Find progressions
    matcher = ProgressionMatcher()
    matches = matcher.find_matches(chords, key_root)
    
    if matches:
        print(f"\nProgression Matches:")
        print("-" * 40)
        for match in matches[:10]:
            print(f"  {match.name} at bar {match.start_bar} (confidence: {match.confidence:.0%})")
    
    # Find recurring patterns
    recurring = matcher.find_recurring_patterns(chords)
    if recurring:
        print(f"\nRecurring Patterns:")
        print("-" * 40)
        for pattern, locations in list(recurring.items())[:5]:
            print(f"  {pattern}: bars {locations}")


def cmd_structure_progressions(args):
    """Show common progressions for genre."""
    from .structure.progression import ProgressionMatcher
    
    matcher = ProgressionMatcher()
    suggestions = matcher.suggest_progressions(args.genre)
    
    print(f"\nCommon progressions for '{args.genre}':")
    print("-" * 40)
    
    for name, degrees in suggestions:
        chords = matcher.degrees_to_chords(degrees, key_root=0)
        print(f"  {name}")
        print(f"    {' - '.join(chords)}")


def cmd_sections(args):
    """Detect song sections."""
    from .utils.midi_io import load_midi
    from .structure.sections import SectionDetector
    
    print(f"\nAnalyzing sections: {args.file}")
    
    data = load_midi(args.file)
    detector = SectionDetector(ppq=data.ppq)
    sections = detector.detect_sections(data)
    
    print(f"\nSections detected: {len(sections)}")
    print("-" * 60)
    print(f"{'Section':<12} {'Bars':<12} {'Length':<8} {'Energy':<8} {'Density':<8}")
    print("-" * 60)
    
    for section in sections:
        bars = f"{section.start_bar}-{section.end_bar}"
        print(f"{section.name:<12} {bars:<12} {section.length_bars:<8} {section.energy:.2f}     {section.density:.1f}")


def cmd_info(args):
    """Show MIDI file info."""
    from .utils.midi_io import load_midi
    from .utils.instruments import classify_note, is_drum_channel, get_drum_category
    
    print(f"\nMIDI File Info: {args.file}")
    print("=" * 60)
    
    data = load_midi(args.file)
    
    print(f"PPQ: {data.ppq}")
    print(f"BPM: {data.bpm:.1f}")
    print(f"Time Signature: {data.time_signature[0]}/{data.time_signature[1]}")
    print(f"Tracks: {len(data.tracks)}")
    
    total_notes = len(data.all_notes)
    print(f"Total Notes: {total_notes}")
    
    if total_notes > 0:
        max_tick = max(n.onset_ticks for n in data.all_notes)
        bars = int(max_tick / data.ticks_per_bar) + 1
        print(f"Duration: {bars} bars ({max_tick / data.ppq:.1f} beats)")
        
        # Note distribution by instrument
        from collections import Counter
        instruments = Counter()
        
        for note in data.all_notes:
            if is_drum_channel(note.channel):
                inst = get_drum_category(note.pitch)
            else:
                inst = classify_note(note.channel, note.pitch)
            instruments[inst] += 1
        
        print(f"\nInstrument Distribution:")
        for inst, count in instruments.most_common(10):
            pct = count / total_notes * 100
            bar = '█' * int(pct / 5)
            print(f"  {inst:<12} {count:>5} ({pct:>5.1f}%) {bar}")
    
    print(f"\nTracks:")
    for track in data.tracks:
        note_count = len(track.notes)
        print(f"  [{track.index}] {track.name}: {note_count} notes")


def main():
    parser = argparse.ArgumentParser(
        description='Music Brain - Groove, Structure & Audio Analysis',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Groove commands
    groove_parser = subparsers.add_parser('groove', help='Groove extraction and application')
    groove_sub = groove_parser.add_subparsers(dest='groove_cmd')
    
    # groove extract
    extract_p = groove_sub.add_parser('extract', help='Extract groove from MIDI')
    extract_p.add_argument('file', help='MIDI file path')
    extract_p.add_argument('--genre', '-g', help='Genre tag')
    extract_p.add_argument('--save', '-s', action='store_true', help='Save to template storage')
    
    # groove apply
    apply_p = groove_sub.add_parser('apply', help='Apply groove to MIDI')
    apply_p.add_argument('file', help='MIDI file to modify')
    apply_p.add_argument('source', help='Genre name or template path')
    apply_p.add_argument('--out', '-o', help='Output path')
    apply_p.add_argument('--intensity', '-i', type=float, default=1.0, help='0.0-1.0')
    
    # groove humanize
    human_p = groove_sub.add_parser('humanize', help='Basic humanization')
    human_p.add_argument('file', help='MIDI file')
    human_p.add_argument('--out', '-o', help='Output path')
    human_p.add_argument('--timing', '-t', type=int, default=10, help='Timing range (ticks)')
    human_p.add_argument('--velocity', '-v', type=int, default=15, help='Velocity range')
    
    # groove genres
    groove_sub.add_parser('genres', help='List available genres')
    
    # groove templates
    templates_p = groove_sub.add_parser('templates', help='List saved templates')
    templates_p.add_argument('--genre', '-g', help='Filter by genre')
    
    # Structure commands
    struct_parser = subparsers.add_parser('structure', help='Harmonic/melodic analysis')
    struct_sub = struct_parser.add_subparsers(dest='struct_cmd')
    
    # structure analyze
    analyze_p = struct_sub.add_parser('analyze', help='Analyze chords and progressions')
    analyze_p.add_argument('file', help='MIDI file')
    analyze_p.add_argument('--key', '-k', type=int, default=0, help='Key root (0=C, 7=G)')
    
    # structure progressions
    prog_p = struct_sub.add_parser('progressions', help='Show common progressions')
    prog_p.add_argument('genre', help='Genre name')
    
    # Sections command
    sections_p = subparsers.add_parser('sections', help='Detect song sections')
    sections_p.add_argument('file', help='MIDI file')
    
    # Info command
    info_p = subparsers.add_parser('info', help='Show MIDI file info')
    info_p.add_argument('file', help='MIDI file')
    
    args = parser.parse_args()
    
    if args.command == 'groove':
        if args.groove_cmd == 'extract':
            cmd_groove_extract(args)
        elif args.groove_cmd == 'apply':
            cmd_groove_apply(args)
        elif args.groove_cmd == 'humanize':
            cmd_groove_humanize(args)
        elif args.groove_cmd == 'genres':
            cmd_groove_genres(args)
        elif args.groove_cmd == 'templates':
            cmd_groove_templates(args)
        else:
            groove_parser.print_help()
    
    elif args.command == 'structure':
        if args.struct_cmd == 'analyze':
            cmd_structure_analyze(args)
        elif args.struct_cmd == 'progressions':
            cmd_structure_progressions(args)
        else:
            struct_parser.print_help()
    
    elif args.command == 'sections':
        cmd_sections(args)
    
    elif args.command == 'info':
        cmd_info(args)
    
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
