"""
Music Brain
A complete music production analysis toolkit.

Modules:
- groove: Extract and apply groove/feel from MIDI
- structure: Chord, progression, and section analysis
- audio: Audio characteristics and mix fingerprinting
- utils: MIDI I/O, PPQ handling, instrument classification
"""

__version__ = '1.0.0'
__author__ = 'Sean'

from .groove.extractor import GrooveExtractor, extract_groove
from .groove.applicator import GrooveApplicator, apply_groove
from .groove.pocket_rules import GENRE_POCKETS, get_pocket, list_genres
from .groove.templates import TemplateStorage, TemplateMerger

from .structure.chord import ChordAnalyzer, analyze_chords
from .structure.progression import ProgressionMatcher, match_progressions
from .structure.sections import SectionDetector, detect_sections

from .utils.midi_io import load_midi, save_midi, MidiData, MidiNote
from .utils.ppq import STANDARD_PPQ, normalize_ticks, scale_ticks
from .utils.instruments import classify_note, get_drum_category

__all__ = [
    # Groove
    'GrooveExtractor',
    'extract_groove',
    'GrooveApplicator', 
    'apply_groove',
    'GENRE_POCKETS',
    'get_pocket',
    'list_genres',
    'TemplateStorage',
    'TemplateMerger',
    
    # Structure
    'ChordAnalyzer',
    'analyze_chords',
    'ProgressionMatcher',
    'match_progressions',
    'SectionDetector',
    'detect_sections',
    
    # Utils
    'load_midi',
    'save_midi',
    'MidiData',
    'MidiNote',
    'STANDARD_PPQ',
    'normalize_ticks',
    'scale_ticks',
    'classify_note',
    'get_drum_category',
]
