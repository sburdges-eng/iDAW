"""
Template Storage and Merging
Handles groove template persistence, versioning, and cross-template averaging.
"""

import os
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False

DEFAULT_STORAGE_PATH = Path.home() / ".music_brain" / "groove_templates"


class TemplateStorage:
    """
    Manages groove template storage with versioning.
    
    Structure:
        ~/.music_brain/groove_templates/
            hiphop/
                template_001.json
                template_002.json
                latest.json
            jazz/
                template_001.json
                latest.json
    """
    
    def __init__(self, base_path: Optional[Path] = None):
        self.base = Path(base_path) if base_path else DEFAULT_STORAGE_PATH
        self.base.mkdir(parents=True, exist_ok=True)
    
    def save(self, genre: str, template: dict, name: Optional[str] = None) -> Path:
        """
        Save a template for a genre.
        
        Args:
            genre: Genre name (lowercase)
            template: Template dict with timing_map, velocity_map, swing, etc.
            name: Optional custom name, otherwise auto-indexed
        
        Returns:
            Path to saved template
        """
        genre = genre.lower()
        genre_dir = self.base / genre
        genre_dir.mkdir(parents=True, exist_ok=True)
        
        # Add metadata
        template['_metadata'] = {
            'genre': genre,
            'saved_at': datetime.now().isoformat(),
            'version': self._get_next_version(genre_dir)
        }
        
        if name:
            filename = f"{name}.json"
        else:
            # Auto-index
            existing = list(genre_dir.glob("template_*.json"))
            index = len(existing) + 1
            filename = f"template_{index:03d}.json"
        
        filepath = genre_dir / filename
        
        with open(filepath, 'w') as f:
            json.dump(template, f, indent=2, default=self._json_serializer)
        
        # Update latest.json
        latest_path = genre_dir / "latest.json"
        with open(latest_path, 'w') as f:
            json.dump(template, f, indent=2, default=self._json_serializer)
        
        return filepath
    
    def load(self, genre: str, version: Optional[int] = None) -> Optional[dict]:
        """
        Load a template.
        
        Args:
            genre: Genre name
            version: Specific version number, or None for latest
        
        Returns:
            Template dict or None if not found
        """
        genre = genre.lower()
        genre_dir = self.base / genre
        
        if not genre_dir.exists():
            return None
        
        if version is not None:
            filepath = genre_dir / f"template_{version:03d}.json"
        else:
            filepath = genre_dir / "latest.json"
        
        if not filepath.exists():
            return None
        
        with open(filepath) as f:
            return json.load(f)
    
    def load_latest(self, genre: str) -> Optional[dict]:
        """Load the latest template for a genre."""
        return self.load(genre, version=None)
    
    def list_genres(self) -> List[str]:
        """List all genres with saved templates."""
        if not self.base.exists():
            return []
        return [d.name for d in self.base.iterdir() if d.is_dir()]
    
    def list_templates(self, genre: str) -> List[Path]:
        """List all templates for a genre."""
        genre_dir = self.base / genre.lower()
        if not genre_dir.exists():
            return []
        return sorted(genre_dir.glob("template_*.json"))
    
    def get_all_templates(self, genre: str) -> List[dict]:
        """Load all templates for a genre."""
        templates = []
        for path in self.list_templates(genre):
            with open(path) as f:
                templates.append(json.load(f))
        return templates
    
    def delete(self, genre: str, version: Optional[int] = None) -> bool:
        """Delete a template or entire genre folder."""
        genre_dir = self.base / genre.lower()
        
        if version is not None:
            filepath = genre_dir / f"template_{version:03d}.json"
            if filepath.exists():
                filepath.unlink()
                return True
            return False
        else:
            # Delete entire genre
            import shutil
            if genre_dir.exists():
                shutil.rmtree(genre_dir)
                return True
            return False
    
    def _get_next_version(self, genre_dir: Path) -> int:
        """Get next version number for a genre."""
        existing = list(genre_dir.glob("template_*.json"))
        return len(existing) + 1
    
    def _json_serializer(self, obj):
        """Handle numpy arrays and other special types."""
        if HAS_NUMPY and isinstance(obj, np.ndarray):
            return obj.tolist()
        if HAS_NUMPY and isinstance(obj, (np.int64, np.int32)):
            return int(obj)
        if HAS_NUMPY and isinstance(obj, (np.float64, np.float32)):
            return float(obj)
        raise TypeError(f"Object of type {type(obj)} is not JSON serializable")


class TemplateMerger:
    """
    Merge multiple templates into a statistically averaged template.
    Uses numpy for stable math when available.
    """
    
    def merge(self, templates: List[dict]) -> dict:
        """
        Merge multiple templates into one averaged template.
        
        Args:
            templates: List of template dicts
        
        Returns:
            Merged template with averaged values
        """
        if not templates:
            raise ValueError("No templates to merge")
        
        if len(templates) == 1:
            return templates[0].copy()
        
        merged = {}
        
        # Merge timing maps
        if 'timing_map' in templates[0]:
            merged['timing_map'] = self._merge_arrays(
                [t.get('timing_map', []) for t in templates]
            )
        
        # Merge velocity maps
        if 'velocity_map' in templates[0]:
            merged['velocity_map'] = self._merge_arrays(
                [t.get('velocity_map', []) for t in templates]
            )
        
        # Merge swing (weighted average)
        swings = [t.get('swing', 0.5) for t in templates]
        merged['swing'] = self._mean(swings)
        
        # Merge push_pull offsets
        if 'push_pull' in templates[0]:
            merged['push_pull'] = self._merge_dicts(
                [t.get('push_pull', {}) for t in templates]
            )
        
        # Merge velocity ranges
        if 'velocity_ranges' in templates[0]:
            merged['velocity_ranges'] = self._merge_velocity_ranges(
                [t.get('velocity_ranges', {}) for t in templates]
            )
        
        # Merge histograms
        if 'histogram' in templates[0]:
            merged['histogram'] = self._merge_arrays(
                [t.get('histogram', []) for t in templates]
            )
        
        # Add merge metadata
        merged['_metadata'] = {
            'merged_from': len(templates),
            'merged_at': datetime.now().isoformat()
        }
        
        return merged
    
    def _merge_arrays(self, arrays: List[list]) -> list:
        """Merge multiple arrays by averaging, handling different lengths."""
        if not arrays:
            return []
        
        # Filter empty arrays
        arrays = [a for a in arrays if a]
        if not arrays:
            return []
        
        # Normalize lengths
        max_len = max(len(a) for a in arrays)
        
        if HAS_NUMPY:
            # Pad shorter arrays with their mean
            normalized = []
            for arr in arrays:
                if len(arr) < max_len:
                    mean_val = np.mean(arr)
                    padded = list(arr) + [mean_val] * (max_len - len(arr))
                    normalized.append(padded)
                else:
                    normalized.append(arr)
            
            stacked = np.array(normalized)
            return np.mean(stacked, axis=0).tolist()
        else:
            # Pure Python fallback
            result = []
            for i in range(max_len):
                values = []
                for arr in arrays:
                    if i < len(arr):
                        values.append(arr[i])
                if values:
                    result.append(sum(values) / len(values))
            return result
    
    def _merge_dicts(self, dicts: List[dict]) -> dict:
        """Merge dicts by averaging numeric values."""
        if not dicts:
            return {}
        
        all_keys = set()
        for d in dicts:
            all_keys.update(d.keys())
        
        merged = {}
        for key in all_keys:
            values = [d.get(key) for d in dicts if key in d]
            if all(isinstance(v, (int, float)) for v in values):
                merged[key] = self._mean(values)
            elif values:
                merged[key] = values[0]  # Take first for non-numeric
        
        return merged
    
    def _merge_velocity_ranges(self, ranges_list: List[dict]) -> dict:
        """Merge velocity range dicts."""
        if not ranges_list:
            return {}
        
        all_instruments = set()
        for r in ranges_list:
            all_instruments.update(r.keys())
        
        merged = {}
        for inst in all_instruments:
            lows = []
            highs = []
            for r in ranges_list:
                if inst in r and isinstance(r[inst], (list, tuple)) and len(r[inst]) == 2:
                    lows.append(r[inst][0])
                    highs.append(r[inst][1])
            
            if lows and highs:
                merged[inst] = (
                    int(self._mean(lows)),
                    int(self._mean(highs))
                )
        
        return merged
    
    def _mean(self, values: list) -> float:
        """Calculate mean, using numpy if available."""
        if not values:
            return 0.0
        if HAS_NUMPY:
            return float(np.mean(values))
        return sum(values) / len(values)


def get_storage(path: Optional[Path] = None) -> TemplateStorage:
    """Get default template storage."""
    return TemplateStorage(path)


def get_merger() -> TemplateMerger:
    """Get template merger."""
    return TemplateMerger()
