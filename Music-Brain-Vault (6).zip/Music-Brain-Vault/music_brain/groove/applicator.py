"""
Groove Applicator
Apply groove templates to MIDI files with track-safe modification.

Features:
- Track-safe MIDI modification (preserves structure)
- Per-instrument timing application
- Beat-position-aware offsets
- PPQ scaling
- Swing application
- Intensity control
"""

import random
from pathlib import Path
from typing import Dict, Optional, Tuple
from dataclasses import dataclass

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False

from ..utils.midi_io import load_midi, save_midi, modify_notes_safe, MidiData, MidiNote
from ..utils.ppq import STANDARD_PPQ, grid_position, scale_ticks
from ..utils.instruments import classify_note, get_drum_category, is_drum_channel
from .templates import TemplateStorage
from .pocket_rules import get_pocket, get_push_pull, get_swing, get_velocity_range, scale_pocket_to_ppq


class GrooveApplicator:
    """
    Apply groove to MIDI files.
    """
    
    def __init__(self, randomness: float = 0.3):
        """
        Args:
            randomness: Amount of random variation (0-1)
        """
        self.randomness = randomness
    
    def apply_genre_pocket(
        self,
        input_path: str,
        output_path: str,
        genre: str,
        intensity: float = 1.0
    ) -> MidiData:
        """
        Apply pre-built genre pocket to MIDI file.
        
        Args:
            input_path: Source MIDI file
            output_path: Destination MIDI file
            genre: Genre name (e.g., 'hiphop', 'jazz')
            intensity: 0.0-1.0, how much to apply
        
        Returns:
            Modified MidiData
        """
        # Load MIDI with track preservation
        data = load_midi(input_path, normalize_ppq=True)
        
        # Get pocket rules and scale to file's PPQ
        pocket = get_pocket(genre)
        pocket = scale_pocket_to_ppq(pocket, data.ppq)
        
        swing = pocket.get('swing', 0.5)
        push_pull = pocket.get('push_pull', {})
        velocity_ranges = pocket.get('velocity', {})
        
        # Create modifier function
        def modify_note(note: MidiNote) -> MidiNote:
            # Get instrument type
            if is_drum_channel(note.channel):
                inst = get_drum_category(note.pitch)
            else:
                inst = classify_note(note.channel, note.pitch)
            
            # Get timing offset for this instrument
            offset = push_pull.get(inst, 0)
            
            # Get beat position (0-15 for 16th notes)
            beat_pos = grid_position(note.onset_ticks, data.ppq, 16)
            
            # Apply timing offset with intensity and randomness
            timing_offset = offset * intensity
            if self.randomness > 0:
                rand_range = abs(offset) * self.randomness if offset != 0 else 5
                timing_offset += random.gauss(0, rand_range)
            
            # Apply swing to off-beat positions (odd 8th notes)
            if swing > 0.5:
                eighth_pos = beat_pos // 2  # 0-7
                if eighth_pos % 2 == 1:  # Off-beat 8th notes
                    swing_offset = (swing - 0.5) * data.ppq * intensity
                    timing_offset += swing_offset
            
            # Calculate new onset (ensure non-negative)
            new_onset = max(0, int(note.onset_ticks + timing_offset))
            
            # Apply velocity modification
            vel_range = velocity_ranges.get(inst, (80, 110))
            target_vel = (vel_range[0] + vel_range[1]) // 2
            
            vel_diff = target_vel - note.velocity
            new_velocity = int(note.velocity + vel_diff * intensity * 0.5)
            
            # Add velocity randomness
            if self.randomness > 0:
                new_velocity += int(random.gauss(0, 8 * self.randomness))
            
            new_velocity = max(1, min(127, new_velocity))
            
            # Return modified note
            note.onset_ticks = new_onset
            note.velocity = new_velocity
            return note
        
        # Apply modifications safely
        modified = modify_notes_safe(data, modify_note)
        
        # Save result
        save_midi(modified, output_path)
        
        return modified
    
    def apply_template(
        self,
        input_path: str,
        output_path: str,
        template: dict,
        intensity: float = 1.0
    ) -> MidiData:
        """
        Apply extracted groove template to MIDI file.
        
        Args:
            input_path: Source MIDI file
            output_path: Destination MIDI file
            template: Template dict with timing_map, push_pull, swing, etc.
            intensity: 0.0-1.0
        
        Returns:
            Modified MidiData
        """
        data = load_midi(input_path, normalize_ppq=True)
        
        # Get template data
        template_ppq = template.get('ppq', STANDARD_PPQ)
        timing_map = template.get('timing_map', [])
        push_pull = template.get('push_pull', {})
        swing = template.get('swing', 0.5)
        velocity_map = template.get('velocity_map', [])
        velocity_curves = template.get('velocity_curves', {})
        
        # Scale timing values if PPQ differs
        ppq_scale = data.ppq / template_ppq if template_ppq != data.ppq else 1.0
        
        def modify_note(note: MidiNote) -> MidiNote:
            # Get instrument
            if is_drum_channel(note.channel):
                inst = get_drum_category(note.pitch)
            else:
                inst = classify_note(note.channel, note.pitch)
            
            # Get grid position
            grid_pos = grid_position(note.onset_ticks, data.ppq, 16)
            
            # Get timing offset from template
            inst_offsets = push_pull.get(inst, {})
            offset = inst_offsets.get(grid_pos, inst_offsets.get(str(grid_pos), 0))
            
            # Scale and apply offset
            scaled_offset = offset * ppq_scale * intensity
            if self.randomness > 0:
                scaled_offset += random.gauss(0, 5 * self.randomness)
            
            # Apply swing
            if swing > 0.5:
                eighth_pos = grid_pos // 2
                if eighth_pos % 2 == 1:
                    swing_offset = (swing - 0.5) * data.ppq * intensity
                    scaled_offset += swing_offset
            
            new_onset = max(0, int(note.onset_ticks + scaled_offset))
            
            # Apply velocity from template curves
            if inst in velocity_curves:
                curve = velocity_curves[inst]
                pos_key = grid_pos if grid_pos in curve else str(grid_pos)
                if pos_key in curve:
                    target_vel, _ = curve[pos_key]
                    vel_diff = target_vel - note.velocity
                    new_velocity = int(note.velocity + vel_diff * intensity * 0.7)
                else:
                    new_velocity = note.velocity
            elif velocity_map and len(velocity_map) > grid_pos:
                # Fall back to global velocity map
                target_vel = velocity_map[grid_pos % len(velocity_map)]
                vel_diff = target_vel - note.velocity
                new_velocity = int(note.velocity + vel_diff * intensity * 0.5)
            else:
                new_velocity = note.velocity
            
            if self.randomness > 0:
                new_velocity += int(random.gauss(0, 6 * self.randomness))
            
            new_velocity = max(1, min(127, new_velocity))
            
            note.onset_ticks = new_onset
            note.velocity = new_velocity
            return note
        
        modified = modify_notes_safe(data, modify_note)
        save_midi(modified, output_path)
        
        return modified
    
    def humanize(
        self,
        input_path: str,
        output_path: str,
        timing_range: int = 10,
        velocity_range: int = 15
    ) -> MidiData:
        """
        Apply basic humanization (random variation).
        
        Args:
            input_path: Source MIDI file
            output_path: Destination MIDI file
            timing_range: Max timing deviation in ticks
            velocity_range: Max velocity deviation
        
        Returns:
            Modified MidiData
        """
        data = load_midi(input_path, normalize_ppq=True)
        
        def modify_note(note: MidiNote) -> MidiNote:
            # Random timing offset (Gaussian distribution)
            timing_offset = int(random.gauss(0, timing_range / 2))
            new_onset = max(0, note.onset_ticks + timing_offset)
            
            # Random velocity offset
            vel_offset = int(random.gauss(0, velocity_range / 2))
            new_velocity = max(1, min(127, note.velocity + vel_offset))
            
            note.onset_ticks = new_onset
            note.velocity = new_velocity
            return note
        
        modified = modify_notes_safe(data, modify_note)
        save_midi(modified, output_path)
        
        return modified
    
    def apply_from_storage(
        self,
        input_path: str,
        output_path: str,
        genre: str,
        intensity: float = 1.0,
        version: Optional[int] = None
    ) -> MidiData:
        """
        Apply template from storage.
        
        Args:
            input_path: Source MIDI file
            output_path: Destination MIDI file
            genre: Genre name to load template for
            intensity: 0.0-1.0
            version: Specific version or None for latest
        
        Returns:
            Modified MidiData
        """
        storage = TemplateStorage()
        template = storage.load(genre, version)
        
        if template is None:
            raise ValueError(f"No template found for genre: {genre}")
        
        return self.apply_template(input_path, output_path, template, intensity)


def apply_groove(
    input_path: str,
    output_path: str,
    source: str,
    intensity: float = 1.0,
    randomness: float = 0.3
) -> MidiData:
    """
    Convenience function to apply groove.
    
    Args:
        input_path: Source MIDI
        output_path: Destination MIDI
        source: Genre name OR path to template JSON
        intensity: 0.0-1.0
        randomness: Amount of random variation
    
    Returns:
        Modified MidiData
    """
    applicator = GrooveApplicator(randomness=randomness)
    
    # Check if source is a file path or genre name
    source_path = Path(source)
    if source_path.exists() and source_path.suffix == '.json':
        import json
        with open(source_path) as f:
            template = json.load(f)
        return applicator.apply_template(input_path, output_path, template, intensity)
    else:
        # Try as genre name
        from .pocket_rules import GENRE_POCKETS
        if source.lower() in GENRE_POCKETS:
            return applicator.apply_genre_pocket(input_path, output_path, source, intensity)
        else:
            # Try loading from storage
            return applicator.apply_from_storage(input_path, output_path, source, intensity)
