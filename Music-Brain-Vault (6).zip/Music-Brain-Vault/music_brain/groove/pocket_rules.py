"""
Genre Pocket Rules
Pre-built timing, swing, and velocity templates for common genres.
All timing values in ticks at 480 PPQ (standard).
"""

# All values at 480 PPQ
STANDARD_PPQ = 480

GENRE_POCKETS = {
    'hiphop': {
        'name': 'Hip-Hop',
        'bpm_range': (85, 100),
        'swing': 0.58,  # 58% = noticeable swing
        'push_pull': {
            'kick': 0,        # Anchor - on the grid
            'snare': 15,      # Behind the beat - THE pocket
            'hihat': -5,      # Slightly ahead - drives the groove
            'bass': 12,       # With the snare
            'keys': 8,        # Relaxed
            'percussion': 5
        },
        'velocity': {
            'kick': (90, 115),
            'snare': (85, 110),
            'hihat': (60, 95),
            'bass': (80, 105)
        },
        'stagger': {
            ('kick', 'bass'): 5,    # Bass slightly after kick
            ('snare', 'bass'): -3   # Bass slightly before snare
        },
        'notes': 'Laid-back feel. Snare sits behind. Ghost notes common.'
    },
    
    'trap': {
        'name': 'Trap',
        'bpm_range': (130, 170),
        'swing': 0.52,  # Nearly straight
        'push_pull': {
            'kick': 0,
            'snare': 5,       # Slightly behind or on grid
            'hihat': 0,       # Tight - rolls are straight 16ths
            'bass': 0,        # 808 locked with kick
            'percussion': 0
        },
        'velocity': {
            'kick': (100, 127),   # Punchy
            'snare': (95, 120),
            'hihat': (50, 100),   # Wide range for rolls
            'bass': (100, 127)    # Hard 808s
        },
        'stagger': {},
        'notes': 'Tight and hard. Hi-hat rolls accelerate. Everything punchy.'
    },
    
    'rnb': {
        'name': 'R&B / Neo-Soul',
        'bpm_range': (65, 95),
        'swing': 0.62,  # Heavy swing
        'push_pull': {
            'kick': 5,        # Even kick is relaxed
            'snare': 20,      # Deep pocket
            'hihat': 5,       # Lazy
            'bass': 18,       # With snare
            'keys': 10,       # Rhodes sits back
            'percussion': 8
        },
        'velocity': {
            'kick': (75, 100),
            'snare': (70, 100),
            'hihat': (40, 80),    # Soft
            'bass': (70, 95)
        },
        'stagger': {
            ('kick', 'bass'): 8,
            ('snare', 'keys'): 5
        },
        'notes': 'Everything sits back. Heavy ghost notes. Smooth dynamics.'
    },
    
    'funk': {
        'name': 'Funk',
        'bpm_range': (95, 120),
        'swing': 0.54,  # Subtle swing
        'push_pull': {
            'kick': -3,       # Slightly ahead - driving
            'snare': 0,       # On the grid - the crack
            'hihat': -5,      # Ahead - pushes the groove
            'bass': -2,       # Tight with kick
            'guitar': 0,      # Staccato, on grid
            'keys': 0,
            'percussion': -3
        },
        'velocity': {
            'kick': (90, 115),
            'snare': (95, 120),   # Strong
            'hihat': (70, 100),
            'bass': (85, 110)
        },
        'stagger': {
            ('kick', 'bass'): 2
        },
        'notes': 'Tight and driving. Ghost notes critical. Syncopation king.'
    },
    
    'jazz': {
        'name': 'Jazz',
        'bpm_range': (120, 200),
        'swing': 0.66,  # Triplet feel
        'push_pull': {
            'kick': 5,        # Loose, conversational
            'snare': 8,       # Relaxed
            'hihat': 3,       # Ride leads time
            'bass': 3,        # Walking, behind ride
            'keys': 10,       # Conversational
            'cymbal': 0       # Ride is the anchor
        },
        'velocity': {
            'kick': (50, 85),     # Subtle
            'snare': (40, 90),    # Wide dynamic range
            'hihat': (45, 80),
            'bass': (65, 95)
        },
        'stagger': {
            ('cymbal', 'bass'): 5,
            ('cymbal', 'keys'): 8
        },
        'notes': 'Everything floats. Ride leads. Extreme dynamics.'
    },
    
    'rock': {
        'name': 'Rock',
        'bpm_range': (100, 140),
        'swing': 0.50,  # Straight
        'push_pull': {
            'kick': 0,        # Foundation
            'snare': 0,       # Tight
            'hihat': -3,      # Slight drive
            'bass': 0,        # Locked with kick
            'guitar': -5,     # Can push for energy
            'keys': 0
        },
        'velocity': {
            'kick': (95, 120),
            'snare': (100, 125),
            'hihat': (75, 105),
            'bass': (90, 115)
        },
        'stagger': {
            ('kick', 'bass'): 0
        },
        'notes': 'Tight and straight. Power from volume/attack not swing.'
    },
    
    'metal': {
        'name': 'Metal',
        'bpm_range': (120, 220),
        'swing': 0.50,  # Dead straight
        'push_pull': {
            'kick': 0,
            'snare': 0,
            'hihat': 0,
            'bass': 0,
            'guitar': 0,
            'keys': 0
        },
        'velocity': {
            'kick': (105, 127),
            'snare': (105, 127),
            'hihat': (90, 115),
            'bass': (100, 125)
        },
        'stagger': {},
        'notes': 'Machine-tight precision. Power from volume and precision.'
    },
    
    'reggae': {
        'name': 'Reggae',
        'bpm_range': (70, 90),
        'swing': 0.55,
        'push_pull': {
            'kick': 0,        # On beat 3
            'snare': 5,       # Rim click
            'hihat': 8,       # Lazy
            'bass': 10,       # Deep pocket
            'guitar': 0,      # Off-beat skank
            'keys': 5
        },
        'velocity': {
            'kick': (80, 105),
            'snare': (60, 85),
            'hihat': (50, 80),
            'bass': (85, 110)
        },
        'stagger': {},
        'notes': 'One drop feel. Bass leads melodically.'
    },
    
    'house': {
        'name': 'House',
        'bpm_range': (120, 130),
        'swing': 0.54,  # Subtle swing in hats
        'push_pull': {
            'kick': 0,        # Four-on-floor anchor
            'snare': 3,       # Clap slightly behind for groove
            'hihat': -3,      # Ahead - drives
            'bass': 0,        # Locked with kick
            'keys': 0,
            'percussion': 2
        },
        'velocity': {
            'kick': (100, 120),
            'snare': (90, 110),
            'hihat': (60, 95),
            'bass': (95, 115)
        },
        'stagger': {},
        'notes': 'Four-on-floor. Swing lives in the hats.'
    },
    
    'techno': {
        'name': 'Techno',
        'bpm_range': (125, 145),
        'swing': 0.50,  # Straight
        'push_pull': {
            'kick': 0,
            'snare': 0,
            'hihat': 0,
            'bass': 0,
            'percussion': 0
        },
        'velocity': {
            'kick': (100, 120),
            'snare': (90, 115),
            'hihat': (70, 100),
            'bass': (95, 115)
        },
        'stagger': {},
        'notes': 'Hypnotic. Groove from repetition not swing.'
    },
    
    'lofi': {
        'name': 'Lo-Fi',
        'bpm_range': (70, 90),
        'swing': 0.62,  # Heavy swing
        'push_pull': {
            'kick': 5,
            'snare': 20,      # Way behind - lazy pocket
            'hihat': 10,      # Lazy
            'bass': 15,       # Behind
            'keys': 12,       # Relaxed Rhodes
            'percussion': 10
        },
        'velocity': {
            'kick': (65, 90),
            'snare': (55, 85),
            'hihat': (40, 70),
            'bass': (60, 85)
        },
        'stagger': {
            ('kick', 'snare'): 10,
            ('kick', 'bass'): 8
        },
        'notes': 'Everything behind the beat. Muffled, warm, lazy.'
    },
    
    'gospel': {
        'name': 'Gospel',
        'bpm_range': (70, 130),
        'swing': 0.60,
        'push_pull': {
            'kick': 0,        # Foundation
            'snare': 10,      # Pocket
            'hihat': 5,       # Relaxed
            'bass': 8,        # With snare
            'keys': 5,        # Organ sits back
            'percussion': 5
        },
        'velocity': {
            'kick': (85, 115),
            'snare': (80, 115),
            'hihat': (60, 95),
            'bass': (80, 105)
        },
        'stagger': {},
        'notes': 'Heavy swing. Lots of fills and expression.'
    },
    
    'country': {
        'name': 'Country',
        'bpm_range': (100, 140),
        'swing': 0.52,  # Slight shuffle possible
        'push_pull': {
            'kick': 0,
            'snare': 0,       # Train beat
            'hihat': -2,      # Slightly ahead
            'bass': 0,        # With kick
            'guitar': 0,
            'keys': 0
        },
        'velocity': {
            'kick': (85, 110),
            'snare': (80, 110),
            'hihat': (65, 95),
            'bass': (80, 105)
        },
        'stagger': {},
        'notes': 'Train beat feel. Ghost notes on snare.'
    }
}


def get_pocket(genre: str) -> dict:
    """Get pocket rules for a genre."""
    return GENRE_POCKETS.get(genre.lower(), GENRE_POCKETS.get('rock'))


def list_genres() -> list:
    """List available genres."""
    return list(GENRE_POCKETS.keys())


def get_push_pull(genre: str, instrument: str) -> int:
    """Get push/pull offset for instrument in genre (ticks at 480 PPQ)."""
    pocket = get_pocket(genre)
    return pocket.get('push_pull', {}).get(instrument, 0)


def get_swing(genre: str) -> float:
    """Get swing ratio for genre (0.5 = straight, 0.66 = triplet)."""
    pocket = get_pocket(genre)
    return pocket.get('swing', 0.50)


def get_velocity_range(genre: str, instrument: str) -> tuple:
    """Get typical velocity range for instrument in genre."""
    pocket = get_pocket(genre)
    return pocket.get('velocity', {}).get(instrument, (80, 110))


def scale_pocket_to_ppq(pocket: dict, target_ppq: int) -> dict:
    """Scale all tick values in pocket to target PPQ."""
    if target_ppq == STANDARD_PPQ:
        return pocket
    
    scale = target_ppq / STANDARD_PPQ
    scaled = dict(pocket)
    
    # Scale push_pull
    if 'push_pull' in scaled:
        scaled['push_pull'] = {k: int(v * scale) for k, v in pocket['push_pull'].items()}
    
    # Scale stagger
    if 'stagger' in scaled:
        scaled['stagger'] = {k: int(v * scale) for k, v in pocket['stagger'].items()}
    
    return scaled
