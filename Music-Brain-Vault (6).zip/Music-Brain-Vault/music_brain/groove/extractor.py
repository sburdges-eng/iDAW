"""
Groove Extractor
Extracts timing feel, swing, and velocity patterns from MIDI files.

Features:
- Multi-bar histogram extraction
- Per-instrument timing analysis
- Real swing ratio calculation
- Velocity curves by beat position
- Cross-instrument stagger detection
"""

from pathlib import Path
from typing import Dict, List, Optional, Tuple
from collections import defaultdict
from dataclasses import dataclass
import math

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False

from ..utils.midi_io import load_midi, MidiData, MidiNote
from ..utils.ppq import STANDARD_PPQ, grid_position, quantize_to_grid, ticks_per_bar
from ..utils.instruments import classify_note, get_drum_category, is_drum_channel, get_groove_instruments
from .templates import TemplateStorage, TemplateMerger
from .pocket_rules import get_pocket, GENRE_POCKETS


@dataclass
class GrooveTemplate:
    """Complete groove template extracted from MIDI."""
    # Timing
    timing_map: List[float]         # 32-bin histogram of note density
    push_pull: Dict[str, Dict[int, float]]  # instrument -> {beat_pos: offset}
    swing: float                    # 0.5 = straight, 0.66 = triplet
    
    # Velocity
    velocity_map: List[float]       # Per-position velocity averages
    velocity_curves: Dict[str, Dict[int, Tuple[float, float]]]  # inst -> {pos: (mean, std)}
    
    # Instrument relationships
    stagger: Dict[Tuple[str, str], float]  # (inst_a, inst_b) -> offset
    
    # Metadata
    ppq: int
    bpm: float
    bars_analyzed: int
    notes_analyzed: int
    source_file: str


class GrooveExtractor:
    """
    Extract groove characteristics from MIDI files.
    """
    
    def __init__(self, subdivisions: int = 32, bars_to_analyze: int = 4):
        """
        Args:
            subdivisions: Grid resolution (32 = 32nd notes)
            bars_to_analyze: Number of bars for pattern averaging
        """
        self.subdivisions = subdivisions
        self.bars_to_analyze = bars_to_analyze
    
    def extract(self, filepath: str, genre: Optional[str] = None) -> GrooveTemplate:
        """
        Extract groove template from MIDI file.
        
        Args:
            filepath: Path to MIDI file
            genre: Optional genre tag for storage
        
        Returns:
            GrooveTemplate with all extracted data
        """
        # Load with PPQ normalization
        data = load_midi(filepath, normalize_ppq=True)
        
        notes = data.all_notes
        if not notes:
            raise ValueError("No notes found in MIDI file")
        
        ppq = data.ppq
        tpb = data.ticks_per_bar
        
        # Extract components
        timing_map = self._extract_timing_histogram(notes, tpb)
        push_pull = self._extract_push_pull(notes, ppq)
        swing = self._extract_swing(notes, ppq)
        velocity_map = self._extract_velocity_map(notes, tpb)
        velocity_curves = self._extract_velocity_curves(notes, ppq)
        stagger = self._extract_stagger(notes, ppq)
        
        # Calculate BPM from tempo
        bpm = data.bpm
        
        # Count bars
        max_tick = max(n.onset_ticks for n in notes)
        bars = int(max_tick / tpb) + 1
        
        return GrooveTemplate(
            timing_map=timing_map,
            push_pull=push_pull,
            swing=swing,
            velocity_map=velocity_map,
            velocity_curves=velocity_curves,
            stagger=stagger,
            ppq=ppq,
            bpm=bpm,
            bars_analyzed=bars,
            notes_analyzed=len(notes),
            source_file=str(filepath)
        )
    
    def _extract_timing_histogram(self, notes: List[MidiNote], ticks_per_bar: int) -> List[float]:
        """
        Extract multi-bar timing histogram.
        Shows note density at each grid position.
        """
        # Group notes by bar
        bars = defaultdict(list)
        for note in notes:
            bar_idx = int(note.onset_ticks / ticks_per_bar)
            local_pos = note.onset_ticks % ticks_per_bar
            bars[bar_idx].append(local_pos)
        
        # Build histogram for each bar
        histograms = []
        ticks_per_sub = ticks_per_bar / self.subdivisions
        
        for bar_idx in sorted(bars.keys())[:self.bars_to_analyze * 2]:  # Analyze more bars
            histogram = [0] * self.subdivisions
            for pos in bars[bar_idx]:
                bin_idx = int(pos / ticks_per_sub) % self.subdivisions
                histogram[bin_idx] += 1
            histograms.append(histogram)
        
        if not histograms:
            return [0.0] * self.subdivisions
        
        # Average across bars
        if HAS_NUMPY:
            avg = np.mean(histograms, axis=0)
            # Normalize to 0-1
            max_val = np.max(avg)
            if max_val > 0:
                avg = avg / max_val
            return avg.tolist()
        else:
            # Pure Python
            avg = []
            for i in range(self.subdivisions):
                vals = [h[i] for h in histograms]
                avg.append(sum(vals) / len(vals))
            max_val = max(avg) if avg else 1
            if max_val > 0:
                avg = [v / max_val for v in avg]
            return avg
    
    def _extract_push_pull(self, notes: List[MidiNote], ppq: int) -> Dict[str, Dict[int, float]]:
        """
        Extract per-instrument timing offsets from grid.
        Positive = behind the beat, Negative = ahead.
        """
        # Group by instrument and grid position
        offsets_by_inst = defaultdict(lambda: defaultdict(list))
        
        for note in notes:
            # Classify instrument
            if is_drum_channel(note.channel):
                inst = get_drum_category(note.pitch)
            else:
                inst = classify_note(note.channel, note.pitch)
            
            # Get grid position and offset
            quantized, offset = quantize_to_grid(note.onset_ticks, ppq, grid_size=16)
            grid_pos = grid_position(note.onset_ticks, ppq, subdivisions=16)
            
            offsets_by_inst[inst][grid_pos].append(offset)
        
        # Calculate mean offset per position
        push_pull = {}
        for inst, positions in offsets_by_inst.items():
            push_pull[inst] = {}
            for pos, offsets in positions.items():
                if offsets:
                    if HAS_NUMPY:
                        push_pull[inst][pos] = float(np.mean(offsets))
                    else:
                        push_pull[inst][pos] = sum(offsets) / len(offsets)
        
        return push_pull
    
    def _extract_swing(self, notes: List[MidiNote], ppq: int) -> float:
        """
        Extract swing ratio.
        
        Swing is measured as the ratio of time from downbeat to upbeat
        vs upbeat to next downbeat.
        
        0.50 = straight (equal spacing)
        0.66 = triplet feel (2:1 ratio)
        """
        # Get 8th note positions
        ticks_per_8th = ppq // 2
        
        # Find on-beat and off-beat notes
        on_beat_times = []  # Notes on 8th note downbeats (0, 2, 4, 6...)
        off_beat_times = []  # Notes on 8th note upbeats (1, 3, 5, 7...)
        
        for note in notes:
            # Position within quarter note
            pos_in_quarter = note.onset_ticks % ppq
            
            # Check if it's roughly on the 8th note grid
            if pos_in_quarter < ticks_per_8th * 0.2:
                # On the downbeat
                on_beat_times.append(note.onset_ticks)
            elif abs(pos_in_quarter - ticks_per_8th) < ticks_per_8th * 0.4:
                # On the upbeat (with tolerance for swing)
                off_beat_times.append(note.onset_ticks)
        
        if len(on_beat_times) < 2 or len(off_beat_times) < 2:
            return 0.50  # Not enough data, assume straight
        
        # Calculate average offset of upbeats from perfect 50%
        swing_ratios = []
        
        for off_time in off_beat_times:
            # Find surrounding on-beats
            prev_on = None
            next_on = None
            
            for on_time in on_beat_times:
                if on_time < off_time:
                    prev_on = on_time
                elif on_time > off_time and next_on is None:
                    next_on = on_time
                    break
            
            if prev_on is not None and next_on is not None:
                total_span = next_on - prev_on
                first_half = off_time - prev_on
                if total_span > 0:
                    ratio = first_half / total_span
                    # Clamp to reasonable range
                    if 0.4 <= ratio <= 0.75:
                        swing_ratios.append(ratio)
        
        if not swing_ratios:
            return 0.50
        
        if HAS_NUMPY:
            return float(np.mean(swing_ratios))
        return sum(swing_ratios) / len(swing_ratios)
    
    def _extract_velocity_map(self, notes: List[MidiNote], ticks_per_bar: int) -> List[float]:
        """Extract average velocity at each grid position."""
        velocities_by_pos = defaultdict(list)
        ticks_per_sub = ticks_per_bar / self.subdivisions
        
        for note in notes:
            pos_in_bar = note.onset_ticks % ticks_per_bar
            bin_idx = int(pos_in_bar / ticks_per_sub) % self.subdivisions
            velocities_by_pos[bin_idx].append(note.velocity)
        
        velocity_map = []
        for i in range(self.subdivisions):
            vels = velocities_by_pos.get(i, [64])  # Default 64
            if HAS_NUMPY:
                velocity_map.append(float(np.mean(vels)))
            else:
                velocity_map.append(sum(vels) / len(vels))
        
        return velocity_map
    
    def _extract_velocity_curves(self, notes: List[MidiNote], ppq: int) -> Dict[str, Dict[int, Tuple[float, float]]]:
        """Extract per-instrument velocity statistics by beat position."""
        vel_by_inst = defaultdict(lambda: defaultdict(list))
        
        for note in notes:
            if is_drum_channel(note.channel):
                inst = get_drum_category(note.pitch)
            else:
                inst = classify_note(note.channel, note.pitch)
            
            grid_pos = grid_position(note.onset_ticks, ppq, subdivisions=16)
            vel_by_inst[inst][grid_pos].append(note.velocity)
        
        curves = {}
        for inst, positions in vel_by_inst.items():
            curves[inst] = {}
            for pos, vels in positions.items():
                if vels:
                    if HAS_NUMPY:
                        mean = float(np.mean(vels))
                        std = float(np.std(vels))
                    else:
                        mean = sum(vels) / len(vels)
                        variance = sum((v - mean) ** 2 for v in vels) / len(vels)
                        std = math.sqrt(variance)
                    curves[inst][pos] = (mean, std)
        
        return curves
    
    def _extract_stagger(self, notes: List[MidiNote], ppq: int) -> Dict[Tuple[str, str], float]:
        """
        Extract timing relationships between instruments.
        Returns average offset between instrument pairs at shared grid positions.
        """
        # Group notes by grid position and instrument
        by_position = defaultdict(lambda: defaultdict(list))
        
        for note in notes:
            if is_drum_channel(note.channel):
                inst = get_drum_category(note.pitch)
            else:
                inst = classify_note(note.channel, note.pitch)
            
            # Coarse grid (quarter notes)
            grid_pos = note.onset_ticks // ppq
            by_position[grid_pos][inst].append(note.onset_ticks)
        
        # Calculate pairwise offsets
        groove_insts = get_groove_instruments()
        stagger = {}
        
        for inst_a in groove_insts:
            for inst_b in groove_insts:
                if inst_a >= inst_b:  # Skip self and duplicates
                    continue
                
                offsets = []
                for pos, inst_notes in by_position.items():
                    if inst_a in inst_notes and inst_b in inst_notes:
                        # Compare timing at shared positions
                        times_a = inst_notes[inst_a]
                        times_b = inst_notes[inst_b]
                        
                        if times_a and times_b:
                            if HAS_NUMPY:
                                avg_a = np.mean(times_a)
                                avg_b = np.mean(times_b)
                            else:
                                avg_a = sum(times_a) / len(times_a)
                                avg_b = sum(times_b) / len(times_b)
                            offsets.append(avg_b - avg_a)
                
                if offsets:
                    if HAS_NUMPY:
                        stagger[(inst_a, inst_b)] = float(np.mean(offsets))
                    else:
                        stagger[(inst_a, inst_b)] = sum(offsets) / len(offsets)
        
        return stagger
    
    def to_dict(self, template: GrooveTemplate) -> dict:
        """Convert template to serializable dict."""
        return {
            'timing_map': template.timing_map,
            'push_pull': template.push_pull,
            'swing': template.swing,
            'velocity_map': template.velocity_map,
            'velocity_curves': {
                inst: {str(pos): list(v) for pos, v in curves.items()}
                for inst, curves in template.velocity_curves.items()
            },
            'stagger': {
                f"{a}_{b}": v for (a, b), v in template.stagger.items()
            },
            'ppq': template.ppq,
            'bpm': template.bpm,
            'bars_analyzed': template.bars_analyzed,
            'notes_analyzed': template.notes_analyzed,
            'source_file': template.source_file
        }


def extract_groove(filepath: str, genre: Optional[str] = None, save: bool = True) -> GrooveTemplate:
    """
    Convenience function to extract and optionally save groove.
    
    Args:
        filepath: MIDI file path
        genre: Genre tag
        save: Whether to save to template storage
    
    Returns:
        Extracted groove template
    """
    extractor = GrooveExtractor()
    template = extractor.extract(filepath, genre)
    
    if save and genre:
        storage = TemplateStorage()
        storage.save(genre, extractor.to_dict(template))
    
    return template
