"""
Track-Safe MIDI I/O
Properly handles multi-track MIDI without destructive flattening.
Maintains track boundaries, controller curves, pitch bends, meta events.
"""

import mido
from typing import List, Tuple, Dict, Any, Optional
from dataclasses import dataclass, field
from .ppq import STANDARD_PPQ, normalize_ticks


@dataclass
class MidiNote:
    """Represents a single MIDI note with full context."""
    pitch: int
    velocity: int
    onset_ticks: int
    duration_ticks: int
    channel: int
    track_index: int
    # Computed fields
    onset_beats: float = 0.0
    onset_bars: float = 0.0
    grid_position: int = 0  # 0-15 for 16th notes


@dataclass
class MidiEvent:
    """Generic MIDI event with absolute timing."""
    abs_time: int
    message: Any
    track_index: int


@dataclass
class TrackData:
    """All events from a single track, with absolute timing."""
    index: int
    name: str
    events: List[MidiEvent] = field(default_factory=list)
    notes: List[MidiNote] = field(default_factory=list)


@dataclass
class MidiData:
    """Complete MIDI file data with track separation preserved."""
    ppq: int
    tracks: List[TrackData]
    tempo: int = 500000  # microseconds per beat (default 120 BPM)
    time_signature: Tuple[int, int] = (4, 4)
    
    @property
    def bpm(self) -> float:
        return 60_000_000 / self.tempo
    
    @property
    def all_notes(self) -> List[MidiNote]:
        """Get all notes across all tracks."""
        notes = []
        for track in self.tracks:
            notes.extend(track.notes)
        return sorted(notes, key=lambda n: n.onset_ticks)
    
    @property
    def ticks_per_bar(self) -> int:
        beats_per_bar = self.time_signature[0] * (4 / self.time_signature[1])
        return int(self.ppq * beats_per_bar)


def load_midi(filepath: str, normalize_ppq: bool = True) -> MidiData:
    """
    Load MIDI file preserving track structure.
    
    Args:
        filepath: Path to MIDI file
        normalize_ppq: If True, normalize all ticks to STANDARD_PPQ (480)
    
    Returns:
        MidiData with full track separation
    """
    mid = mido.MidiFile(filepath)
    source_ppq = mid.ticks_per_beat
    target_ppq = STANDARD_PPQ if normalize_ppq else source_ppq
    
    tracks = []
    tempo = 500000
    time_sig = (4, 4)
    
    for track_idx, track in enumerate(mid.tracks):
        track_data = TrackData(
            index=track_idx,
            name=track.name or f"Track {track_idx}"
        )
        
        abs_time = 0
        active_notes = {}  # (channel, pitch) -> (onset_time, velocity)
        
        for msg in track:
            # Convert delta to absolute
            abs_time += msg.time
            
            # Normalize if needed
            if normalize_ppq and source_ppq != target_ppq:
                norm_time = normalize_ticks(abs_time, source_ppq, target_ppq)
            else:
                norm_time = abs_time
            
            # Extract tempo and time signature
            if msg.type == 'set_tempo':
                tempo = msg.tempo
            elif msg.type == 'time_signature':
                time_sig = (msg.numerator, msg.denominator)
            
            # Store all events
            track_data.events.append(MidiEvent(
                abs_time=norm_time,
                message=msg.copy(),
                track_index=track_idx
            ))
            
            # Track note on/off for duration calculation
            if msg.type == 'note_on' and msg.velocity > 0:
                key = (msg.channel, msg.note)
                active_notes[key] = (norm_time, msg.velocity)
            
            elif msg.type == 'note_off' or (msg.type == 'note_on' and msg.velocity == 0):
                key = (msg.channel, msg.note)
                if key in active_notes:
                    onset, velocity = active_notes.pop(key)
                    duration = norm_time - onset
                    
                    # Calculate beat/bar positions
                    ppq = target_ppq
                    ticks_per_bar = ppq * 4  # Assuming 4/4 for now
                    
                    note = MidiNote(
                        pitch=msg.note,
                        velocity=velocity,
                        onset_ticks=onset,
                        duration_ticks=duration,
                        channel=msg.channel,
                        track_index=track_idx,
                        onset_beats=onset / ppq,
                        onset_bars=onset / ticks_per_bar,
                        grid_position=int((onset % ticks_per_bar) / (ticks_per_bar / 16)) % 16
                    )
                    track_data.notes.append(note)
        
        tracks.append(track_data)
    
    return MidiData(
        ppq=target_ppq,
        tracks=tracks,
        tempo=tempo,
        time_signature=time_sig
    )


def save_midi(data: MidiData, filepath: str, target_ppq: Optional[int] = None):
    """
    Save MidiData back to file, preserving track structure.
    
    Args:
        data: MidiData to save
        filepath: Output path
        target_ppq: Optional PPQ for output (scales if different)
    """
    out_ppq = target_ppq or data.ppq
    scale = out_ppq / data.ppq if target_ppq else 1.0
    
    mid = mido.MidiFile(ticks_per_beat=out_ppq)
    
    for track_data in data.tracks:
        track = mido.MidiTrack()
        track.name = track_data.name
        mid.tracks.append(track)
        
        # Sort events by absolute time
        sorted_events = sorted(track_data.events, key=lambda e: e.abs_time)
        
        # Convert back to delta time
        prev_time = 0
        for event in sorted_events:
            abs_t = int(event.abs_time * scale)
            delta = max(0, abs_t - prev_time)
            
            msg = event.message.copy()
            msg.time = delta
            track.append(msg)
            
            prev_time = abs_t
    
    mid.save(filepath)


def modify_notes_safe(data: MidiData, modifier_fn) -> MidiData:
    """
    Safely modify notes while preserving all other events.
    
    Args:
        data: Original MidiData
        modifier_fn: Function(note: MidiNote) -> MidiNote with modified timing/velocity
    
    Returns:
        New MidiData with modified notes
    """
    import copy
    new_data = copy.deepcopy(data)
    
    for track in new_data.tracks:
        # Build map of original note events
        note_on_events = {}
        note_off_events = {}
        
        for event in track.events:
            msg = event.message
            if msg.type == 'note_on' and msg.velocity > 0:
                key = (msg.channel, msg.note, event.abs_time)
                note_on_events[key] = event
            elif msg.type == 'note_off' or (msg.type == 'note_on' and msg.velocity == 0):
                key = (msg.channel, msg.note)
                # Match to most recent note_on
                for on_key in list(note_on_events.keys()):
                    if on_key[0] == key[0] and on_key[1] == key[1]:
                        note_off_events[(on_key, event.abs_time)] = event
        
        # Modify notes and update corresponding events
        for note in track.notes:
            original_onset = note.onset_ticks
            original_end = original_onset + note.duration_ticks
            original_velocity = note.velocity
            
            # Apply modification
            modified = modifier_fn(note)
            
            # Find and update the note_on event
            for event in track.events:
                msg = event.message
                if (msg.type == 'note_on' and 
                    msg.velocity > 0 and
                    msg.channel == note.channel and 
                    msg.note == note.pitch and
                    event.abs_time == original_onset):
                    
                    event.abs_time = modified.onset_ticks
                    msg.velocity = modified.velocity
                    break
            
            # Find and update the note_off event
            for event in track.events:
                msg = event.message
                if ((msg.type == 'note_off' or (msg.type == 'note_on' and msg.velocity == 0)) and
                    msg.channel == note.channel and 
                    msg.note == note.pitch and
                    abs(event.abs_time - original_end) < 10):  # Small tolerance
                    
                    event.abs_time = modified.onset_ticks + modified.duration_ticks
                    break
            
            # Update the note object
            note.onset_ticks = modified.onset_ticks
            note.duration_ticks = modified.duration_ticks
            note.velocity = modified.velocity
    
    return new_data


def get_notes_by_instrument(data: MidiData, instrument_type: str) -> List[MidiNote]:
    """Get notes filtered by instrument type."""
    from .instruments import classify_note
    
    result = []
    for note in data.all_notes:
        if classify_note(note.channel, note.pitch) == instrument_type:
            result.append(note)
    return result


def flatten_to_single_track(data: MidiData) -> MidiData:
    """
    Intentionally flatten to single track (for simple output).
    Use only when you explicitly want this behavior.
    """
    import copy
    
    all_events = []
    for track in data.tracks:
        all_events.extend(track.events)
    
    all_events.sort(key=lambda e: e.abs_time)
    
    # Reassign track indices
    for event in all_events:
        event.track_index = 0
    
    single_track = TrackData(
        index=0,
        name="Merged",
        events=all_events,
        notes=sorted(data.all_notes, key=lambda n: n.onset_ticks)
    )
    
    return MidiData(
        ppq=data.ppq,
        tracks=[single_track],
        tempo=data.tempo,
        time_signature=data.time_signature
    )
