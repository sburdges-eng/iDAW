"""
PPQ (Pulses Per Quarter Note) Utilities
Handles normalization and scaling between different MIDI resolutions.
"""

STANDARD_PPQ = 480  # Industry standard, what we normalize to


def normalize_ticks(ticks: int, source_ppq: int, target_ppq: int = STANDARD_PPQ) -> int:
    """Convert ticks from source PPQ to target PPQ."""
    if source_ppq == target_ppq:
        return ticks
    return int(ticks * target_ppq / source_ppq)


def scale_ticks(ticks: int, source_ppq: int, target_ppq: int) -> int:
    """Scale ticks between any two PPQ values."""
    if source_ppq == target_ppq:
        return ticks
    return int(ticks * target_ppq / source_ppq)


def ticks_per_bar(ppq: int, time_sig_numerator: int = 4, time_sig_denominator: int = 4) -> int:
    """Calculate ticks per bar given PPQ and time signature."""
    beats_per_bar = time_sig_numerator * (4 / time_sig_denominator)
    return int(ppq * beats_per_bar)


def ticks_to_beats(ticks: int, ppq: int) -> float:
    """Convert ticks to beat position."""
    return ticks / ppq


def beats_to_ticks(beats: float, ppq: int) -> int:
    """Convert beat position to ticks."""
    return int(beats * ppq)


def ticks_to_bars(ticks: int, ppq: int, beats_per_bar: int = 4) -> float:
    """Convert ticks to bar position (0-indexed)."""
    ticks_per_b = ppq * beats_per_bar
    return ticks / ticks_per_b


def grid_position(ticks: int, ppq: int, subdivisions: int = 16) -> int:
    """
    Get grid position within a bar (0 to subdivisions-1).
    Default 16 = 16th notes in 4/4.
    """
    ticks_per_bar_val = ppq * 4  # Assuming 4/4
    ticks_per_subdivision = ticks_per_bar_val / subdivisions
    position_in_bar = ticks % ticks_per_bar_val
    return int(position_in_bar / ticks_per_subdivision) % subdivisions


def scale_template(template: dict, source_ppq: int, target_ppq: int) -> dict:
    """
    Scale all tick-based values in a template from source to target PPQ.
    Critical for applying templates extracted at different resolutions.
    """
    if source_ppq == target_ppq:
        return template
    
    scale_factor = target_ppq / source_ppq
    scaled = {}
    
    for key, value in template.items():
        if key in ('push_pull', 'timing_offsets', 'stagger'):
            # These contain tick values that need scaling
            if isinstance(value, dict):
                scaled[key] = {}
                for k, v in value.items():
                    if isinstance(v, dict):
                        scaled[key][k] = {kk: int(vv * scale_factor) if isinstance(vv, (int, float)) else vv 
                                          for kk, vv in v.items()}
                    elif isinstance(v, (int, float)):
                        scaled[key][k] = int(v * scale_factor)
                    else:
                        scaled[key][k] = v
            else:
                scaled[key] = value
        elif key == 'ppq':
            scaled[key] = target_ppq
        else:
            scaled[key] = value
    
    return scaled


def quantize_to_grid(ticks: int, ppq: int, grid_size: int = 16) -> tuple:
    """
    Quantize tick position to nearest grid point.
    Returns (quantized_ticks, offset_from_grid).
    """
    ticks_per_bar_val = ppq * 4
    ticks_per_grid = ticks_per_bar_val / grid_size
    
    grid_index = round(ticks / ticks_per_grid)
    quantized = int(grid_index * ticks_per_grid)
    offset = ticks - quantized
    
    return quantized, offset
