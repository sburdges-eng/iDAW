---
title: "{{title}}"
type: workflow
created: {{date}}
tags:
  - workflow
---

# {{title}}

## Purpose

*What does this workflow accomplish?*

---

## When to Use

*What situations call for this workflow?*

---

## Prerequisites

- [ ] 
- [ ] 

---

## Steps

### 1. 

### 2. 

### 3. 

### 4. 

### 5. 

---

## Settings / Parameters

| Parameter | Value | Notes |
|-----------|-------|-------|
| | | |

---

## Tips

- 

---

## Common Issues

| Issue | Solution |
|-------|----------|
| | |

---

## Related
- [[]]

