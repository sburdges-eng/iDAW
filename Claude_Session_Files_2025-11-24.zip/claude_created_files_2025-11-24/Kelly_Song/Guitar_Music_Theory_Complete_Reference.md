# COMPREHENSIVE GUITAR MUSIC THEORY REFERENCE
## From Beginner to Advanced

---

# PART 1: OPEN CHORD SHAPES

## How to Read Chord Diagrams

- **Vertical lines** = Guitar strings (left to right: 6th/Low E to 1st/High E)
- **Horizontal lines** = Frets (top line = nut)
- **Dots** = Finger placement
- **X** = Do not play this string (mute)
- **O** = Play string open
- **Finger numbering**: 1=Index, 2=Middle, 3=Ring, 4=Pinky

---

## MAJOR OPEN CHORDS

### A Major
```
Frets:    X 0 2 2 2 0
Strings:  6 5 4 3 2 1 (Low E to High E)
```
- **String 5 (A)**: Open
- **String 4 (D)**: Fret 2 - Index finger (1)
- **String 3 (G)**: Fret 2 - Middle finger (2)
- **String 2 (B)**: Fret 2 - Ring finger (3)
- **String 1 (E)**: Open
- **String 6**: Muted (don't play)
- **Notes**: A - E - A - C# - E

### B Major (Barre Chord)
```
Frets:    X 2 4 4 4 2
Strings:  6 5 4 3 2 1
```
- **Index finger**: Barre strings 5, 2, 1 at fret 2
- **Ring finger**: Barre or stack strings 4, 3, 2 at fret 4
- **Notes**: B - F# - B - D# - F#

### C Major
```
Frets:    X 3 2 0 1 0
Strings:  6 5 4 3 2 1
```
- **String 5 (A)**: Fret 3 - Ring finger (3)
- **String 4 (D)**: Fret 2 - Middle finger (2)
- **String 3 (G)**: Open
- **String 2 (B)**: Fret 1 - Index finger (1)
- **String 1 (E)**: Open
- **String 6**: Muted
- **Notes**: C - E - G - C - E

### D Major
```
Frets:    X X 0 2 3 2
Strings:  6 5 4 3 2 1
```
- **String 4 (D)**: Open
- **String 3 (G)**: Fret 2 - Index finger (1)
- **String 2 (B)**: Fret 3 - Ring finger (3)
- **String 1 (E)**: Fret 2 - Middle finger (2)
- **Strings 6, 5**: Muted
- **Notes**: D - A - D - F#

### E Major
```
Frets:    0 2 2 1 0 0
Strings:  6 5 4 3 2 1
```
- **String 6 (E)**: Open
- **String 5 (A)**: Fret 2 - Middle finger (2)
- **String 4 (D)**: Fret 2 - Ring finger (3)
- **String 3 (G)**: Fret 1 - Index finger (1)
- **Strings 2, 1**: Open
- **Notes**: E - B - E - G# - B - E

### F Major (Barre Chord)
```
Frets:    1 3 3 2 1 1
Strings:  6 5 4 3 2 1
```
- **Index finger**: Barre all strings at fret 1
- **Middle finger**: String 3 at fret 2
- **Ring finger**: String 5 at fret 3
- **Pinky**: String 4 at fret 3
- **Notes**: F - C - F - A - C - F

### F Major (Easy Version - No Barre)
```
Frets:    X X 3 2 1 1
Strings:  6 5 4 3 2 1
```
- **Index finger**: Barre strings 1-2 at fret 1
- **Middle finger**: String 3 at fret 2
- **Ring finger**: String 4 at fret 3
- Strum only top 4 strings

### G Major
```
Frets:    3 2 0 0 0 3
Strings:  6 5 4 3 2 1
```
- **String 6 (E)**: Fret 3 - Middle finger (2) or Ring finger (3)
- **String 5 (A)**: Fret 2 - Index finger (1)
- **Strings 4, 3, 2**: Open
- **String 1 (E)**: Fret 3 - Pinky (4) or Ring finger (3)
- **Notes**: G - B - D - G - B - G

---

## MINOR OPEN CHORDS

### Am (A Minor)
```
Frets:    X 0 2 2 1 0
Strings:  6 5 4 3 2 1
```
- **String 5 (A)**: Open
- **String 4 (D)**: Fret 2 - Middle finger (2)
- **String 3 (G)**: Fret 2 - Ring finger (3)
- **String 2 (B)**: Fret 1 - Index finger (1)
- **String 1 (E)**: Open
- **Notes**: A - E - A - C - E

### Bm (B Minor) - Barre Chord
```
Frets:    X 2 4 4 3 2
Strings:  6 5 4 3 2 1
```
- **Index finger**: Barre strings 1-5 at fret 2
- **Middle finger**: String 2 at fret 3
- **Ring finger**: String 4 at fret 4
- **Pinky**: String 3 at fret 4
- **Notes**: B - F# - B - D - F#

### Dm (D Minor)
```
Frets:    X X 0 2 3 1
Strings:  6 5 4 3 2 1
```
- **String 4 (D)**: Open
- **String 3 (G)**: Fret 2 - Middle finger (2)
- **String 2 (B)**: Fret 3 - Ring finger (3)
- **String 1 (E)**: Fret 1 - Index finger (1)
- **Strings 6, 5**: Muted
- **Notes**: D - A - D - F

### Em (E Minor)
```
Frets:    0 2 2 0 0 0
Strings:  6 5 4 3 2 1
```
- **String 6 (E)**: Open
- **String 5 (A)**: Fret 2 - Middle finger (2)
- **String 4 (D)**: Fret 2 - Ring finger (3)
- **Strings 3, 2, 1**: Open
- **Notes**: E - B - E - G - B - E

### Fm (F Minor) - Barre Chord
```
Frets:    1 3 3 1 1 1
Strings:  6 5 4 3 2 1
```
- **Index finger**: Barre all strings at fret 1
- **Ring finger**: Barre strings 4-5 at fret 3
- **Notes**: F - C - F - Ab - C - F

---

## DOMINANT 7TH CHORDS (e.g., A7, E7)

### A7
```
Frets:    X 0 2 0 2 0
Strings:  6 5 4 3 2 1
```
- **String 5 (A)**: Open
- **String 4 (D)**: Fret 2 - Middle finger (2)
- **String 3 (G)**: Open (provides the G note - the b7)
- **String 2 (B)**: Fret 2 - Ring finger (3)
- **String 1 (E)**: Open
- **Notes**: A - E - G - C# - E

### B7
```
Frets:    X 2 1 2 0 2
Strings:  6 5 4 3 2 1
```
- **String 5 (A)**: Fret 2 - Middle finger (2)
- **String 4 (D)**: Fret 1 - Index finger (1)
- **String 3 (G)**: Fret 2 - Ring finger (3)
- **String 2 (B)**: Open
- **String 1 (E)**: Fret 2 - Pinky (4)
- **Notes**: B - D# - A - B - F#

### C7
```
Frets:    X 3 2 3 1 0
Strings:  6 5 4 3 2 1
```
- **String 5 (A)**: Fret 3 - Ring finger (3)
- **String 4 (D)**: Fret 2 - Middle finger (2)
- **String 3 (G)**: Fret 3 - Pinky (4)
- **String 2 (B)**: Fret 1 - Index finger (1)
- **String 1 (E)**: Open
- **Notes**: C - E - Bb - C - E

### D7
```
Frets:    X X 0 2 1 2
Strings:  6 5 4 3 2 1
```
- **String 4 (D)**: Open
- **String 3 (G)**: Fret 2 - Ring finger (3)
- **String 2 (B)**: Fret 1 - Index finger (1)
- **String 1 (E)**: Fret 2 - Middle finger (2)
- **Notes**: D - A - C - F#

### E7
```
Frets:    0 2 0 1 0 0
Strings:  6 5 4 3 2 1
```
- **String 6 (E)**: Open
- **String 5 (A)**: Fret 2 - Middle finger (2)
- **String 4 (D)**: Open (provides the D note - the b7)
- **String 3 (G)**: Fret 1 - Index finger (1)
- **Strings 2, 1**: Open
- **Notes**: E - B - D - G# - B - E

### G7
```
Frets:    3 2 0 0 0 1
Strings:  6 5 4 3 2 1
```
- **String 6 (E)**: Fret 3 - Ring finger (3)
- **String 5 (A)**: Fret 2 - Middle finger (2)
- **Strings 4, 3, 2**: Open
- **String 1 (E)**: Fret 1 - Index finger (1)
- **Notes**: G - B - D - G - B - F

---

## MAJOR 7TH CHORDS (e.g., Cmaj7, Fmaj7)

### Cmaj7
```
Frets:    X 3 2 0 0 0
Strings:  6 5 4 3 2 1
```
- **String 5 (A)**: Fret 3 - Ring finger (3)
- **String 4 (D)**: Fret 2 - Middle finger (2)
- **Strings 3, 2, 1**: Open
- **Notes**: C - E - G - B - E
- **Tip**: Same as C major but remove index finger from B string

### Dmaj7
```
Frets:    X X 0 2 2 2
Strings:  6 5 4 3 2 1
```
- **String 4 (D)**: Open
- **Strings 3, 2, 1**: Fret 2 - barre or individual fingers
- **Notes**: D - A - C# - F#

### Emaj7
```
Frets:    0 2 1 1 0 0
Strings:  6 5 4 3 2 1
```
- **String 6 (E)**: Open
- **String 5 (A)**: Fret 2 - Ring finger (3)
- **String 4 (D)**: Fret 1 - Index finger (1)
- **String 3 (G)**: Fret 1 - Middle finger (2)
- **Strings 2, 1**: Open
- **Notes**: E - B - D# - G# - B - E

### Fmaj7 (Easy Version)
```
Frets:    X X 3 2 1 0
Strings:  6 5 4 3 2 1
```
- **String 4 (D)**: Fret 3 - Ring finger (3)
- **String 3 (G)**: Fret 2 - Middle finger (2)
- **String 2 (B)**: Fret 1 - Index finger (1)
- **String 1 (E)**: Open
- **Notes**: F - A - C - E

### Gmaj7
```
Frets:    3 2 0 0 0 2
Strings:  6 5 4 3 2 1
```
- **String 6 (E)**: Fret 3 - Ring finger (3)
- **String 5 (A)**: Fret 2 - Middle finger (2)
- **Strings 4, 3, 2**: Open
- **String 1 (E)**: Fret 2 - Index finger (1)
- **Notes**: G - B - D - G - B - F#

### Amaj7
```
Frets:    X 0 2 1 2 0
Strings:  6 5 4 3 2 1
```
- **String 5 (A)**: Open
- **String 4 (D)**: Fret 2 - Ring finger (3)
- **String 3 (G)**: Fret 1 - Index finger (1)
- **String 2 (B)**: Fret 2 - Middle finger (2)
- **String 1 (E)**: Open
- **Notes**: A - E - G# - C# - E

---

## MINOR 7TH CHORDS (e.g., Am7, Em7)

### Am7
```
Frets:    X 0 2 0 1 0
Strings:  6 5 4 3 2 1
```
- **String 5 (A)**: Open
- **String 4 (D)**: Fret 2 - Middle finger (2)
- **String 3 (G)**: Open
- **String 2 (B)**: Fret 1 - Index finger (1)
- **String 1 (E)**: Open
- **Notes**: A - E - G - C - E

### Bm7 (Barre Chord)
```
Frets:    X 2 4 2 3 2
Strings:  6 5 4 3 2 1
```
- **Index finger**: Barre at fret 2
- **Ring finger**: String 4 at fret 4
- **Middle finger**: String 2 at fret 3
- **Notes**: B - F# - A - D - F#

### Dm7
```
Frets:    X X 0 2 1 1
Strings:  6 5 4 3 2 1
```
- **String 4 (D)**: Open
- **String 3 (G)**: Fret 2 - Ring finger (3)
- **String 2 (B)**: Fret 1 - Index finger (1)
- **String 1 (E)**: Fret 1 - Index finger barre
- **Notes**: D - A - C - F

### Em7
```
Frets:    0 2 0 0 0 0
Strings:  6 5 4 3 2 1
```
- **String 6 (E)**: Open
- **String 5 (A)**: Fret 2 - Middle finger (2)
- **All other strings**: Open
- **Notes**: E - B - E - G - B - E
- **Tip**: Simply lift ring finger from E minor!

### Gm7 (Barre Chord)
```
Frets:    3 5 3 3 3 3
Strings:  6 5 4 3 2 1
```
- **Index finger**: Barre all strings at fret 3
- **Ring finger**: String 5 at fret 5
- **Notes**: G - D - F - Bb - D - G

---

# PART 2: THE CAGED SYSTEM

## Overview

The CAGED system is built on five basic open chord shapes: **C**, **A**, **G**, **E**, and **D**. Each shape can be moved up the neck as barre chords to play any chord.

## The Five Movable Shapes

### E-Shape (Most Common)
**Root note location**: 6th string

Open E Major = 022100
Move to fret 1 = F Major (133211)
Move to fret 3 = G Major (355433)

```
E-Shape Barre Chord Template:
Frets:    R  R+2  R+2  R+1  R  R
Strings:  6   5    4    3   2  1
(R = root fret position, full barre)
```
- Index finger: Full barre across all strings at root fret
- Middle finger: 3rd string, root+1 fret
- Ring finger: 5th string, root+2 fret
- Pinky: 4th string, root+2 fret

**Example - G Major (E-shape at fret 3)**:
```
Frets:    3 5 5 4 3 3
```

### A-Shape (Very Common)
**Root note location**: 5th string

Open A Major = X02220
Move to fret 2 = B Major (X24442)
Move to fret 3 = C Major (X35553)

```
A-Shape Barre Chord Template:
Frets:    X  R  R+2  R+2  R+2  R
Strings:  6  5   4    3    2   1
```
- Index finger: Barre strings 1-5 at root fret
- Ring finger: Barre strings 2-4 at root+2 fret (or use three fingers)

**Example - C Major (A-shape at fret 3)**:
```
Frets:    X 3 5 5 5 3
```

### C-Shape (Less Common)
**Root note location**: 5th string

Open C Major = X32010
Move to fret 3 = D Major

```
C-Shape Barre Chord Template:
Frets:    X  R  R-1  R-2  R-2  R-2
Strings:  6  5   4    3    2    1
```
- Requires barre across strings 1-3
- More challenging stretch

### G-Shape (Difficult)
**Root note location**: 6th string (also 1st string)

Open G Major = 320003
Move to fret 3 = Bb Major

```
G-Shape Characteristics:
- Large finger spread required
- Often modified or partially played
- Root on both 6th and 1st strings
```

### D-Shape
**Root note location**: 4th string

Open D Major = XX0232
Move to fret 3 = F Major (XX3565)

```
D-Shape Barre Chord Template:
Frets:    X  X  R  R+2  R+3  R+2
Strings:  6  5  4   3    2    1
```
- Only use top 4 strings
- Root is on 4th string

---

## How CAGED Shapes Connect

The shapes connect in sequence up the neck, sharing root notes:

```
C -> A -> G -> E -> D -> C (repeats)
```

**Example: Finding all C Major positions**
1. **C-shape** (open position): X32010
2. **A-shape** (fret 3): X35553
3. **G-shape** (fret 5): 355433 (modified)
4. **E-shape** (fret 8): 8-10-10-9-8-8
5. **D-shape** (fret 10): XX-10-12-13-12

---

## CAGED for Minor Chords

Apply the same principle with minor chord shapes:

### Em-Shape (Root: 6th string)
```
Frets:    R  R+2  R+2  R  R  R
```

### Am-Shape (Root: 5th string)
```
Frets:    X  R  R+2  R+2  R+1  R
```

### Dm-Shape (Root: 4th string)
```
Frets:    X  X  R  R+2  R+3  R+1
```

---

# PART 3: CHORD VOICINGS ON GUITAR

## What is a Chord Voicing?

A **voicing** is the specific arrangement of the notes in a chord:
- Which octave each note is in
- Which strings play which notes
- The order of notes from lowest to highest

## Factors That Affect Voicing

1. **String selection**: Which strings you use
2. **Fret position**: Where on the neck you play
3. **Note doubling**: Which notes appear multiple times
4. **Inversions**: Which note is in the bass

## Creating Different Voicings

### Example: C Major (C-E-G)

**Voicing 1 - Open Position**
```
X 3 2 0 1 0 = C E G C E (Root position)
```

**Voicing 2 - Barre at Fret 3 (A-shape)**
```
X 3 5 5 5 3 = C G C E G (Root position)
```

**Voicing 3 - Barre at Fret 8 (E-shape)**
```
8 10 10 9 8 8 = C G C E G C (Root position)
```

**Voicing 4 - Triad on strings 1-2-3**
```
X X 5 5 5 X = G C E (2nd inversion)
```

---

# PART 4: MUSIC THEORY FUNDAMENTALS

## Intervals

An **interval** is the distance between two notes, measured in half steps (semitones).

### Complete Interval Reference

| Interval | Semitones | Example (from C) | Sound Character |
|----------|-----------|------------------|-----------------|
| Unison (P1) | 0 | C to C | Same note |
| Minor 2nd (m2) | 1 | C to Db | Dissonant, tense |
| Major 2nd (M2) | 2 | C to D | Slightly tense |
| Minor 3rd (m3) | 3 | C to Eb | Sad, dark |
| Major 3rd (M3) | 4 | C to E | Happy, bright |
| Perfect 4th (P4) | 5 | C to F | Open, suspended |
| Tritone (A4/d5) | 6 | C to F#/Gb | Very tense, unstable |
| Perfect 5th (P5) | 7 | C to G | Stable, powerful |
| Minor 6th (m6) | 8 | C to Ab | Bittersweet |
| Major 6th (M6) | 9 | C to A | Warm, pleasant |
| Minor 7th (m7) | 10 | C to Bb | Bluesy, unresolved |
| Major 7th (M7) | 11 | C to B | Dreamy, jazzy |
| Octave (P8) | 12 | C to C | Same note, higher |

### Interval Quality Types

- **Perfect intervals**: Unison, 4th, 5th, Octave
- **Major/Minor intervals**: 2nd, 3rd, 6th, 7th
- **Augmented**: Raised by one half step
- **Diminished**: Lowered by one half step

### Guitar Fretboard Interval Visualization
```
Each fret = 1 semitone (half step)
Two frets = 1 whole step

String relationship:
- 6th to 5th string = Perfect 4th (5 frets same fret)
- 5th to 4th string = Perfect 4th
- 4th to 3rd string = Perfect 4th
- 3rd to 2nd string = Major 3rd (4 frets same fret)
- 2nd to 1st string = Perfect 4th
```

---

## Scale Construction

### The Major Scale Formula
**Whole - Whole - Half - Whole - Whole - Whole - Half**
(W-W-H-W-W-W-H)

**In semitones**: 2-2-1-2-2-2-1

**Scale degrees**: 1 - 2 - 3 - 4 - 5 - 6 - 7

**Example - C Major**:
```
C - D - E - F - G - A - B - C
  2   2   1   2   2   2   1  (semitones between notes)
```

### The Natural Minor Scale Formula
**Whole - Half - Whole - Whole - Half - Whole - Whole**
(W-H-W-W-H-W-W)

**In semitones**: 2-1-2-2-1-2-2

**Scale degrees**: 1 - 2 - b3 - 4 - 5 - b6 - b7

**Example - A Minor (relative to C Major)**:
```
A - B - C - D - E - F - G - A
  2   1   2   2   1   2   2
```

### The Major Pentatonic Scale
**Formula**: 1 - 2 - 3 - 5 - 6

Removes the 4th and 7th degrees from the major scale.

**Example - C Major Pentatonic**:
```
C - D - E - G - A
```

### The Minor Pentatonic Scale
**Formula**: 1 - b3 - 4 - 5 - b7

**Example - A Minor Pentatonic**:
```
A - C - D - E - G
```

### The Blues Scale
**Minor Blues Formula**: 1 - b3 - 4 - b5 - 5 - b7

The b5 is the "blue note" - adds tension and character.

**Example - A Blues Scale**:
```
A - C - D - Eb - E - G
```

**Major Blues Formula**: 1 - 2 - b3 - 3 - 5 - 6

**Example - C Major Blues**:
```
C - D - Eb - E - G - A
```

---

## Chord Construction

### Triads (Three-Note Chords)

Built by stacking thirds from a root note.

| Triad Type | Formula | Intervals | Example (C root) |
|------------|---------|-----------|------------------|
| Major | 1-3-5 | M3 + m3 | C-E-G |
| Minor | 1-b3-5 | m3 + M3 | C-Eb-G |
| Diminished | 1-b3-b5 | m3 + m3 | C-Eb-Gb |
| Augmented | 1-3-#5 | M3 + M3 | C-E-G# |

### 7th Chords (Four-Note Chords)

Add another third on top of the triad.

| 7th Chord Type | Formula | Example (C root) |
|----------------|---------|------------------|
| Major 7th (Cmaj7) | 1-3-5-7 | C-E-G-B |
| Dominant 7th (C7) | 1-3-5-b7 | C-E-G-Bb |
| Minor 7th (Cm7) | 1-b3-5-b7 | C-Eb-G-Bb |
| Minor-Major 7th (CmMaj7) | 1-b3-5-7 | C-Eb-G-B |
| Half-Diminished (Cm7b5) | 1-b3-b5-b7 | C-Eb-Gb-Bb |
| Diminished 7th (Cdim7) | 1-b3-b5-bb7 | C-Eb-Gb-Bbb(A) |

### Extended Chords

Extended chords include notes beyond the 7th (9th, 11th, 13th).

**Important**: The 9th = octave + 2nd, 11th = octave + 4th, 13th = octave + 6th

| Extended Chord | Formula | Notes (C root) |
|----------------|---------|----------------|
| C9 | 1-3-5-b7-9 | C-E-G-Bb-D |
| Cmaj9 | 1-3-5-7-9 | C-E-G-B-D |
| Cm9 | 1-b3-5-b7-9 | C-Eb-G-Bb-D |
| C11 | 1-3-5-b7-9-11 | C-E-G-Bb-D-F |
| C13 | 1-3-5-b7-9-11-13 | C-E-G-Bb-D-F-A |

**Practical Note**: On guitar, extended chords often omit notes:
- 9th chords: May omit the 5th
- 11th chords: Often omit the 3rd (clashes with 11th)
- 13th chords: Usually play root, 3rd, 7th, and 13th only

---

## The Nashville Number System

### What It Is

A method of notating chord progressions using numbers instead of chord names, allowing instant transposition to any key.

### How It Works

Each scale degree gets a number:

| Scale Degree | Number | In Key of C | In Key of G |
|--------------|--------|-------------|-------------|
| 1 (Tonic) | 1 | C | G |
| 2 | 2 | Dm | Am |
| 3 | 3 | Em | Bm |
| 4 (Subdominant) | 4 | F | C |
| 5 (Dominant) | 5 | G | D |
| 6 | 6 | Am | Em |
| 7 | 7 | Bdim | F#dim |

### Notation Conventions

| Symbol | Meaning | Example |
|--------|---------|---------|
| Number alone | Major chord | 1 = C major (in key of C) |
| Dash or "m" | Minor chord | 2- or 2m = D minor |
| 7 | Dominant 7th | 5-7 = G7 |
| maj7 | Major 7th | 1maj7 = Cmaj7 |
| Underline | Split measure | <u>1 4</u> = C for 2 beats, F for 2 beats |
| Diamond | Whole note/hold | Sustain the chord |
| < or > | Push (syncopate) | Play on the "and" before the beat |
| # or b | Non-diatonic | b7 = Bb chord in key of C |

### Common Progressions in Nashville Numbers

- **I-IV-V-I**: 1-4-5-1 (Classic rock/country)
- **I-V-vi-IV**: 1-5-6-4 (Pop progression)
- **ii-V-I**: 2-5-1 (Jazz turnaround)
- **I-vi-IV-V**: 1-6-4-5 (50s progression)
- **12-Bar Blues**: 1-1-1-1 / 4-4-1-1 / 5-4-1-5

---

## Circle of Fifths

### The Diagram

```
                C (0)
           F (1b)   G (1#)
        Bb (2b)         D (2#)
      Eb (3b)             A (3#)
        Ab (4b)         E (4#)
          Db (5b)     B (5#)
              Gb/F# (6b/6#)
```

### Key Signatures Reference

**Sharp Keys (Clockwise)**:
| Key | Sharps | Notes Sharped |
|-----|--------|---------------|
| C | 0 | None |
| G | 1 | F# |
| D | 2 | F#, C# |
| A | 3 | F#, C#, G# |
| E | 4 | F#, C#, G#, D# |
| B | 5 | F#, C#, G#, D#, A# |
| F# | 6 | F#, C#, G#, D#, A#, E# |

**Flat Keys (Counter-clockwise)**:
| Key | Flats | Notes Flatted |
|-----|-------|---------------|
| F | 1 | Bb |
| Bb | 2 | Bb, Eb |
| Eb | 3 | Bb, Eb, Ab |
| Ab | 4 | Bb, Eb, Ab, Db |
| Db | 5 | Bb, Eb, Ab, Db, Gb |
| Gb | 6 | Bb, Eb, Ab, Db, Gb, Cb |

### Order of Sharps and Flats

- **Sharps**: F - C - G - D - A - E - B (mnemonic: "Father Charles Goes Down And Ends Battle")
- **Flats**: B - E - A - D - G - C - F (reverse of sharps)

### Relative Major/Minor

Each major key has a relative minor (same key signature):
- Relative minor is 3 semitones below the major
- Example: C major / A minor (both have no sharps or flats)

### Practical Uses

1. **Finding compatible keys**: Adjacent keys share 6 of 7 notes
2. **Chord progressions**: The 4 and 5 chords are adjacent to the 1 on the circle
3. **Modulation**: Move to adjacent keys for smooth key changes

---

# PART 5: ADVANCED CONCEPTS

## Voice Leading

### Definition

Voice leading is the art of moving individual notes (voices) smoothly from one chord to the next, minimizing large jumps.

### Core Principles

1. **Common tones**: Keep notes that are shared between chords
2. **Stepwise motion**: Move other notes by the smallest interval possible
3. **Contrary motion**: If bass moves up, inner voices move down (and vice versa)
4. **Avoid parallel fifths/octaves**: Classical rule, less strict in modern music

### Voice Leading on Guitar

**Example: C to Am Transition**

Poor voice leading (big jumps):
```
C (open): X-3-2-0-1-0
Am (open): X-0-2-2-1-0
```

Better voice leading (using inversions):
```
C/E: 0-3-2-0-1-0
Am: X-0-2-2-1-0
(Smoother bass line: E to A, only a 4th)
```

### Practical Tips

1. Use **triads** on different string sets for flexibility
2. Learn **shell voicings** (root, 3rd, 7th) for jazz
3. Think horizontally (melody) not just vertically (chord shapes)
4. Keep common tones in the same voice/string

---

## Chord Inversions

### Definition

An **inversion** places a note other than the root in the bass (lowest) position.

### Triad Inversions

| Position | Bass Note | Stack | Example (C Major) |
|----------|-----------|-------|-------------------|
| Root position | Root | 1-3-5 | C-E-G |
| 1st inversion | 3rd | 3-5-1 | E-G-C |
| 2nd inversion | 5th | 5-1-3 | G-C-E |

### 7th Chord Inversions

| Position | Bass Note | Example (Cmaj7) |
|----------|-----------|-----------------|
| Root position | Root (C) | C-E-G-B |
| 1st inversion | 3rd (E) | E-G-B-C |
| 2nd inversion | 5th (G) | G-B-C-E |
| 3rd inversion | 7th (B) | B-C-E-G |

### Slash Chord Notation

Inversions are written as slash chords:
- **C/E** = C major with E in bass (1st inversion)
- **C/G** = C major with G in bass (2nd inversion)

### Inversion Voicings on Guitar

**C Major - Root Position (String set 5-4-3)**
```
X 3 2 0 X X = C-E-G
```

**C/E - 1st Inversion (String set 6-5-4)**
```
0 3 2 X X X = E-C-G
```

**C/G - 2nd Inversion (String set 4-3-2)**
```
X X 0 0 1 X = G-C-E
```

---

## Suspended and Add Chords

### Suspended Chords

Suspended chords **replace** the 3rd with another note.

| Chord | Formula | Notes (C) | Character |
|-------|---------|-----------|-----------|
| Csus4 | 1-4-5 | C-F-G | Tense, wants to resolve down to major |
| Csus2 | 1-2-5 | C-D-G | Open, wants to resolve up to major |

**Key Point**: Sus chords are neither major nor minor (no 3rd).

### Sus Chord Voicings

**Asus4**
```
X 0 2 2 3 0
```

**Asus2**
```
X 0 2 2 0 0
```

**Dsus4**
```
X X 0 2 3 3
```

**Dsus2**
```
X X 0 2 3 0
```

**Esus4**
```
0 2 2 2 0 0
```

### Add Chords

Add chords **keep** the 3rd and add another note.

| Chord | Formula | Notes (C) | Difference from Sus |
|-------|---------|-----------|---------------------|
| Cadd9 | 1-3-5-9 | C-E-G-D | Has the 3rd (E) |
| Cadd11 | 1-3-5-11 | C-E-G-F | Has the 3rd (E) |

**Important Distinction**:
- **Csus2** = C-D-G (no 3rd)
- **Cadd9** = C-E-G-D (includes 3rd)
- **C9** = C-E-G-Bb-D (includes 7th)

### Add Chord Voicings

**Cadd9**
```
X 3 2 0 3 0
```

**Gadd9**
```
3 X 0 2 0 3
```

---

## Altered Chords

### Definition

Altered chords modify the 5th and/or 9th of a dominant 7th chord.

### Alterations Available

| Alteration | Interval Change | Notes |
|------------|-----------------|-------|
| b5 | Lower 5th by 1/2 step | Same as #11 |
| #5 | Raise 5th by 1/2 step | Same as b13 |
| b9 | Lower 9th by 1/2 step | Dark sound |
| #9 | Raise 9th by 1/2 step | "Hendrix chord" |

### Common Altered Chord Types

**7b5** (or 7#11)
- Formula: 1-3-b5-b7
- Example: C7b5 = C-E-Gb-Bb

**7#5** (or 7b13)
- Formula: 1-3-#5-b7
- Example: C7#5 = C-E-G#-Bb

**7b9**
- Formula: 1-3-5-b7-b9
- Example: C7b9 = C-E-G-Bb-Db

**7#9** ("Hendrix Chord")
- Formula: 1-3-5-b7-#9
- Example: C7#9 = C-E-G-Bb-D#
- Famous in "Purple Haze"

**7alt** (Fully Altered)
- Contains altered 5th AND altered 9th
- Four combinations: b5/b9, b5/#9, #5/b9, #5/#9

### The Altered Scale

**Formula**: 1-b9-#9-3-b5-#5-b7

Also called "Super Locrian" - the 7th mode of melodic minor.

**Example - C Altered Scale**:
```
C - Db - D# - E - Gb - Ab - Bb
```

### Altered Voicings on Guitar

**E7#9 (The "Hendrix Chord")**
```
0 7 6 7 8 0
or
X 7 6 7 8 X
```

**A7b9**
```
X 0 2 3 2 3
```

---

## Modal Theory

### The Seven Modes

Each mode is derived from a major scale, starting on a different degree.

| Mode | Degree | Formula | Character | Tonic Chord |
|------|--------|---------|-----------|-------------|
| Ionian | 1st | 1-2-3-4-5-6-7 | Bright, happy | Major |
| Dorian | 2nd | 1-2-b3-4-5-6-b7 | Minor, jazzy | Minor |
| Phrygian | 3rd | 1-b2-b3-4-5-b6-b7 | Dark, exotic | Minor |
| Lydian | 4th | 1-2-3-#4-5-6-7 | Dreamy, floating | Major |
| Mixolydian | 5th | 1-2-3-4-5-6-b7 | Bluesy major | Dominant 7th |
| Aeolian | 6th | 1-2-b3-4-5-b6-b7 | Sad, natural minor | Minor |
| Locrian | 7th | 1-b2-b3-4-b5-b6-b7 | Unstable, tense | Diminished |

### Mode Interval Patterns (Whole/Half Steps)

| Mode | Pattern |
|------|---------|
| Ionian | W-W-H-W-W-W-H |
| Dorian | W-H-W-W-W-H-W |
| Phrygian | H-W-W-W-H-W-W |
| Lydian | W-W-W-H-W-W-H |
| Mixolydian | W-W-H-W-W-H-W |
| Aeolian | W-H-W-W-H-W-W |
| Locrian | H-W-W-H-W-W-W |

### Characteristic Notes (What Makes Each Mode Unique)

| Mode | Compared To | Characteristic Note |
|------|-------------|---------------------|
| Dorian | Natural minor | Major 6th |
| Phrygian | Natural minor | Minor 2nd |
| Lydian | Major | Raised 4th (#4) |
| Mixolydian | Major | Lowered 7th (b7) |
| Locrian | Natural minor | Diminished 5th (b5) |

### Modes in C (All Using C Major Scale Notes)

| Mode | Starting Note | Notes |
|------|---------------|-------|
| C Ionian | C | C-D-E-F-G-A-B |
| D Dorian | D | D-E-F-G-A-B-C |
| E Phrygian | E | E-F-G-A-B-C-D |
| F Lydian | F | F-G-A-B-C-D-E |
| G Mixolydian | G | G-A-B-C-D-E-F |
| A Aeolian | A | A-B-C-D-E-F-G |
| B Locrian | B | B-C-D-E-F-G-A |

### Parallel Modes (Same Root)

| Mode | Notes (from C) |
|------|----------------|
| C Ionian | C-D-E-F-G-A-B |
| C Dorian | C-D-Eb-F-G-A-Bb |
| C Phrygian | C-Db-Eb-F-G-Ab-Bb |
| C Lydian | C-D-E-F#-G-A-B |
| C Mixolydian | C-D-E-F-G-A-Bb |
| C Aeolian | C-D-Eb-F-G-Ab-Bb |
| C Locrian | C-Db-Eb-F-Gb-Ab-Bb |

### Modal Application Guidelines

| Mode | Use Over | Genre Context |
|------|----------|---------------|
| Ionian | Major chords, I chord | Pop, classical |
| Dorian | Minor chords, ii chord | Jazz, funk, R&B |
| Phrygian | Minor chords, iii chord | Flamenco, metal |
| Lydian | Major chords, IV chord | Jazz, film scores |
| Mixolydian | Dominant 7th, V chord | Blues, rock, country |
| Aeolian | Minor chords, vi chord | Rock, pop ballads |
| Locrian | Diminished chords, vii chord | Rarely used |

### Famous Modal Examples

- **Dorian**: "So What" (Miles Davis), "Billie Jean" (Michael Jackson)
- **Phrygian**: "White Rabbit" (Jefferson Airplane)
- **Lydian**: "Flying in a Blue Dream" (Joe Satriani)
- **Mixolydian**: "Sweet Home Alabama" (Lynyrd Skynyrd), "Norwegian Wood" (Beatles)
- **Aeolian**: "Stairway to Heaven" (Led Zeppelin intro)

---

# QUICK REFERENCE CHARTS

## Interval Quick Reference

```
Semitones:  0   1    2    3    4    5    6    7    8    9    10   11   12
Interval:   P1  m2   M2   m3   M3   P4   TT   P5   m6   M6   m7   M7   P8
On guitar:  0   1    2    3    4    5    6    7    8    9    10   11   12 frets
```

## Scale Formula Quick Reference

```
Major:           W W H W W W H  (1 2 3 4 5 6 7)
Natural Minor:   W H W W H W W  (1 2 b3 4 5 b6 b7)
Harmonic Minor:  W H W W H WH H (1 2 b3 4 5 b6 7)
Melodic Minor:   W H W W W W H  (1 2 b3 4 5 6 7) ascending
Major Pent:      1 2 3 5 6
Minor Pent:      1 b3 4 5 b7
Blues:           1 b3 4 b5 5 b7
```

## Chord Formula Quick Reference

```
Major:       1 3 5
Minor:       1 b3 5
Diminished:  1 b3 b5
Augmented:   1 3 #5
Major 7:     1 3 5 7
Dominant 7:  1 3 5 b7
Minor 7:     1 b3 5 b7
m7b5:        1 b3 b5 b7
Dim 7:       1 b3 b5 bb7
Sus2:        1 2 5
Sus4:        1 4 5
Add9:        1 3 5 9
```

## Nashville Numbers in Major Keys

```
Key:  1      2m     3m     4      5      6m     7dim
C:    C      Dm     Em     F      G      Am     Bdim
G:    G      Am     Bm     C      D      Em     F#dim
D:    D      Em     F#m    G      A      Bm     C#dim
A:    A      Bm     C#m    D      E      F#m    G#dim
E:    E      F#m    G#m    A      B      C#m    D#dim
F:    F      Gm     Am     Bb     C      Dm     Edim
Bb:   Bb     Cm     Dm     Eb     F      Gm     Adim
```

---

*Document created for comprehensive guitar music theory reference*
*Covers beginner through advanced concepts*
