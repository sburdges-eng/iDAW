# KELLY SONG - COMPLETE GUITAR SETUP GUIDE
## For "When I Found You Sleeping"

---

## FILES ON YOUR DESKTOP

| File | Description |
|------|-------------|
| `Kelly_Combined_Guitar.mid` | 2-track MIDI (fingerpicking + strumming) |
| `Kelly_Human_Guitar.mid` | Fingerpicking only |
| `Kelly_Chorus_Strum.mid` | Front Porch Step strumming only |
| `Kelly_Mitzvah_Fillers.mid` | Previous version with filler tones |
| `Kelly_Performance_Sheet.md` | Lyrics with timestamps & vowel notes |

---

## RECOMMENDED SETUP IN LOGIC PRO

### Track 1: Fingerpicking (plays throughout)

**Best Instrument Options (in order):**

1. **Bluesy Acoustic** (warmest, most bedroom-emo)
   - Library > Sampler Instruments > 08 Guitars > 01 Acoustic Guitars > Bluesy Acoustic

2. **Roundback Acoustic** (intimate fingerstyle)
   - Same location

3. **Steel String Acoustic** (brighter, more presence)
   - Library > Sampler Instruments > 08 Guitars > Steel String Acoustic

**Alchemy Alternatives:**
- Alchemy > Modern Songwriter > Guitars > **Mood Acoustic**
- Alchemy > Modern Songwriter > Guitars > **Acoustic Pluck**
- Alchemy > Modern Songwriter > Guitars > **Silver Ballad**

### Track 2: Strumming (chorus/bridge only)

**Best Options:**
1. **Roundback Acoustic** or **Acoustic Guitar**
2. Pan slightly left (-15) while fingerpicking is center or slight right

---

## ALCHEMY GUITAR PATCHES (Full List)

### Modern Songwriter > Guitars (Best for this song)
- 12 String Split
- 12 Strings
- **Acoustic Pluck** ★
- Autumn Legends
- Bandura Dreams
- Bandura Unison
- Drifting Guitar Riff
- Dulcimer Reverser
- Electric Eighties
- **Ethereal Guitar** ★
- Fast Tremolo Guitar
- Gentle Quirks
- Granular Magnetic Guitar
- **Guitar PM Acoustic** ★
- Hither and Zither
- Lost Temple
- Magic Hat
- Middle Eastern Dreams
- **Mood Acoustic** ★★★ (try this first)
- Mosaic Guitar
- **Old Time Radio** ★ (lo-fi character)
- Pluck Layer
- **Post Rock Guitar** ★
- **Silver Ballad** ★★
- Small Pluck Echoes
- Sonicus
- Strange Guitar Space
- Strange Plucky Guitar
- Tone Bender

### Basic > Guitars
- Rain Strum (could work for strumming track)
- Water Guitar
- Water Rings

---

## LO-FI BEDROOM TREATMENT

### EQ Settings (Channel EQ)
```
High Pass: 80 Hz (remove rumble)
Low Shelf: +2 dB at 200 Hz (warmth)
Bell: -2 dB at 2.5 kHz (reduce harshness)
High Shelf: -3 dB at 8 kHz (tape-like rolloff)
```

### Compression (Compressor)
```
Threshold: -18 dB
Ratio: 3:1
Attack: 30 ms
Release: 150 ms
Gain: +2 dB
```
Or use preset: **Compressor > 03 Guitars > Classic Guitar**

### Reverb (Space Designer)
- Use: **01 Large Spaces > 02 Halls > 03.6s Guitar Hall Large**
- OR: **03 Small Spaces > 01 Rooms > 0.3s Jazz Guitar Room**
- Mix: 15-25% wet

### Lo-Fi Character (Optional)
1. **Tape Delay** - very short delay (50-80ms), low feedback, mix 10%
2. **Bitcrusher** - subtle, just to add grit
3. **Vinyl** plugin if you have it - adds crackle/warmth

---

## SAMPLER INSTRUMENTS (EXS24)

### Acoustic Guitars Available:
| Instrument | Character |
|------------|-----------|
| Acoustic Guitar | Clean, neutral |
| Acoustic Harmonics | Bell-like overtones |
| **Bluesy Acoustic** | Warm, worn-in ★★★ |
| Classical Acoustic Guitar | Nylon, soft |
| Dobro Chords | Slide guitar |
| Dobro Slide | Slide guitar |
| **Roundback Acoustic** | Intimate ★★ |
| Steel String Acoustic | Bright, present |
| 12 String Acoustic | Full, shimmery |
| 12 String Dual | Doubled 12-string |
| Hawaiian Ukulele | Ukulele |
| Bluegrass Banjo | Banjo |

---

## MIXING SUGGESTIONS

### Panning
```
Fingerpicking: Center or +10 Right
Strumming: -15 Left
```

### Volume Balance
```
Fingerpicking: 0 dB (reference)
Strumming: -3 to -6 dB (support, not compete)
```

### Automation Ideas
- Strumming volume: fade in at chorus start
- Reverb: increase slightly during "Freeze" section
- High-pass filter: automate lower during intimate verses

---

## QUICK SETUP STEPS

1. **Open** `Kelly_Combined_Guitar.mid` in Logic
2. **Track 1** (fingerpicking):
   - Load **Bluesy Acoustic** from Library
   - Add Channel EQ with lo-fi settings above
   - Add Space Designer (small room)
3. **Track 2** (strumming):
   - Load **Roundback Acoustic**
   - Pan -15 Left
   - Volume -4 dB
4. **Master**: Add light compression, tape saturation
5. **Tempo**: Should auto-detect 82 BPM

---

## KEYBOARD SHORTCUTS

| Key | Action |
|-----|--------|
| Y | Open/Close Library |
| P | Open Piano Roll |
| E | Open Editor |
| X | Open Mixer |
| B | Open Smart Controls |
| Cmd+K | Open Musical Typing |

---

*Setup guide for Kelly Song project*
*82 BPM | 3:38 | Lo-Fi Bedroom Emo*
