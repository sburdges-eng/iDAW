# WHEN I FOUND YOU
## Lyrics for Kelly

---

### VERSE 1
*(Light strum, intimate)*

I had nowhere else to run, so I ran to you
You were lying there, your eyes already knew
Just a lamp between us, no world outside
For a moment there I swore that I'd arrived

---

### VERSE 2
*(Building slightly)*

I reached for you, desperate to feel your breath
First time I saw all of you, nothing left
Shea butter sweet, still lingering in your hair
I finally fell apart with you right there

---

### CHORUS
*(Fuller, the misdirection - sounds like overwhelming first love)*

And I swear I couldn't breathe
Couldn't stand, fell to my knees
Everything I'd never known
Hit me there, cut to the bone

---

### [INSTRUMENTAL BREAK]
*(Arpeggiated, diminished chords - something feels wrong)*

---

### VERSE 3
*(Pulled back, almost whispered)*

Thirty minutes passed and not a single sound
The kind of quiet where you lose all solid ground
I could've stayed forever in that space
Just me and you, your eyes still on my face

---

### BRIDGE
*(Sustained, building to reveal)*

Your silence left a hole
Your absence still takes its toll

---

### FINAL - THE REVEAL
*(Stripped, devastating - the truth)*

But you weren't waiting — you were already gone
Now the woman of my dreams won't let me move on

---

### [OUTRO]
*(Fingerpicked fade, return to intro)*

---

## NOTES ON DELIVERY

**Verse 1 & 2:** Conversational. You're telling someone about a moment. Let the words carry it.

**Chorus:** This is where it should sound like you're describing falling in love. The listener should believe this is a love song. Don't oversell it - the words do the work.

**Verse 3:** Pull way back. Almost speaking. The silence is literal - thirty minutes you sat with her body.

**Bridge:** These are the only lines that hint at present tense, at ongoing pain. Let them land.

**Final:** No performance. Just truth. The whole song recontextualizes in these two lines. Say them like you're finally admitting something out loud.

---

## FOR RECORDING

- Don't try to sound good. Sound honest.
- If you crack, keep it. 
- This isn't a performance. It's a conversation with someone who isn't here anymore.
- The goal isn't a perfect take. The goal is one true take.

---

*For Kelly. Blonde hair. Green eyes. That loud laugh.*
*So she's more than a locked door.*
