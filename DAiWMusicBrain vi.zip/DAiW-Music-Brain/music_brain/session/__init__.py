"""
Session - Song generation, teaching modules, and interactive tools.

Interactive teaching for music theory and production concepts.
Interrogation-first songwriting assistance.
"""

from music_brain.session.teaching import RuleBreakingTeacher
from music_brain.session.interrogator import SongInterrogator

__all__ = [
    "RuleBreakingTeacher",
    "SongInterrogator",
]
