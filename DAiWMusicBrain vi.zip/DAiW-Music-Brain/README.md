# DAiW - Digital Audio Intelligent Workstation

> A Python toolkit for music production intelligence: groove extraction, chord analysis, arrangement generation, and AI-assisted songwriting.

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Overview

DAiW (Digital Audio intelligent Workstation) combines:
- **Music Brain** - Python analysis engine for MIDI/audio
- **Vault** - Knowledge base of songwriting guides, theory references, and production workflows
- **CLI** - Command-line tools for groove extraction, chord analysis, and AI-assisted composition

## Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/DAiW-Music-Brain.git
cd DAiW-Music-Brain

# Install dependencies
pip install -r requirements.txt

# Install as package
pip install -e .
```

## Quick Start

### Command Line Interface

```bash
# Extract groove from a MIDI file
daiw extract drums.mid

# Analyze chord progression
daiw analyze --chords song.mid

# Apply groove template to a track
daiw apply --genre funk --source template.mid --target track.mid

# Diagnose harmonic issues in a progression
daiw diagnose "F-C-Am-Dm"

# Generate reharmonization suggestions
daiw reharm "F-C-Am-Dm" --style jazz

# Interactive teaching mode
daiw teach rulebreaking
```

### Python API

```python
from music_brain.groove import extract_groove, apply_groove
from music_brain.structure import analyze_chords, detect_sections
from music_brain.audio import analyze_feel

# Extract timing/velocity groove from reference
groove = extract_groove("reference_drums.mid")

# Apply groove to target
apply_groove("my_drums.mid", groove, output="humanized.mid")

# Analyze chord progression
chords = analyze_chords("song.mid")
print(chords.progression)  # ['Fmaj7', 'C', 'Am7', 'Dm']

# Detect song sections
sections = detect_sections("song.mid")
for section in sections:
    print(f"{section.name}: bars {section.start}-{section.end}")
```

## Project Structure

```
DAiW-Music-Brain/
├── music_brain/              # Python analysis package
│   ├── groove/               # Groove extraction & application
│   ├── structure/            # Chord, section, progression analysis
│   ├── audio/                # Audio feel analysis
│   ├── utils/                # MIDI I/O, instruments, PPQ handling
│   ├── daw/                  # Logic Pro / DAW integration
│   ├── session/              # Song generator & teaching modules
│   └── data/                 # JSON datasets (chords, genres, grooves)
│
├── vault/                    # Knowledge base (Obsidian-compatible)
│   ├── Songwriting_Guides/   # Practical songwriting references
│   ├── Theory_Reference/     # Music theory deep-dives
│   ├── Production_Workflows/ # DAW-specific techniques
│   ├── Templates/            # Reusable song templates
│   └── Data_Files/           # JSON datasets for AI retrieval
│
├── docs/                     # Documentation
├── examples/                 # Example MIDI files and scripts
└── tests/                    # Test suite
```

## Features

### Groove Analysis
- Extract timing deviations (swing, push/pull)
- Velocity contours and accent patterns
- Ghost note detection
- Cross-DAW PPQ normalization

### Chord & Harmony
- Roman numeral analysis
- Borrowed chord detection
- Modal interchange identification
- Reharmonization suggestions

### Section Detection
- Automatic verse/chorus/bridge labeling
- Energy curve analysis
- Transition point detection

### AI Integration
- Compatible with AnythingLLM for vault-based chat
- Training datasets for LLM fine-tuning
- Embedding-optimized markdown

## Vault Knowledge Base

The `vault/` directory is an Obsidian-compatible knowledge base containing:

- **Rule-Breaking Masterpieces** - Famous examples of theory rules broken for artistic effect
- **Borrowed Chord Field Manual** - Modal mixture and borrowed chords explained
- **Emotional Harmony Framework** - Mapping chords to emotional responses
- **Genre Pocket Maps** - Timing characteristics by genre
- **Production Workflows** - DAW-specific techniques and templates

## Requirements

- Python 3.9+
- mido (MIDI I/O)
- numpy (numerical analysis)
- pretty_midi (advanced MIDI parsing)

Optional:
- librosa (audio analysis)
- music21 (music theory)

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

MIT License - see [LICENSE](LICENSE) for details.

## Acknowledgments

- Built for musicians who think in sound, not spreadsheets
- Inspired by the lo-fi bedroom recording philosophy
- "The wrong note played with conviction is the right note."
