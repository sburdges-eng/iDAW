# 🎯🎳 Dart Strike - iOS App

**Dart Strike** is a hybrid darts-bowling game for iOS where players tap pins to knock them down and score points using traditional bowling rules.

## 📱 Features

- **Interactive Pin Layout**: Tap bowling pins to knock them down
- **Traditional Bowling Scoring**: Full implementation of strikes, spares, and open frames
- **Multi-Player Support**: Up to 8 players can compete
- **Auto Pin Reset**: Pins automatically reset after frames and turns
- **Game State Saving**: Resume games after closing the app
- **Professional Scorecard**: View cumulative scores and frame-by-frame breakdown
- **10th Frame Rules**: Proper bonus throws for strikes and spares

## 🏗️ Project Structure

```
DartStrike-iOS/
├── DartStrikeApp.swift              # Main app entry point
├── Models/
│   └── GameModel.swift              # Core game logic and bowling rules
├── Views/
│   ├── GameView.swift               # Main gameplay screen
│   ├── ScorecardView.swift          # Bowling scorecard display
│   └── PlayerSetupView.swift        # Player setup and game start
└── Utilities/
    └── PersistenceManager.swift     # Game state saving/loading
```

## 🚀 Getting Started

### Prerequisites

- **Xcode 14+** (for SwiftUI support)
- **iOS 15.0+** target deployment
- Mac running macOS Monterey or later

### Installation Steps

1. **Create New Xcode Project**
   ```
   File > New > Project
   Choose: iOS > App
   Interface: SwiftUI
   Language: Swift
   Product Name: DartStrike
   ```

2. **Add Files to Project**
   - Create folder structure matching the layout above
   - Copy each `.swift` file into the appropriate folder
   - Ensure all files are added to the target

3. **Configure Project Settings**
   - Select your project in the navigator
   - Under "General" tab:
     - Set **Display Name**: "Dart Strike"
     - Set **Bundle Identifier**: `com.yourdomain.dartstrike`
     - Set **Deployment Target**: iOS 15.0
   
4. **Build and Run**
   ```
   Product > Run (⌘R)
   ```

## 📋 How to Play

### Setup
1. Launch the app
2. Add players (up to 8) using the player setup screen
3. Tap "Start Game"

### Gameplay
1. **Select Pins**: Tap the bowling pins you want to knock down
2. **Submit Throw**: Press "Submit Throw" to lock in your selection
3. **Automatic Turn Rotation**: The game automatically switches players after each frame
4. **View Scores**: Tap "Scorecard" to see detailed scoring

### Scoring Rules

#### Strike (X)
- Knock down all 10 pins on first throw
- Score: 10 + next 2 throws

#### Spare (/)
- Knock down all 10 pins using both throws
- Score: 10 + next 1 throw

#### Open Frame
- Less than 10 pins knocked down
- Score: Actual number of pins

#### 10th Frame
- Strike on 1st ball: Get 2 bonus throws
- Spare on 2nd ball: Get 1 bonus throw
- Maximum: 30 points in 10th frame

**Perfect Game**: 12 strikes = 300 points

## 🔧 Testing the Pin Reset Fix

The app includes the debugged pin reset functionality:

### Test Scenario 1: Basic Pin Reset
1. Start a 2-player game
2. Player 1: Select and knock down 5 pins, submit throw
3. Player 1: Select remaining 5 pins, submit second throw
4. **✅ Verify**: All pins reset to standing for Player 2

### Test Scenario 2: Strike Reset
1. Player knocks down all 10 pins (strike)
2. Submit throw
3. **✅ Verify**: Pins immediately reset for next frame

### Test Scenario 3: Frame Transition
1. Complete an entire frame (2 throws)
2. **✅ Verify**: Pins reset for next player's turn

### Test Scenario 4: 10th Frame
1. Reach the 10th frame
2. Get a strike on first throw
3. **✅ Verify**: Pins reset for bonus throws

## 💾 Game State Persistence

The app automatically saves your game progress:

- **Auto-Save**: When app goes to background
- **Resume**: Prompted to resume when reopening
- **Manual Reset**: Use "New Game" button to start fresh

Saved data includes:
- All player scores and frames
- Current player turn
- Pin positions
- Game progress

## 🐛 Debugging Tips

### Pins Not Resetting
- Check that `resetPins()` is called in `moveToNextFrame()`
- Verify `@Published` properties trigger UI updates
- Ensure `gameModel` is passed correctly to views

### Scoring Issues
- Review `calculateFrameScore()` logic
- Check that strikes/spares are detected properly
- Verify 10th frame special rules

### Persistence Not Working
- Check UserDefaults key names match
- Ensure `Codable` conformance on all models
- Test save/load functions individually

## 🎨 Customization

### Change Pin Colors
In `PinView` (GameView.swift):
```swift
.fill(pin.isStanding ? Color.white : Color.red.opacity(0.3))
// Change to your preferred colors
```

### Modify Pin Layout
In `PinLayoutView` (GameView.swift):
```swift
// Adjust spacing, sizes, or arrangement
HStack(spacing: 20) { ... }
```

### Add Animations (Future)
```swift
// Add withAnimation wrapper:
withAnimation {
    game.togglePin(pinId)
}
```

## 📱 Running on Physical Device

1. Connect your iPhone via USB
2. In Xcode, select your device from the device menu
3. **Trust Developer**: Settings > General > VPN & Device Management
4. Tap "Run" in Xcode

**Note**: You'll need an Apple Developer account ($99/year) to deploy to device for more than 7 days.

## 🔄 Version History

**Version 1.0** (Current)
- ✅ Core bowling gameplay
- ✅ Pin reset functionality (debugged)
- ✅ Traditional scoring system
- ✅ Multi-player support
- ✅ Game state persistence
- ✅ No animations (clean, fast gameplay)

## 🎯 Future Enhancements (Optional)

- [ ] Sound effects for pin knockdowns
- [ ] Game statistics and history
- [ ] Player profiles and avatars
- [ ] Handicap scoring system
- [ ] Dark mode support
- [ ] iPad optimization
- [ ] iCloud sync for multiple devices

## 📞 Support

For issues or questions:
1. Check the debugging tips section
2. Review the code comments in each file
3. Test with the provided test scenarios

## 📄 License

Personal use only. Not for commercial distribution.

---

## 🎉 Quick Start Checklist

- [ ] Xcode project created
- [ ] All `.swift` files added
- [ ] Project builds without errors
- [ ] Tested on simulator
- [ ] Pins reset correctly between turns
- [ ] Scoring calculates properly
- [ ] Game saves and loads correctly

**Ready to bowl? 🎯🎳**
