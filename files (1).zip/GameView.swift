//
//  GameView.swift
//  Dart Strike
//
//  Main gameplay view with interactive pins
//

import SwiftUI

struct GameView: View {
    @ObservedObject var game: GameModel
    @State private var showingScorecard = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // Current Player Info
                if let player = game.currentPlayer {
                    VStack(spacing: 8) {
                        Text(player.name)
                            .font(.largeTitle)
                            .fontWeight(.bold)
                        
                        HStack {
                            Text("Frame: \(player.currentFrameIndex + 1)")
                            Text("•")
                            Text("Throw: \(player.currentThrow)")
                            Text("•")
                            Text("Score: \(player.totalScore)")
                        }
                        .font(.title3)
                        .foregroundColor(.secondary)
                    }
                    .padding()
                }
                
                // Pins Display
                Text("Pins Knocked: \(game.getPinsKnockedDown())/10")
                    .font(.headline)
                    .foregroundColor(.blue)
                
                // Bowling Pin Layout
                PinLayoutView(pins: $game.pins, onPinTap: { pinId in
                    game.togglePin(pinId)
                })
                .padding()
                
                Spacer()
                
                // Control Buttons
                VStack(spacing: 15) {
                    Button(action: {
                        game.submitThrow()
                    }) {
                        Text("Submit Throw")
                            .font(.title2)
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(12)
                    }
                    
                    HStack(spacing: 15) {
                        Button(action: {
                            game.resetPins()
                        }) {
                            Text("Reset Pins")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.orange)
                                .cornerRadius(12)
                        }
                        
                        Button(action: {
                            showingScorecard = true
                        }) {
                            Text("Scorecard")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.green)
                                .cornerRadius(12)
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 30)
            }
            .navigationTitle("🎯 Dart Strike")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("New Game") {
                        game.resetGame()
                    }
                }
            }
            .sheet(isPresented: $showingScorecard) {
                ScorecardView(game: game)
            }
            .alert("Game Complete!", isPresented: $game.gameComplete) {
                Button("View Scorecard") {
                    showingScorecard = true
                }
                Button("New Game") {
                    game.resetGame()
                }
            } message: {
                if let winner = game.players.max(by: { $0.totalScore < $1.totalScore }) {
                    Text("\(winner.name) wins with \(winner.totalScore) points!")
                }
            }
        }
    }
}

// MARK: - Pin Layout View
struct PinLayoutView: View {
    @Binding var pins: [Pin]
    let onPinTap: (Int) -> Void
    
    var body: some View {
        VStack(spacing: 30) {
            // Row 1: Pin 7, 8, 9, 10
            HStack(spacing: 20) {
                ForEach([7, 8, 9, 10], id: \.self) { pinId in
                    PinView(pin: getPin(pinId), onTap: {
                        onPinTap(pinId)
                    })
                }
            }
            
            // Row 2: Pin 4, 5, 6
            HStack(spacing: 20) {
                Spacer()
                ForEach([4, 5, 6], id: \.self) { pinId in
                    PinView(pin: getPin(pinId), onTap: {
                        onPinTap(pinId)
                    })
                }
                Spacer()
            }
            
            // Row 3: Pin 2, 3
            HStack(spacing: 20) {
                Spacer()
                ForEach([2, 3], id: \.self) { pinId in
                    PinView(pin: getPin(pinId), onTap: {
                        onPinTap(pinId)
                    })
                }
                Spacer()
            }
            
            // Row 4: Pin 1
            HStack {
                Spacer()
                PinView(pin: getPin(1), onTap: {
                    onPinTap(1)
                })
                Spacer()
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.gray.opacity(0.1))
        )
    }
    
    private func getPin(_ id: Int) -> Pin {
        pins.first(where: { $0.id == id }) ?? Pin(id: id)
    }
}

// MARK: - Individual Pin View
struct PinView: View {
    let pin: Pin
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            ZStack {
                Circle()
                    .fill(pin.isStanding ? Color.white : Color.red.opacity(0.3))
                    .frame(width: 60, height: 60)
                    .overlay(
                        Circle()
                            .stroke(pin.isStanding ? Color.blue : Color.red, lineWidth: 3)
                    )
                
                Text("\(pin.id)")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(pin.isStanding ? .blue : .red)
            }
        }
    }
}

// MARK: - Preview
struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        let game = GameModel()
        game.startNewGame(playerNames: ["Sean", "Player 2"])
        return GameView(game: game)
    }
}
