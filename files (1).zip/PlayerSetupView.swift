//
//  PlayerSetupView.swift
//  Dart Strike
//
//  Setup screen for adding players and starting game
//

import SwiftUI

struct PlayerSetupView: View {
    @ObservedObject var game: GameModel
    @State private var playerName: String = ""
    @State private var playerNames: [String] = []
    @State private var showError = false
    @State private var errorMessage = ""
    
    var body: some View {
        NavigationView {
            VStack(spacing: 30) {
                // Title
                VStack(spacing: 10) {
                    Text("🎯🎳")
                        .font(.system(size: 80))
                    
                    Text("Dart Strike")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    
                    Text("Darts meets Bowling")
                        .font(.headline)
                        .foregroundColor(.secondary)
                }
                .padding(.top, 40)
                
                // Player List
                if !playerNames.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Players (\(playerNames.count))")
                            .font(.headline)
                            .foregroundColor(.secondary)
                        
                        ScrollView {
                            VStack(spacing: 8) {
                                ForEach(Array(playerNames.enumerated()), id: \.offset) { index, name in
                                    HStack {
                                        Text("\(index + 1).")
                                            .fontWeight(.bold)
                                            .foregroundColor(.blue)
                                        
                                        Text(name)
                                            .font(.body)
                                        
                                        Spacer()
                                        
                                        Button(action: {
                                            playerNames.remove(at: index)
                                        }) {
                                            Image(systemName: "trash")
                                                .foregroundColor(.red)
                                        }
                                    }
                                    .padding()
                                    .background(
                                        RoundedRectangle(cornerRadius: 8)
                                            .fill(Color.gray.opacity(0.1))
                                    )
                                }
                            }
                        }
                        .frame(maxHeight: 250)
                    }
                    .padding(.horizontal)
                }
                
                Spacer()
                
                // Add Player Section
                VStack(spacing: 15) {
                    TextField("Enter player name", text: $playerName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .font(.body)
                        .autocapitalization(.words)
                        .disableAutocorrection(true)
                    
                    Button(action: addPlayer) {
                        Text("Add Player")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(playerName.isEmpty ? Color.gray : Color.blue)
                            .cornerRadius(12)
                    }
                    .disabled(playerName.isEmpty)
                }
                .padding(.horizontal)
                
                // Start Game Button
                Button(action: startGame) {
                    Text("Start Game")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(playerNames.isEmpty ? Color.gray : Color.green)
                        .cornerRadius(12)
                }
                .disabled(playerNames.isEmpty)
                .padding(.horizontal)
                .padding(.bottom, 30)
            }
            .navigationTitle("Setup")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Error", isPresented: $showError) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(errorMessage)
            }
        }
    }
    
    private func addPlayer() {
        let trimmedName = playerName.trimmingCharacters(in: .whitespaces)
        
        guard !trimmedName.isEmpty else {
            errorMessage = "Player name cannot be empty"
            showError = true
            return
        }
        
        guard !playerNames.contains(where: { $0.lowercased() == trimmedName.lowercased() }) else {
            errorMessage = "Player name already exists"
            showError = true
            return
        }
        
        guard playerNames.count < 8 else {
            errorMessage = "Maximum 8 players allowed"
            showError = true
            return
        }
        
        playerNames.append(trimmedName)
        playerName = ""
    }
    
    private func startGame() {
        guard !playerNames.isEmpty else { return }
        game.startNewGame(playerNames: playerNames)
    }
}

// MARK: - Preview
struct PlayerSetupView_Previews: PreviewProvider {
    static var previews: some View {
        PlayerSetupView(game: GameModel())
    }
}
