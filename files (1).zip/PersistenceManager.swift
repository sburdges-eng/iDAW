//
//  PersistenceManager.swift
//  Dart Strike
//
//  Handles saving and loading game state
//

import Foundation

class PersistenceManager {
    static let shared = PersistenceManager()
    
    private let userDefaults = UserDefaults.standard
    private let gameStateKey = "DartStrike_GameState"
    private let lastPlayedKey = "DartStrike_LastPlayed"
    
    private init() {}
    
    // MARK: - Save Game
    func saveGame(players: [Player], currentPlayerIndex: Int, pins: [Pin], gameStarted: Bool) {
        let gameState = GameState(
            players: players,
            currentPlayerIndex: currentPlayerIndex,
            pins: pins,
            gameStarted: gameStarted,
            lastPlayed: Date()
        )
        
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(gameState)
            userDefaults.set(data, forKey: gameStateKey)
            userDefaults.set(Date(), forKey: lastPlayedKey)
            print("✅ Game saved successfully")
        } catch {
            print("❌ Failed to save game: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Load Game
    func loadGame() -> GameState? {
        guard let data = userDefaults.data(forKey: gameStateKey) else {
            print("ℹ️ No saved game found")
            return nil
        }
        
        do {
            let decoder = JSONDecoder()
            let gameState = try decoder.decode(GameState.self, from: data)
            print("✅ Game loaded successfully")
            return gameState
        } catch {
            print("❌ Failed to load game: \(error.localizedDescription)")
            return nil
        }
    }
    
    // MARK: - Check if saved game exists
    func hasSavedGame() -> Bool {
        return userDefaults.data(forKey: gameStateKey) != nil
    }
    
    // MARK: - Get last played date
    func getLastPlayedDate() -> Date? {
        return userDefaults.object(forKey: lastPlayedKey) as? Date
    }
    
    // MARK: - Delete saved game
    func deleteSavedGame() {
        userDefaults.removeObject(forKey: gameStateKey)
        userDefaults.removeObject(forKey: lastPlayedKey)
        print("✅ Saved game deleted")
    }
    
    // MARK: - Auto-save helper
    func autoSave(game: GameModel) {
        guard game.gameStarted && !game.gameComplete else { return }
        saveGame(
            players: game.players,
            currentPlayerIndex: game.currentPlayerIndex,
            pins: game.pins,
            gameStarted: game.gameStarted
        )
    }
}

// MARK: - Game State Model
struct GameState: Codable {
    let players: [Player]
    let currentPlayerIndex: Int
    let pins: [Pin]
    let gameStarted: Bool
    let lastPlayed: Date
}

// MARK: - GameModel Extension for Persistence
extension GameModel {
    func saveGame() {
        PersistenceManager.shared.saveGame(
            players: players,
            currentPlayerIndex: currentPlayerIndex,
            pins: pins,
            gameStarted: gameStarted
        )
    }
    
    func loadGame() {
        if let gameState = PersistenceManager.shared.loadGame() {
            self.players = gameState.players
            self.currentPlayerIndex = gameState.currentPlayerIndex
            self.pins = gameState.pins
            self.gameStarted = gameState.gameStarted
            self.gameComplete = false
        }
    }
    
    func hasSavedGame() -> Bool {
        return PersistenceManager.shared.hasSavedGame()
    }
    
    func deleteSavedGame() {
        PersistenceManager.shared.deleteSavedGame()
    }
}
