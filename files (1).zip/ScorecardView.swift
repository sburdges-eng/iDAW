//
//  ScorecardView.swift
//  Dart Strike
//
//  Traditional bowling scorecard display
//

import SwiftUI

struct ScorecardView: View {
    @ObservedObject var game: GameModel
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    ForEach(game.players) { player in
                        PlayerScorecardView(player: player)
                    }
                }
                .padding()
            }
            .navigationTitle("Scorecard")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - Player Scorecard
struct PlayerScorecardView: View {
    let player: Player
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // Player Name and Total
            HStack {
                Text(player.name)
                    .font(.title2)
                    .fontWeight(.bold)
                
                Spacer()
                
                Text("\(player.totalScore)")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.blue)
            }
            
            // Frame Boxes
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 4) {
                    ForEach(0..<10) { frameIndex in
                        FrameBoxView(
                            frame: player.frames[frameIndex],
                            frameNumber: frameIndex + 1,
                            isActive: frameIndex == player.currentFrameIndex && !player.isGameComplete
                        )
                    }
                }
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.gray.opacity(0.1))
        )
    }
}

// MARK: - Frame Box View
struct FrameBoxView: View {
    let frame: Frame
    let frameNumber: Int
    let isActive: Bool
    
    var body: some View {
        VStack(spacing: 0) {
            // Frame Number
            Text("\(frameNumber)")
                .font(.caption)
                .fontWeight(.semibold)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 4)
                .background(isActive ? Color.blue.opacity(0.2) : Color.clear)
            
            Divider()
            
            // Throws Display
            if frameNumber == 10 {
                // 10th frame has special layout
                TenthFrameThrowsView(frame: frame)
            } else {
                // Regular frame
                RegularFrameThrowsView(frame: frame)
            }
            
            Divider()
            
            // Cumulative Score
            Text(frame.score != nil ? "\(frame.score!)" : "")
                .font(.headline)
                .fontWeight(.bold)
                .frame(maxWidth: .infinity)
                .frame(height: 30)
                .background(Color.white)
        }
        .frame(width: frameNumber == 10 ? 90 : 70)
        .overlay(
            RoundedRectangle(cornerRadius: 4)
                .stroke(isActive ? Color.blue : Color.gray, lineWidth: isActive ? 2 : 1)
        )
    }
}

// MARK: - Regular Frame Throws
struct RegularFrameThrowsView: View {
    let frame: Frame
    
    var body: some View {
        HStack(spacing: 0) {
            // First Throw
            Text(formatFirstThrow())
                .font(.caption)
                .frame(maxWidth: .infinity)
                .frame(height: 25)
            
            Divider()
            
            // Second Throw
            Text(formatSecondThrow())
                .font(.caption)
                .frame(maxWidth: .infinity)
                .frame(height: 25)
        }
        .background(Color.white)
    }
    
    private func formatFirstThrow() -> String {
        guard let first = frame.firstThrow else { return "" }
        return first == 10 ? "X" : "\(first)"
    }
    
    private func formatSecondThrow() -> String {
        guard let first = frame.firstThrow, let second = frame.secondThrow else { return "" }
        
        if first == 10 { return "" }  // Strike, no second throw
        if first + second == 10 { return "/" }  // Spare
        return second == 0 ? "-" : "\(second)"
    }
}

// MARK: - 10th Frame Throws
struct TenthFrameThrowsView: View {
    let frame: Frame
    
    var body: some View {
        HStack(spacing: 0) {
            // First Throw
            Text(formatThrow(frame.firstThrow, previous: nil))
                .font(.caption)
                .frame(maxWidth: .infinity)
                .frame(height: 25)
            
            Divider()
            
            // Second Throw
            Text(formatThrow(frame.secondThrow, previous: frame.firstThrow))
                .font(.caption)
                .frame(maxWidth: .infinity)
                .frame(height: 25)
            
            Divider()
            
            // Third Throw (bonus)
            Text(formatThrow(frame.thirdThrow, previous: frame.secondThrow))
                .font(.caption)
                .frame(maxWidth: .infinity)
                .frame(height: 25)
        }
        .background(Color.white)
    }
    
    private func formatThrow(_ throw: Int?, previous: Int?) -> String {
        guard let throwValue = `throw` else { return "" }
        
        if throwValue == 10 { return "X" }
        
        if let prev = previous {
            if prev != 10 && prev + throwValue == 10 { return "/" }
        }
        
        return throwValue == 0 ? "-" : "\(throwValue)"
    }
}

// MARK: - Preview
struct ScorecardView_Previews: PreviewProvider {
    static var previews: some View {
        let game = GameModel()
        game.startNewGame(playerNames: ["Sean", "Player 2"])
        
        // Add some test data
        game.players[0].frames[0].firstThrow = 10
        game.players[0].frames[0].score = 20
        game.players[0].frames[1].firstThrow = 7
        game.players[0].frames[1].secondThrow = 3
        game.players[0].frames[1].score = 30
        
        return ScorecardView(game: game)
    }
}
