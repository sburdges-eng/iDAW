---
title: "Kelly in the Water"
status: in-progress
key: 
bpm: 
time_signature: 4/4
created: 2025
modified: 2025
tags:
  - status/in-progress
---

# Kelly in the Water

## Overview

**Key:** 
**BPM:** 
**Time Signature:** 4/4
**Duration:** 
**Genre/Style:** 

---

## Concept / Vision

*Original composition*

---

## Structure

| Section | Bars | Time | Notes |
|---------|------|------|-------|
| | | | |

---

## Chord Progression

### Main
```
| | | | |
```

---

## Recording Notes

### Session Info
- **Interface:** PreSonus AudioBox iTwo
- **DAW:** Logic Pro

---

## Mixing Notes

*Document your mixing decisions here as you make them*

---

## Stems / File Inventory

| Stem | Filename | Notes |
|------|----------|-------|
| | | |

**Project File Location:** 

---

## Related
- [[Echoes in the Dream]]
- [[Workflows/]]

