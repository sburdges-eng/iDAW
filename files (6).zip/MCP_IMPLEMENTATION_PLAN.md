# DAiW MCP Implementation Plan

## 🎯 OVERVIEW

**MCP (Model Context Protocol)** will allow Claude Desktop, other AI assistants, and future applications to interact with DAiW programmatically. This transforms DAiW from a standalone CLI tool into an **AI-accessible music generation service**.

### **What MCP Enables:**

```
WITHOUT MCP:
User → Claude conversation → User manually runs CLI → User uploads results

WITH MCP:
User → Claude uses DAiW tools directly → Complete workflow automated
```

---

## 🏗️ ARCHITECTURE DECISION

### **Option A: Single Comprehensive Server (RECOMMENDED)**
```
daiw_mcp
├── Harmony tools (5-7 tools)
├── Groove tools (4-6 tools)
├── Diagnostic tools (3-4 tools)
├── Audio analysis tools (4-6 tools)
├── Vault tools (2-3 tools)
└── MIDI tools (3-4 tools)

Total: ~25-30 tools in one server
```

**Advantages:**
- Single installation for users
- AI can discover all capabilities at once
- Easier to maintain
- Consistent error handling
- Shared utilities (MIDI I/O, file management)

### **Option B: Separate Servers by Domain**
```
daiw_core_mcp     (harmony, groove, diagnostics)
daiw_audio_mcp    (audio analysis, reference matching)
daiw_vault_mcp    (knowledge base access)
daiw_midi_mcp     (MIDI file operations)
```

**Advantages:**
- Modular installation
- Independent development
- Clearer separation of concerns

**Disadvantages:**
- More complex for users
- AI needs to know about multiple servers
- Duplication of utilities

### **RECOMMENDATION: Option A - Single Server**

DAiW's tools are highly interconnected (harmony → MIDI, audio → harmony, etc.). A single server with well-organized tool categories is more practical.

---

## 📋 MCP TOOL DESIGN

### **Tool Categories:**

```python
# Category 1: HARMONY GENERATION (Phase 1 ✅)
daiw_generate_harmony          # Intent → chord progression
daiw_diagnose_progression      # Analyze existing progression
daiw_suggest_reharmonization   # Alternative harmonies
daiw_validate_rule_breaking    # Check if rule-break is justified

# Category 2: GROOVE MANAGEMENT (Phase 1 ✅)
daiw_extract_groove            # MIDI → groove profile
daiw_apply_groove              # Apply groove to MIDI
daiw_list_groove_templates     # Available genre grooves
daiw_create_custom_groove      # Define new groove

# Category 3: AUDIO ANALYSIS (Phase 2)
daiw_analyze_audio             # WAV/MP3 → analysis
daiw_extract_chords            # Audio → chord progression
daiw_compare_references        # Match to target
daiw_production_profile        # Frequency/stereo/dynamics

# Category 4: ARRANGEMENT (Phase 2)
daiw_generate_arrangement      # Intent → structure
daiw_create_section            # Single section
daiw_calculate_energy_arc      # Dynamic curve

# Category 5: COMPLETE COMPOSITION (Phase 2)
daiw_compose_complete_song     # Full multi-track generation
daiw_generate_bass_line        # From harmony
daiw_create_production_guide   # Mix notes

# Category 6: KNOWLEDGE BASE (All phases)
daiw_search_vault              # Find relevant knowledge
daiw_get_rule_breaking_example # Specific masterpiece
daiw_list_genre_fingerprints   # Genre characteristics

# Category 7: MIDI OPERATIONS (All phases)
daiw_read_midi                 # Parse MIDI file
daiw_write_midi                # Create MIDI file
daiw_merge_tracks              # Combine MIDI files
daiw_export_to_daw             # DAW project template
```

---

## 🔧 IMPLEMENTATION PRIORITY

### **Phase 1: Core MCP Server (Week 1-2)**
**Status:** Phase 1 code complete, ready to wrap in MCP

**Tools to implement:**
1. `daiw_generate_harmony` ⭐
2. `daiw_diagnose_progression` ⭐
3. `daiw_extract_groove`
4. `daiw_apply_groove`
5. `daiw_list_groove_templates`
6. `daiw_read_midi`
7. `daiw_write_midi`

**Deliverable:** Working MCP server with 7 tools

### **Phase 2: Audio Analysis (Week 3-4)**
**Status:** Phase 2 starter complete, needs full implementation

**Tools to implement:**
1. `daiw_analyze_audio`
2. `daiw_compare_references`
3. `daiw_production_profile`

**Deliverable:** Audio analysis capabilities

### **Phase 3: Complete Composition (Week 5-6)**
**Status:** Planned, not implemented

**Tools to implement:**
1. `daiw_compose_complete_song` ⭐
2. `daiw_generate_arrangement`
3. `daiw_generate_bass_line`
4. `daiw_create_production_guide`

**Deliverable:** End-to-end song generation

### **Phase 4: Knowledge Base (Week 7)**
**Tools to implement:**
1. `daiw_search_vault`
2. `daiw_get_rule_breaking_example`

**Deliverable:** AI can query Music Brain Vault

---

## 💻 MCP SERVER IMPLEMENTATION

### **Project Structure:**
```
daiw_mcp/
├── __init__.py
├── server.py                 # Main MCP server
├── tools/
│   ├── __init__.py
│   ├── harmony.py           # Harmony generation tools
│   ├── groove.py            # Groove tools
│   ├── audio.py             # Audio analysis tools
│   ├── arrangement.py       # Arrangement tools
│   ├── composition.py       # Complete composition
│   ├── vault.py             # Knowledge base tools
│   └── midi.py              # MIDI utilities
├── models/
│   ├── __init__.py
│   ├── harmony_models.py    # Pydantic models for harmony
│   ├── groove_models.py     # Pydantic models for groove
│   └── audio_models.py      # Pydantic models for audio
├── utils/
│   ├── __init__.py
│   ├── file_manager.py      # File operations
│   └── error_handler.py     # Unified error handling
└── pyproject.toml           # Dependencies & metadata
```

### **Server Initialization:**

```python
# server.py
from mcp.server.fastmcp import FastMCP
from pathlib import Path

# Initialize MCP server
mcp = FastMCP(
    "daiw_mcp",
    dependencies=[
        "mido>=1.3.0",
        "numpy>=1.24.0",
        "librosa>=0.10.0",
    ]
)

# Import tool registrations
from .tools import harmony, groove, audio, midi
```

---

## 🎼 EXAMPLE TOOL IMPLEMENTATIONS

### **Tool 1: Generate Harmony**

```python
# tools/harmony.py
from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List
import json

class GenerateHarmonyInput(BaseModel):
    """Input for harmony generation from emotional intent."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra='forbid'
    )
    
    core_wound: str = Field(
        ...,
        description="Core emotional wound (e.g., 'Finding someone after they left', 'Unrequited love')",
        min_length=5,
        max_length=200
    )
    emotional_intent: str = Field(
        ...,
        description="Emotional intent (e.g., 'Grief disguised as love', 'Anxious hope')",
        min_length=5,
        max_length=200
    )
    key: str = Field(
        default="C",
        description="Musical key (e.g., 'C', 'F', 'Am', 'D#')",
        pattern=r'^[A-G][#b]?m?$'
    )
    tempo_bpm: int = Field(
        default=120,
        description="Tempo in beats per minute",
        ge=40,
        le=240
    )
    technical_rule_to_break: Optional[str] = Field(
        default=None,
        description="Optional rule to break (e.g., 'HARMONY_ModalInterchange', 'HARMONY_AvoidTonicResolution')"
    )
    num_chords: int = Field(
        default=4,
        description="Number of chords in progression",
        ge=2,
        le=16
    )

@mcp.tool(
    name="daiw_generate_harmony",
    annotations={
        "title": "Generate Harmony from Emotional Intent",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def generate_harmony(params: GenerateHarmonyInput) -> str:
    """Generate chord progression from emotional intent using DAiW's interrogation engine.
    
    This tool translates emotional states into musical harmony choices. It uses
    the "Interrogate Before Generate" philosophy to deeply understand intent
    before making technical music theory decisions.
    
    Returns:
        str: JSON with chord progression, MIDI file path, and justification
    """
    try:
        from music_brain.harmony import HarmonyGenerator
        from music_brain.structure import CompleteSongIntent
        
        # Create intent
        intent = CompleteSongIntent(
            core_wound=params.core_wound,
            emotional_intent=params.emotional_intent,
            technical_constraints=f"{params.key} major, {params.tempo_bpm} BPM",
            technical_rule_to_break=params.technical_rule_to_break
        )
        
        # Generate harmony
        generator = HarmonyGenerator()
        result = generator.generate_from_intent(intent)
        
        # Save MIDI
        midi_path = f"/tmp/daiw_harmony_{params.key}_{params.tempo_bpm}.mid"
        generator.generate_midi_from_harmony(result, midi_path, params.tempo_bpm)
        
        return json.dumps({
            "status": "success",
            "progression": result.chord_progression,
            "roman_numerals": result.roman_numerals,
            "justification": result.emotional_justification,
            "rule_breaking": result.rule_breaking_applied,
            "midi_file": midi_path,
            "key": params.key,
            "tempo_bpm": params.tempo_bpm
        }, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
            "suggestion": "Check that intent parameters are clear and specific"
        }, indent=2)
```

### **Tool 2: Diagnose Progression**

```python
class DiagnoseProgressionInput(BaseModel):
    """Input for chord progression diagnosis."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra='forbid'
    )
    
    progression: str = Field(
        ...,
        description="Chord progression (e.g., 'F-C-Dm-Bbm', 'Am-F-C-G')",
        min_length=3,
        pattern=r'^[A-G][#b]?m?(add\d+|maj\d+|m\d+|\d+)?(-[A-G][#b]?m?(add\d+|maj\d+|m\d+|\d+)?)*$'
    )
    key: str = Field(
        ...,
        description="Musical key (e.g., 'C', 'F', 'Am')",
        pattern=r'^[A-G][#b]?m?$'
    )
    mode: str = Field(
        default="major",
        description="Mode: 'major' or 'minor'",
        pattern=r'^(major|minor)$'
    )

@mcp.tool(
    name="daiw_diagnose_progression",
    annotations={
        "title": "Diagnose Chord Progression",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def diagnose_progression(params: DiagnoseProgressionInput) -> str:
    """Analyze chord progression for Roman numerals, borrowed chords, and emotional function.
    
    Detects rule-breaking patterns like modal interchange, identifies borrowed
    chords, and provides emotional interpretation of harmonic choices.
    
    Returns:
        str: JSON with Roman numeral analysis, detected rule-breaking, emotional character
    """
    try:
        from music_brain.diagnostics import ChordDiagnostics
        
        diagnostics = ChordDiagnostics()
        result = diagnostics.diagnose(
            params.progression,
            key=params.key,
            mode=params.mode
        )
        
        return json.dumps({
            "status": "success",
            "progression": params.progression,
            "key": f"{params.key} {params.mode}",
            "roman_numerals": result.roman_numerals,
            "chord_analysis": [
                {
                    "chord": chord.chord_name,
                    "roman": chord.roman_numeral,
                    "diatonic": chord.is_diatonic,
                    "borrowed_from": chord.borrowed_from,
                    "emotional_function": chord.emotional_function
                }
                for chord in result.chord_analyses
            ],
            "rule_breaking_detected": result.rule_breaking,
            "emotional_character": result.emotional_character,
            "reharmonization_suggestions": result.suggestions
        }, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
            "suggestion": "Check chord names and key signature"
        }, indent=2)
```

### **Tool 3: Apply Groove**

```python
class ApplyGrooveInput(BaseModel):
    """Input for applying groove to MIDI."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra='forbid'
    )
    
    midi_file: str = Field(
        ...,
        description="Path to input MIDI file",
        min_length=1
    )
    groove_name: str = Field(
        ...,
        description="Groove template name (e.g., 'funk', 'boom-bap', 'dilla', 'straight', 'trap')",
        pattern=r'^[a-z_]+$'
    )
    intensity: float = Field(
        default=1.0,
        description="Groove intensity (0.0 = quantized, 1.0 = full groove)",
        ge=0.0,
        le=1.0
    )
    output_path: Optional[str] = Field(
        default=None,
        description="Optional output path (auto-generated if not specified)"
    )

@mcp.tool(
    name="daiw_apply_groove",
    annotations={
        "title": "Apply Groove to MIDI",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def apply_groove(params: ApplyGrooveInput) -> str:
    """Apply genre-specific groove humanization to MIDI drum pattern.
    
    Transforms quantized MIDI into human-feeling performances using
    systematic timing deviations, swing, and velocity variations.
    
    Returns:
        str: JSON with output file path and groove characteristics applied
    """
    try:
        from music_brain.groove import GrooveApplicator
        import os
        
        # Generate output path if not specified
        output_path = params.output_path
        if not output_path:
            base = os.path.splitext(params.midi_file)[0]
            output_path = f"{base}_groove_{params.groove_name}.mid"
        
        # Apply groove
        applicator = GrooveApplicator()
        template = applicator.load_template(params.groove_name)
        applicator.apply_groove(
            params.midi_file,
            output_path,
            template,
            intensity=params.intensity
        )
        
        return json.dumps({
            "status": "success",
            "input_file": params.midi_file,
            "output_file": output_path,
            "groove_applied": params.groove_name,
            "intensity": params.intensity,
            "groove_characteristics": {
                "tempo_bpm": template.tempo_bpm,
                "swing_percentage": template.swing_percentage,
                "push_pull": template.push_pull,
                "pocket_description": template.pocket_description
            }
        }, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
            "suggestion": "Check that MIDI file exists and groove name is valid"
        }, indent=2)
```

---

## 🚀 USAGE EXAMPLES

### **Example 1: Claude Desktop Usage**

```
User: Generate harmony for a song about grief disguised as love

Claude: I'll use DAiW to generate harmony from that emotional intent.
[calls daiw_generate_harmony with:
  core_wound="Finding someone after they left"
  emotional_intent="Grief disguised as love"
  key="F"
  tempo_bpm=82
  technical_rule_to_break="HARMONY_ModalInterchange"
]

Result: Generated F-C-Dm-Bbm progression. The Bbm chord (borrowed 
from F minor) creates "bittersweet darkness" - perfect for grief 
disguised as love. The modal interchange makes hope feel earned 
and bittersweet.

MIDI file saved to: /tmp/daiw_harmony_F_82.mid

Would you like me to:
1. Analyze this progression in detail
2. Apply a groove to make it more human
3. Generate a complete arrangement
```

### **Example 2: Multi-Tool Workflow**

```
User: Create a complete lo-fi song about my friend Kelly who died

Claude: I'll generate a complete song using DAiW's workflow:

Step 1: Generate harmony from emotional intent
[daiw_generate_harmony: "Finding someone after they left" → F-C-Dm-Bbm]

Step 2: Analyze the progression
[daiw_diagnose_progression: Validates Bbm as modal interchange]

Step 3: Apply lo-fi groove
[daiw_apply_groove: intensity=0.75, minimal humanization]

Step 4: Generate complete arrangement
[daiw_compose_complete_song: verse-chorus structure, 3 minutes]

Result:
- Harmony: F-C-Dm-Bbm (validated)
- Drums: Lo-fi groove applied
- Bass: Generated from harmony
- Structure: verse-verse-chorus-verse-chorus-bridge-chorus
- Production guide: Ready for recording

All files ready in /tmp/kelly_song_complete/
```

---

## 📦 INSTALLATION

### **For Users:**

```bash
# Install DAiW MCP server
pip install daiw-mcp

# Configure in Claude Desktop
# Add to ~/Library/Application Support/Claude/claude_desktop_config.json:
{
  "mcpServers": {
    "daiw": {
      "command": "python",
      "args": ["-m", "daiw_mcp"]
    }
  }
}
```

### **For Developers:**

```bash
# Clone DAiW repo
git clone https://github.com/sburdges-eng/DAiW-Music-Brain.git
cd DAiW-Music-Brain

# Install in development mode
pip install -e ".[mcp]"

# Test with MCP Inspector
npx @modelcontextprotocol/inspector python -m daiw_mcp
```

---

## 🧪 TESTING STRATEGY

### **1. Unit Tests (Per Tool)**
```python
# test_harmony_tool.py
async def test_generate_harmony():
    params = GenerateHarmonyInput(
        core_wound="Finding someone after they left",
        emotional_intent="Grief disguised as love",
        key="F",
        tempo_bpm=82
    )
    result = await generate_harmony(params)
    result_dict = json.loads(result)
    
    assert result_dict["status"] == "success"
    assert "F" in result_dict["progression"]
    assert "Bbm" in result_dict["progression"]
```

### **2. Integration Tests (Multi-Tool)**
```python
async def test_complete_workflow():
    # Generate harmony
    harmony_result = await generate_harmony(...)
    harmony_data = json.loads(harmony_result)
    midi_path = harmony_data["midi_file"]
    
    # Diagnose it
    diagnose_result = await diagnose_progression(
        progression=harmony_data["progression"],
        key="F",
        mode="major"
    )
    
    # Apply groove
    groove_result = await apply_groove(
        midi_file=midi_path,
        groove_name="funk",
        intensity=0.8
    )
    
    assert all results successful
```

### **3. MCP Inspector Testing**
```bash
# Launch inspector
npx @modelcontextprotocol/inspector python -m daiw_mcp

# Test in browser:
# 1. Call daiw_generate_harmony
# 2. Verify JSON response
# 3. Check MIDI file created
# 4. Test error handling
```

---

## 📊 IMPLEMENTATION CHECKLIST

### **Phase 1: Core MCP Server (Week 1-2)**
- [ ] Set up project structure
- [ ] Create server.py with FastMCP
- [ ] Implement harmony tools (3 tools)
- [ ] Implement groove tools (3 tools)
- [ ] Implement MIDI tools (2 tools)
- [ ] Add error handling
- [ ] Write unit tests
- [ ] Test with MCP Inspector
- [ ] Documentation

### **Phase 2: Audio Analysis (Week 3-4)**
- [ ] Implement audio analysis tools
- [ ] Add reference comparison
- [ ] Production profiling
- [ ] Integration tests

### **Phase 3: Complete Composition (Week 5-6)**
- [ ] Arrangement generation
- [ ] Complete composition tool
- [ ] Bass line generation
- [ ] Production guide creation

### **Phase 4: Knowledge Base (Week 7)**
- [ ] Vault search
- [ ] Rule-breaking examples
- [ ] Genre fingerprints

### **Phase 5: Polish & Release (Week 8)**
- [ ] Complete test coverage
- [ ] Documentation
- [ ] PyPI package
- [ ] Claude Desktop instructions
- [ ] Example workflows

---

## 🎯 SUCCESS METRICS

**MCP implementation is successful when:**

1. ✅ **Claude Desktop Integration**
   - Users can ask Claude to generate music
   - Multi-step workflows work seamlessly
   - Error messages are helpful

2. ✅ **Tool Completeness**
   - All Phase 1 capabilities exposed
   - Tools are discoverable
   - Input validation prevents errors

3. ✅ **Kelly Song Test**
   - Complete Kelly song generated via MCP
   - F-C-Dm-Bbm validated
   - Production guide created
   - Ready to record

4. ✅ **Developer Experience**
   - Easy to install
   - Clear documentation
   - Good test coverage
   - Extensible for new tools

---

## 💡 FUTURE ENHANCEMENTS

### **Phase 6: Advanced Features**
- Streaming responses for long operations
- Progress callbacks for generation
- Batch processing multiple songs
- DAW integration tools

### **Phase 7: Resources**
- Expose Music Brain Vault as MCP resources
- Rule-breaking database browsable
- Genre templates accessible

### **Phase 8: Prompts**
- Pre-built intent templates
- Emotional interrogation prompts
- Production guide templates

---

## 🔥 THE VISION

**Today:**
```
User writes CLI commands manually
User uploads/downloads files
User interprets results
```

**With MCP:**
```
User: "Create a lo-fi song about grief"
Claude: [Uses 5 DAiW tools seamlessly]
        "Here's your complete song package"
```

**The Impact:**
- AI assistants can compose music
- Natural language → technical implementation
- "Interrogate Before Generate" at scale
- Zero friction creative workflow

---

## 📂 FILES TO CREATE

1. **daiw_mcp/server.py** - Main MCP server
2. **daiw_mcp/tools/harmony.py** - Harmony tools
3. **daiw_mcp/tools/groove.py** - Groove tools
4. **daiw_mcp/tools/midi.py** - MIDI tools
5. **daiw_mcp/models/harmony_models.py** - Pydantic models
6. **daiw_mcp/pyproject.toml** - Package metadata
7. **tests/test_harmony_tools.py** - Tests
8. **README_MCP.md** - MCP-specific docs

---

## 🚀 IMMEDIATE NEXT STEPS

### **Step 1: Create MCP Project (30 min)**
```bash
mkdir daiw_mcp
cd daiw_mcp
touch server.py pyproject.toml
mkdir -p tools models tests
```

### **Step 2: Implement First Tool (1 hour)**
```python
# Start with daiw_generate_harmony
# Wrap existing harmony_generator.py
# Test with MCP Inspector
```

### **Step 3: Add 2 More Tools (2 hours)**
```python
# daiw_diagnose_progression
# daiw_apply_groove
```

### **Step 4: Test in Claude Desktop (30 min)**
```bash
# Configure Claude Desktop
# Test natural language → music generation
```

**Total Time to Working MCP:** ~4 hours

---

*"From CLI commands to natural language music generation - MCP makes DAiW accessible to AI."*

Ready to implement? 🎸
