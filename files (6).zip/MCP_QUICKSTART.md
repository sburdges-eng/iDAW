# DAiW MCP Quick Start Guide

## 🎯 WHAT IS THIS?

MCP (Model Context Protocol) lets Claude Desktop and other AI assistants use DAiW directly through natural language. No more manual CLI commands!

**Without MCP:**
```
You: Generate harmony for grief
Claude: Here's how to do it... [explains]
You: [manually runs daiw command]
You: [uploads result back to Claude]
```

**With MCP:**
```
You: Generate harmony for grief
Claude: [automatically calls daiw_generate_harmony]
        Here's your F-C-Dm-Bbm progression!
        [shows analysis and provides MIDI file]
```

---

## ⚡ QUICK START (5 MINUTES)

### **Step 1: Install MCP Dependencies**
```bash
pip install mcp fastmcp pydantic --break-system-packages
```

### **Step 2: Test the MCP Server**
```bash
cd /mnt/user-data/outputs

# Test with MCP Inspector (visual testing tool)
npx @modelcontextprotocol/inspector python daiw_mcp_starter.py
```

This opens a browser at http://localhost:5173 where you can:
- See all 3 tools available
- Test each tool with sample inputs
- View JSON responses
- Debug any errors

### **Step 3: Try Each Tool**

**Tool 1: Generate Harmony**
```json
{
  "core_wound": "Finding someone after they left",
  "emotional_intent": "Grief disguised as love",
  "key": "F",
  "tempo_bpm": 82,
  "technical_rule_to_break": "HARMONY_ModalInterchange",
  "num_chords": 4
}
```

**Tool 2: Diagnose Progression**
```json
{
  "progression": "F-C-Dm-Bbm",
  "key": "F",
  "mode": "major"
}
```

**Tool 3: Apply Groove**
```json
{
  "midi_file": "/path/to/drums.mid",
  "groove_name": "funk",
  "intensity": 0.8
}
```

---

## 🖥️ CLAUDE DESKTOP INTEGRATION

### **Step 1: Configure Claude Desktop**

Edit your config file:
- **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

Add this:
```json
{
  "mcpServers": {
    "daiw": {
      "command": "python",
      "args": [
        "/mnt/user-data/outputs/daiw_mcp_starter.py"
      ]
    }
  }
}
```

### **Step 2: Restart Claude Desktop**

Close and reopen Claude Desktop. You should see "daiw" in the MCP section.

### **Step 3: Test in Claude Desktop**

```
You: Use DAiW to generate harmony for a song about finding someone after they're gone

Claude: I'll use DAiW's harmony generator...
[calls daiw_generate_harmony]

Result: Generated F-C-Dm-Bbm progression. The Bbm chord is borrowed 
from F minor (modal interchange), creating "bittersweet darkness" that 
perfectly captures grief disguised as love.

MIDI file: /tmp/daiw_harmony_F_82.mid
```

---

## 🧪 TESTING EXAMPLES

### **Example 1: Kelly Song Workflow**

```
You: Generate a chord progression for a song about my friend Kelly 
     who died by suicide. The emotion is grief disguised as love - 
     every line sounds like falling in love until the final reveal.
     Use F major at 82 BPM.

Claude: [calls daiw_generate_harmony with modal interchange]

You: Analyze that progression in detail

Claude: [calls daiw_diagnose_progression]

You: Apply a minimal lo-fi groove

Claude: [calls daiw_apply_groove with straight, intensity=0.75]
```

### **Example 2: Rule-Breaking Exploration**

```
You: What happens if I use modal interchange in a major key?

Claude: [calls daiw_generate_harmony with HARMONY_ModalInterchange]
        [calls daiw_diagnose_progression to analyze result]
        
        Modal interchange borrows chords from the parallel minor...
        [explains with concrete example from generated progression]
```

### **Example 3: Genre Groove Comparison**

```
You: Show me the difference between funk and boom-bap grooves

Claude: [calls daiw_apply_groove with funk]
        [calls daiw_apply_groove with boom-bap]
        
        Funk (95 BPM, 58% swing):
        - Kick pushes forward (+15ms)
        - Creates forward momentum
        
        Boom-bap (92 BPM, 54% swing):
        - More laid back
        - Classic hip-hop feel
```

---

## 🎼 AVAILABLE TOOLS

### **1. daiw_generate_harmony**
Generate chord progressions from emotional intent

**Required:**
- `core_wound` (string): Emotional truth
- `emotional_intent` (string): Transformation or state

**Optional:**
- `key` (string): Default "C"
- `tempo_bpm` (int): Default 120
- `technical_rule_to_break` (string): Rule to break
- `num_chords` (int): Default 4

**Returns:**
- Chord progression
- Roman numerals
- Emotional justification
- MIDI file path

### **2. daiw_diagnose_progression**
Analyze existing chord progressions

**Required:**
- `progression` (string): Chords separated by dashes
- `key` (string): Musical key

**Optional:**
- `mode` (string): "major" or "minor", default "major"

**Returns:**
- Roman numeral analysis
- Borrowed chord detection
- Emotional interpretation
- Rule-breaking identified

### **3. daiw_apply_groove**
Apply genre-specific groove to MIDI

**Required:**
- `midi_file` (string): Path to MIDI file
- `groove_name` (string): funk, boom-bap, dilla, straight, trap

**Optional:**
- `intensity` (float): 0.0-1.0, default 1.0
- `output_path` (string): Auto-generated if not provided

**Returns:**
- Output file path
- Groove characteristics
- Technical details

---

## 📊 TOOL USAGE PATTERNS

### **Pattern 1: Complete Song Generation**
```
1. daiw_generate_harmony (intent → progression)
2. daiw_diagnose_progression (validate choices)
3. daiw_apply_groove (humanize drums)
```

### **Pattern 2: Analysis & Learning**
```
1. daiw_diagnose_progression (analyze existing)
2. daiw_generate_harmony (generate alternative)
3. Compare and learn
```

### **Pattern 3: Production Workflow**
```
1. daiw_generate_harmony (create harmony)
2. daiw_apply_groove (multiple grooves)
3. Compare grooves
4. Choose best for emotion
```

---

## 🔧 TROUBLESHOOTING

### **Issue: "DAiW modules not found"**
```bash
# Ensure DAiW modules are in same directory
cp harmony_generator.py /mnt/user-data/outputs/
cp chord_diagnostics.py /mnt/user-data/outputs/
cp groove_applicator.py /mnt/user-data/outputs/
```

### **Issue: "MIDI file not found"**
```
Make sure to provide full path to MIDI file:
/tmp/drums.mid (not just drums.mid)
```

### **Issue: "Invalid groove name"**
```
Valid grooves: funk, boom-bap, dilla, straight, trap
(all lowercase, use hyphen in boom-bap)
```

### **Issue: MCP Inspector won't start**
```bash
# Install Node.js if needed
# Then try again:
npx @modelcontextprotocol/inspector python daiw_mcp_starter.py
```

---

## 🎯 WHAT'S NEXT?

### **Current Status:**
- ✅ 3 core tools working
- ✅ MCP server functional
- ✅ Claude Desktop ready

### **Phase 2: Add More Tools**
- `daiw_analyze_audio` (reference track analysis)
- `daiw_compose_complete_song` (full generation)
- `daiw_generate_bass_line` (from harmony)
- `daiw_search_vault` (knowledge base)

### **Phase 3: Full Production**
- Package as `daiw-mcp` on PyPI
- Full integration with Phase 1 code
- Complete test suite
- Production documentation

---

## 💡 PHILOSOPHY IN ACTION

**"Interrogate Before Generate" via MCP:**

```
You: I want to write a song about loss

Claude: Let me help you explore that emotion first...
        What specifically was lost?
        How does it feel now?
        What transformation happened?
        
You: I found my friend after they'd already left permanently

Claude: [Uses that emotional excavation]
        [Calls daiw_generate_harmony with:
          core_wound="Finding someone after they left"
          emotional_intent="Grief disguised as love"
        ]
        
        Here's a progression that captures that...
        F-C-Dm-Bbm
        
        The Bbm (borrowed from F minor) creates a moment where
        hope invades the sadness - exactly like grief disguised
        as love. Every chord sounds like falling in love until
        Bbm reveals the truth.
```

**This is DAiW's philosophy automated through AI.**

---

## 📚 RESOURCES

### **Files in This Package:**
1. **daiw_mcp_starter.py** - Working MCP server (3 tools)
2. **MCP_IMPLEMENTATION_PLAN.md** - Complete implementation plan
3. **This guide** - Quick start & usage

### **Next Steps:**
1. Test with MCP Inspector
2. Configure Claude Desktop
3. Try the examples above
4. Read full implementation plan
5. Add more tools as needed

---

## ✨ THE VISION

**Today:**
```
Manual CLI commands
Copy/paste results
Upload files to Claude
```

**With Full MCP:**
```
You: "Create a complete lo-fi song about grief"
Claude: [Uses 8+ DAiW tools seamlessly]
        [Generates harmony, drums, bass, arrangement]
        [Analyzes references, creates production guide]
        "Here's your complete song package, ready to record"
```

**MCP transforms DAiW from a tool into an AI-accessible music creation service.**

---

*Ready to test? Run the MCP Inspector and try the tools!*

```bash
cd /mnt/user-data/outputs
npx @modelcontextprotocol/inspector python daiw_mcp_starter.py
```
